# Toon Render — análise inicial

Objetivo: criar um renderizador rasterizado para Blender 4.5.9, com resposta
interativa no viewport e controle explícito dos passes. A primeira entrega
executável deve mostrar malhas opacas com cor simples; texturas, transparência,
ordem de materiais e line art entram depois, sobre uma base medida e estável.

## Referência examinada

O arquivo `../BlenderMalt-Windows (1).zip` contém o addon BlenderMalt e o
framework Malt. A análise abaixo se baseia no código dentro desse ZIP, sem
copiá-lo para este projeto.

- `BlenderMalt/MaltRenderEngine.py`: implementa `bpy.types.RenderEngine`.
  `view_update` invalida a cena e as malhas alteradas; `view_draw` monta a cena
  avaliada, solicita um quadro e apresenta o resultado; `render` entrega os
  pixels ao resultado final do Blender.
- `BlenderMalt/MaltMeshes.py`: triangula a geometria avaliada, separa índices
  por material, extrai posições, normais e UVs, e usa código C para acelerar
  parte da extração. Mantém cache de malhas no viewport.
- `BlenderMalt/.MaltPath/Bridge/Client_API.py` e `Bridge/Server.py`: enviam a
  cena a um processo separado que cria um contexto OpenGL 4.5 via GLFW.
  O resultado volta por PBO, leitura de pixels e memória compartilhada. No
  `view_draw`, o Blender cria uma textura com esses pixels e desenha um quad.
- `BlenderMalt/.MaltPath/Malt/Pipeline.py`: agrupa objetos por material e malha,
  usa instancing e emite draw calls. O `draw_scene_pass` fixa estado de depth
  test e desliga blending antes de percorrer os materiais.
- `Malt/Pipelines/NPR_Pipeline`: demonstra passes, buffers auxiliares, material
  shaders e line art. Para transparência, `RenderLayers.py` repete o grafo por
  várias camadas de depth peeling, com custo proporcional ao número de camadas.
  `Shaders/Filters/Line.glsl` usa profundidade e normais para detectar linhas.
- `Malt/Pipelines/MiniPipeline/MiniPipeline.py`: exemplo mínimo de um FBO de
  cor e profundidade com um passe de malhas. É a melhor referência para o
  primeiro marco funcional.

O manifesto do addon de referência declara Blender mínimo 4.1, não 4.5.9
especificamente. Este addon próprio foi testado com o Blender 4.5.9 fornecido
pelo usuário.

## Viabilidade e escolha técnica

Sim: a técnica central é a mesma de um renderizador de jogos convencional:
malhas em buffers na GPU, shaders GLSL, teste de profundidade, passes em FBO e
composição de tela. Não há necessidade de WebGL, navegador ou ray tracing.
O custo real depende de resolução, quantidade de pixels por passe, número de
draw calls, geometria, materiais e frequência de atualização; "OpenGL" por si
só não garante rapidez.

Não convém reproduzir toda a arquitetura do Malt. O grafo genérico, o processo
separado, a leitura e o reenvio de cada quadro e os múltiplos passes de depth
peeling atendem a objetivos mais amplos. Para `toon_render`, a proposta inicial
é um pipeline fixo e pequeno:

1. Addon `RenderEngine` próprio, com `view_update`, `view_draw` e `render`.
2. Sincronização incremental de câmera, transformações e malhas avaliadas.
3. Cache de buffers por malha e um passe opaco com depth test em textura/FBO.
4. Apresentação da textura no viewport e leitura de pixels apenas quando
   necessária para o render final.
5. Medição separada de exportação da cena, desenho GPU e apresentação.

Para o primeiro protótipo, vale experimentar a API `gpu` do Blender 4.5 dentro
do próprio processo, que oferece shaders, batches e renderização offscreen.
Ela usa o backend gráfico do Blender; portanto a implementação deve evitar
pressupor que o contexto do viewport será sempre OpenGL puro. Caso a API não
permita o controle de estado ou a passagem de textura que o projeto exigir,
o fallback é um processo OpenGL próprio, como no Malt, medindo o custo da
transferência de quadros antes de adotá-lo.

## Evolução após a primeira imagem

1. Cor e textura de material, UV, alpha cutout.
2. Ordenação explícita por fila de renderização e passes opaco/transparente;
   transparentes convencionais exigem ordenação por distância e blending.
3. Buffer de normais e profundidade; detecção de contornos em tela; composição
   de line art. Controlar largura e sensibilidade sem reprocessar a geometria.
4. Ajustes de desempenho: cache persistente, menos mudanças de shader,
   resolução reduzida no viewport e limites claros de custo por passe.

## Protótipo 0.26.0

`Z Depth`, na categoria Shader, gera uma máscara de contato em tons de cinza
comparando a profundidade do material com a geometria visível de outros
objetos na direção da câmera. `Distance` limita a separação em unidades da
cena; `Expand` amplia a máscara em pixels e `Alpha Threshold` ignora fontes
muito transparentes. A saída `Fac` pode alimentar Color, Alpha ou um Color
Ramp. Por usar a profundidade da câmera, o efeito depende do enquadramento.

`Fresnel` retorna uma máscara em tons de cinza conforme o ângulo entre a
normal da face e a câmera. `Power` controla a concentração nas bordas.

Remover um efeito de pós processamento desativa imediatamente seu passe no
viewport e no render final, inclusive Outline / Lineart e Mosaic.

`Flip Book`, na categoria Texture, lê uma sprite sheet e oferece `Horizontal
Frames`, `Vertical Frames`, `Start Frame` e `End Frame`. A ordem é da esquerda
para a direita e de cima para baixo, começando no índice 0. `End Frame = -1`
usa a última célula automaticamente. A entrada numérica `Frame` seleciona
um quadro dentro do intervalo, começando em 0 e repetindo em loop. Ela aceita
diretamente a saída do node `Time` ou de qualquer outro node numérico. As saídas `Color` e `Alpha`
podem alimentar o material, inclusive em PNGs transparentes. A entrada
`Vector` aceita UV ou a saída do node Mapping.

`Time`, na categoria Utilities, retorna segundos como float. `Real Time`
continua aumentando com a timeline parada e atualiza a 3D View enquanto o
Toon Render está ativo. `Scene Time` usa o frame e o FPS da cena, adequado
para renderizar animações de forma reproduzível. Para animar a sprite sheet,
ligue `Time > Seconds` a `Flip Book > Frame`. Para controlar a velocidade,
insira um node `Math > Multiply` entre eles. O modo Real Time segue o relógio
do Blender; na exportação de animação, use Scene Time se cada frame precisar
corresponder exatamente ao FPS configurado.

Em `Light Properties > Toon Render Light`, luzes Sun, Point e Spot mostram
`Color` e `Strength`. Esses campos editam diretamente `Light.color` e
`Light.energy`, que o shader do Toon Render já usa. A força da sombra continua
no painel separado `Toon Render Shadows > Strength`.

O node `Blur`, na categoria Color, recebe e retorna `Color`. `Radius` define o
raio em pixels da imagem, `Strength` mistura a cor original com a borrada e
`Quality` escolhe 3×3, 5×5 ou 7×7 amostras. O renderer desenha a informação
que entra no node em um buffer próprio e então faz o blur, portanto também
funciona com cores geradas por outros nodes, incluindo `Proximity Mask` e
`Shader to RGB`. É possível encadear dois ou mais nodes Blur. A cor borrada
pode ser ligada a `Material Output > Color` ou convertida em máscara para
`Alpha`. Cada Blur ativo adiciona um buffer na resolução do render e mais
amostras de textura por pixel; raios grandes e qualidade 7×7 custam mais.

`Proximity Mask > Filter by Material` restringe a detecção aos materiais da
lista do próprio node. Use `+` para criar entradas e selecione o material em
cada uma; desligado, o node considera todas as outras malhas. O passe de
geometria de Outline e Mosaic agora ignora corretamente os uniforms de
proximidade quando a máscara só influencia a cor do material.

`Image Texture` apresenta a entrada `Vector` para ligar a saída de `Mapping`
ou outro vetor; sem ligação, continua usando a UV ativa. Ao abrir um arquivo
com nós Image Texture antigos, o addon acrescenta essa entrada automaticamente.

`Proximity Mask`, na categoria Shader, agora usa projeção direcional em vez de
amostras ao redor do pixel da câmera. `Direction` é o vetor em coordenadas do
mundo no sentido em que a geometria de origem projeta a máscara no material
receptor. Por exemplo, para projetar algo à frente de uma face em Y negativo
sobre essa face, use uma direção com Y positivo. `Distance` limita o percurso
do raio nessa direção; `Bias` evita influências quando as superfícies estão
quase coincidentes. `Resolution` determina a nitidez da silhueta (256, 512 ou
1024). A projeção ortográfica é ajustada aos limites do objeto receptor, então
a forma não muda com o movimento da câmera. Ligue `Fac` a `Color Ramp`,
`Mix Color` ou `Alpha` para criar efeitos sem lâmpada.
`Alpha Threshold` descarta pixels de origem pouco opacos; os demais contribuem
com seu alpha, inclusive quando ele vem de textura. O próprio objeto receptor
é excluído, mesmo com vários materiais. Cada combinação de objeto receptor,
filtro de materiais e configuração de projeção usa um mapa adicional. O mapa
guarda a primeira superfície vista na direção escolhida; várias superfícies
transparentes sobrepostas ainda não são acumuladas nesse passe.

O Toon Shader Editor agora oferece `Vertex Color`, `Object Color` e `Mapping`
na categoria Texture. `Vertex Color` escolhe um Color Attribute da malha pelo
nome e retorna Color e Alpha; funciona com atributos nos domínios Corner e
Point. `Object Color` retorna Color e Alpha da propriedade `Object > Viewport
Display > Color` de cada objeto. O buffer de vértices continua compartilhado
pelos materiais do objeto e inclui somente os atributos de cor usados pelos
seus shaders.
`Mapping` se liga à nova entrada Vector de `Image Texture`. Seus modos são UV,
Object, World, Triplanar e MatCap, com controles de Location, Rotation e Scale.
Triplanar mistura três projeções da imagem conforme a normal local, com
controle Blend para a nitidez da transição; MatCap usa a reflexão da normal
vista pela câmera. A entrada Vector do Image Texture usa a UV ativa quando
fica sem ligação. O modo Triplanar requer ligação direta de `Mapping > Vector`
para `Image Texture > Vector`.

Em `Render Properties > Toon Render`, `Transparent` preserva o alpha do fundo,
dos materiais Blend e dos materiais Additive no PNG final. Ao ativar essa opção,
o formato de cor do PNG muda para RGBA. Outros formatos, incluindo vídeo, usam
fundo opaco. O Outline e o Mosaic também preservam esse alpha durante os passes
de pós-processamento.
Em `World Properties > Viewport Display`, `Background Color` substitui o campo
`Color` do Blender e define a cor de fundo do viewport e do render quando
`Transparent` está desligado. Sem World, o fundo usa cinza escuro.
Os painéis nativos de `Object Data Properties` voltam a aparecer para malhas,
Curves e Point Clouds, incluindo Vertex Groups, Shape Keys, Color Attributes,
UV Maps, Attributes e dados de geometria compatíveis com cada tipo.

O arquivo `__init__.py` já é um addon instalável. Ele renderiza malhas avaliadas
trianguladas, respeita a câmera e as instâncias, e aplica teste de profundidade.
Ao selecionar `Toon Render` como motor de uma cena, o addon muda automaticamente
`Color Management > View Transform` para `Standard`. O mesmo ajuste é feito ao
abrir um arquivo que já usa Toon Render. Depois da ativação, o usuário ainda
pode alterar o View Transform manualmente.
O editor `Toon Shader Editor` é uma árvore de nós própria. Cada material novo
recebe apenas `Toon Surface` e `Material Output`. Cor e Alpha ficam em entradas
do `Toon Surface`; Alpha sem conexão oferece um slider de 0 a 1. O menu
`Add`/`Shift+A` agrupa os 17 nós em `Shader`, `Texture`, `Color` e `Utilities`.
Para textura, adicione `Image Texture` e conecte `Color` a `Color` e, se quiser usar o canal
alpha da imagem, `Alpha` a `Alpha`. A imagem usa a camada UV ativa da malha.
O grafo agora avalia os nós utilitários por pixel no shader da GPU. `Alpha`
aceita saídas escalares e saídas de cor; uma cor ligada a `Alpha` é convertida
para luminância RGB. `Image Texture > Color` pode alimentar diretamente Alpha,
assim como `RGB`, `Gradient Texture`, `Color Ramp`, `Mix Color` e combinações
desses nós. `Gradient Texture` usa UV e oferece `Scale` e modos Linear,
Diagonal, Radial e Spherical. `Color Ramp` usa a interface de rampa do Blender,
com suas interpolações e cores, e possui saídas `Color` e `Alpha`.
Os demais nós utilitários são `Value`, `UV Map`, `Separate Color`,
`Combine Color`, `Math`, `Map Range` e `Invert Color`. `Mix Color` oferece os
19 modos do Blender 4.5.9: Mix, Darken, Multiply, Color Burn, Lighten, Screen,
Color Dodge, Add, Overlay, Soft Light, Linear Light, Difference, Exclusion,
Subtract, Divide, Hue, Saturation, Color e Value. Seus valores são enviados
como uniforms; alterações numéricas não exigem recompilar o shader. Alterar
ligações, modo de mistura ou tipo de gradiente altera a variante do shader.
`Material Output` agora possui `Surface`, `Color` e `Alpha`. Sem conexão em
`Color`, a entrada `Surface` mantém a iluminação normal do `Toon Surface`.
Ao ligar uma cor em `Color`, ela vira a cor final do pixel, sem uma segunda
aplicação de luz. `Shader to RGB` transforma a saída `Shader` do `Toon Surface`
em cor já iluminada, que pode passar por `Color Ramp`, `Mix Color` e outros nós
antes de entrar em `Material Output > Color`. Assim é possível quantizar a
iluminação para criar faixas toon. `Toon Surface` também oferece saída `Alpha`.
`Shadow Mask`, na categoria `Shader`, oferece uma saída `Fac`: 0 em áreas sem
sombra e até 1 nas áreas cobertas por uma sombra de Sun, Spot ou Point.
Quando há várias luzes com sombras, usa o maior valor de sombra. É possível
ligar `Fac` diretamente a `Material Output > Alpha` para mostrar uma superfície
somente onde há sombra; com `Color Ramp`, é possível ajustar a borda ou
inverter a máscara. A luz precisa ter `Shadows` ativado e o material precisa
ter `Receive Shadow` marcado. No passe que produz os mapas de sombra, o nó usa
um valor constante para evitar dependência circular com sua própria máscara.
O buffer de geometria usado pelo Outline ainda não reproduz a máscara de
sombra no contorno de superfícies com esse Alpha.
No `Material Output`, uma ligação em `Alpha` define a transparência final.
Sem ligação, o slider `Alpha` controla a transparência diretamente: com
`Surface` ativo ele multiplica o Alpha do `Toon Surface`; com `Color` ligado,
vale sozinho. O valor padrão 1 mantém a transparência anterior.
O nó `Additive` possui uma entrada `Color` com seletor de cor, que também aceita
uma conexão RGB ou textura, controle `Intensity` e uma saída `Shader` para
`Material Output > Surface`. O renderizador usa mistura aditiva convencional:
`RGB final = RGB da cena + RGB do Additive × Alpha`. O alpha da cor ou textura
é multiplicado pelo `Alpha` do `Material Output`. `Intensity` começa em 1 e
aceita valores HDR acima de 1. Sua cor não depende das luzes. O passe usa
teste de profundidade e não escreve profundidade, permitindo que geometrias
sobrepostas contribuam juntas. Uma conexão em
`Material Output > Color` prevalece sobre `Surface` e desativa o modo aditivo.
Em `Material Properties > Toon Render`, `Double Sided` e `Unlit` começam
desmarcados. `Double Sided` mostra frente e verso da face; desmarcado, o verso
é descartado no render normal e no mapa usado pelo Outline. `Unlit` usa a cor
e a textura do material sem aplicar iluminação, mantendo Alpha e transparência.
`Cast Shadow` e `Receive Shadow` começam marcados. O primeiro decide se os
triângulos desse material entram nos mapas de sombra das luzes; o segundo
decide se a contribuição de luz desse material é escurecida pelas sombras.
Ambos funcionam por material, inclusive quando um objeto usa vários slots.
O renderizador desenha materiais transparentes depois dos opacos, com blending
alpha e ordenação de objetos pela distância à câmera. `Toon Surface` oferece
`Transparency: Blend/Cutout` abaixo da entrada `Alpha`. Em Cutout, `Threshold`
descarta pixels abaixo do valor e os restantes escrevem profundidade. Em Blend,
`Threshold` descarta pixels quase transparentes antes da mistura e do pré-passe
de profundidade; o valor inicial é 0,001. Aumente-o se bordas transparentes
estiverem encobrindo superfícies atrás delas. `Transparency Overlap` também
fica abaixo de Alpha: ligado, mistura todas as faces; desligado, usa um
pré-passe de profundidade para mostrar somente a superfície mais próxima em
cada pixel.
`Render Priority` é um float logo abaixo dos controles de transparência.
Valores menores são desenhados antes, valores maiores depois. Cada valor cria
uma camada de composição: a profundidade é reiniciada entre as camadas, então
uma prioridade maior aparece por cima mesmo se a geometria estiver mais longe
da câmera. Dentro da mesma prioridade, os opacos (inclusive Cutout) passam
antes dos materiais Blend, seguidos pelos Additive; a profundidade continua
funcionando normalmente e Blend é ordenado pela distância da câmera. Muitos valores distintos exigem
mais reinícios do buffer de profundidade.
A iluminação lê até quatro lâmpadas Sun, Point ou Spot da cena, incluindo cor e
intensidade. Point e Spot usam distância;
Spot também usa direção, tamanho e suavidade do cone. Há uma parcela ambiente
fixa. A escala das lâmpadas locais é aproximada, não física.
Em `Light Properties > Toon Render Shadows`, Sun, Point e Spot oferecem
`Shadows` (desligado por padrão), resolução, distância, bias, suavidade e força.
Sun também oferece `Area Size`, que controla a área coberta pelo mapa. O Sun
acompanha a região próxima da câmera para concentrar a resolução na parte
visível. Point usa seis projeções reunidas num atlas 2D; resoluções altas nesse
tipo de luz consomem mais memória. As sombras são calculadas por luz e não
escurecem materiais `Unlit`. O mapa usa Alpha do `Toon Surface`, inclusive
Alpha conectado a `Image Texture`: Cutout faz sombra recortada e Blend
transmite luz proporcional à opacidade. Duas camadas de profundidade permitem
sombras de até duas superfícies transparentes sobrepostas ao longo do raio;
sobreposições mais profundas ainda não são representadas integralmente.
Também há uma fila opaca explícita, agrupada por
variante de shader e material. Geometria do viewport fica em cache até uma
atualização geométrica.

Na versão 0.10.1, a montagem das malhas usa leitura em blocos e NumPy em vez
de percorrer cada canto da malha em Python. O cache do viewport agora invalida
somente as malhas alteradas; peças com deformação de esqueleto são
reconstruídas a cada quadro e peças estáticas, inclusive as que usam Mirror,
mantêm seus buffers GPU. No arquivo `hero.blend` fornecido para medir, a etapa
de montagem das 19 malhas caiu de aproximadamente 48 ms para 7 ms por quadro
após o primeiro quadro, em render de teste de 256 × 256. Essa medição isola a
montagem de malhas no F12; o FPS do viewport deve ser medido na interface.
Na versão 0.11.1, cada malha avaliada cria um único Vertex Buffer para posições,
normais e UVs. Cada material usado cria apenas seu Index Buffer e um batch que
referencia o Vertex Buffer comum. Isso elimina a duplicação dos atributos por
material, inclusive quando a malha deformada precisa ser enviada novamente em
cada quadro. O número de chamadas de desenho por material permanece igual.

Na aba `World`, o painel `Toon Render Post Processing` contém uma pilha de
efeitos. `+ Add` oferece `Outline / Lineart` e `Mosaic`; cada item pode ser
ativado, desativado, removido e movido para cima ou para baixo. A ordem da
lista é a ordem de aplicação. `Outline / Lineart` tem cor, espessura em pixels,
sensibilidade à profundidade e às normais, e opacidade. O renderizador desenha
a cena em uma textura, gera um mapa de normais e distância da câmera e aplica
os efeitos em passes sucessivos de tela cheia. O mapa ignora detalhes internos
da textura de cor; detecta silhuetas e mudanças de forma. Alpha e Cutout
definem onde há geometria no mapa. `Mosaic` divide a imagem em células
quadradas com `Pixel Size` de 1 a 256 pixels e mistura a cor pixelizada com
`Opacity` de 0 a 1. Com Pixel Size 1 ou Opacity 0, preserva a imagem.
As configurações pertencem ao datablock World, portanto
cenas que compartilham o mesmo World compartilham a pilha.
Ambos os efeitos têm `Limit to Materials`, desligado por padrão para agir sobre
toda a cena. Ao ativar, use `+` para inserir materiais
na lista ou o conta-gotas para clicar em uma face na 3D View e adicionar seu
material. `-` remove o item selecionado. A lista vazia não aplica o efeito.
O filtro usa o material visível por pixel, inclusive em objetos com vários
materiais; no Outline, também desenha a borda entre um material selecionado e
outro não selecionado. No Mosaic, apenas pixels do material escolhido são
pixelizados, respeitando a geometria visível. Quando `Limit to Materials`
está ativo, `Occlusion Alpha Threshold` controla quais superfícies Blend ou
Additive na frente bloqueiam essa seleção: com alpha abaixo do limiar, a
superfície não oculta o material selecionado atrás dela no mapa de IDs. O
limiar não descarta o próprio material selecionado, mesmo que ele seja
Additive e seu alpha esteja abaixo do valor do slider.
O Outline / Lineart oferece o mesmo slider e o aplica tanto ao mapa de IDs
quanto ao mapa de geometria que detecta contornos, inclusive sem filtro de
materiais. Por exemplo, para uma malha com alpha 0,8, use um limiar maior
que 0,8. O render da malha transparente continua normal; o limiar afeta
apenas as máscaras usadas pelo pós-processamento. Efeitos com limiares
diferentes recebem mapas separados.
Cada efeito da pilha pode ter
sua própria lista. O mapa de IDs
de materiais exige um passe adicional de geometria somente quando pelo menos
um filtro tem materiais na lista.

Os nós do Shader Editor padrão não integram esta árvore. O grafo próprio é
armazenado no material; o renderizador segue seus links até o `Material Output`.
Se o material não tem grafo Toon, o addon usa `diffuse_color`. A ordenação de
Blend é por objeto; `Transparency Overlap` desligado resolve faces sobrepostas
do próprio batch, mas interseções complexas entre objetos ainda podem depender
da ordem. O Outline atual não gera linhas para detalhes
que existem apenas na textura de cor.

O `Toon Shader Editor` mantém no centro do cabeçalho o popover `Slot` e o
seletor de material com `New`, como no Shader Editor padrão. Com Toon Render
ativo, esse `New` cria um material Toon, gera `Toon Surface` e `Material Output`,
e associa a árvore ao material. O addon não acrescenta um botão ao cabeçalho do
viewport. No topo de `Material Properties`, o painel de slots mostra a lista
de materiais do objeto, os botões para adicionar, remover e reordenar slots,
e o seletor de material. Seu `New` também cria um material Toon. No modo Edit,
`Assign`, `Select` e `Deselect` permitem atribuir o material ativo às faces
selecionadas e inspecionar essa atribuição. O painel `Toon Render` com
`Double Sided`, `Unlit`, `Cast Shadow` e `Receive Shadow` aparece logo abaixo.
Em `Output Properties`, o Toon Render mostra os painéis nativos `Format`,
`Frame Range` e `Output`, incluindo resolução, porcentagem, proporção dos
pixels, taxa de quadros, intervalo e passo da animação, caminho, formato e
opções de arquivo. Os subpainéis de gerenciamento de cor, densidade de pixels
e codificação de vídeo também aparecem quando aplicáveis. Esses valores são
as propriedades padrão do Blender; não há uma cópia separada no addon.
Para abrir o editor dedicado em uma área, use a busca F3 por `Open Toon Shader
Editor`; depois você pode conservar essa área no seu workspace. O cabeçalho
padrão do Blender foi substituído apenas para esta árvore, pois seu `New`
criava um grupo de nós solto que não aparecia no material.
Materiais existentes do Blender conservam seus dados; eles não são alterados
pelo addon. O antigo nó de grupo usado na versão 0.3 foi removido.

Teste realizado: Blender 4.5.9 LTS, em segundo plano. `smoke_editor.py` criou
via `New Material` um grafo com exatamente dois nós e confirmou que a árvore
permanece associada ao material depois de salvar e reabrir o `.blend`.
`smoke_materials.py` renderizou dois cubos com dois nós `Image Texture`
independentes. `smoke_lights.py` comparou o render ambiente aos renders Sun,
Point e Spot, e confirmou que uma Spot apontada para longe não ilumina o cubo.
`smoke_alpha.py` confirmou render opaco, Alpha 0, Alpha 0,5 e Alpha vindo de
imagem RGBA. Também comparou Cutout e Blend acima/abaixo dos thresholds e
Transparency Overlap ligado/desligado. `smoke_priority.py` colocou um cubo
atrás do outro, inverteu suas prioridades e verificou a mudança da cor final
nos passes opaco, Blend e em uma mistura dos dois. Também conferiu que
prioridades iguais conservam o teste de profundidade. `smoke_editor.py`
confirmou a persistência dos controles ao salvar e reabrir. `smoke_post.py`
comparou o render
sem efeito, com Outline, com efeito desligado, com dois efeitos e com ordem
invertida; também salvou e reabriu a pilha no World. O F12 foi verificado;
o viewport com pós-processamento ainda precisa de teste na interface. Estes
testes confirmam o caminho básico, não FPS.
`smoke_material_flags.py` confirmou o verso oculto por padrão, o verso visível
com `Double Sided`, a cor sem iluminação com `Unlit` e a persistência das
opções ao salvar e reabrir.
`smoke_shared_vbo.py` renderizou uma malha com dois materiais, um simples e
outro com textura, usando batches com o mesmo Vertex Buffer.
`smoke_shadows.py` comparou Sun, Spot e Point com sombras ligadas e desligadas.
No Sun, também verificou Alpha 0, Alpha 0,5 e textura RGBA em Cutout e Blend; na Point,
verificou Alpha 0,5. Conferiu ainda `Strength` zero e render com Outline ativo.
`smoke_utility_nodes.py` verificou Value, RGB e cor de textura ligados a Alpha,
Gradient Texture com duas escalas, Color Ramp e seu Alpha, os 19 modos de Mix
Color, Separate/Combine Color, Math, Map Range e Invert Color. Também salvou e
reabriu um `.blend` com esses nós. `smoke_shadows.py` confirmou uma sombra
parcial gerada por Gradient Texture ligado a Alpha.
`smoke_shader_to_rgb.py` confirmou que Shader to RGB reproduz a cor iluminada,
que Color Ramp reage à Sun, que Color direto funciona sem Surface e sem luz,
e que o Alpha do Material Output funciona como slider ou ligado à saída Alpha
do Toon Surface. `smoke_shadows.py` confirmou a sombra do caminho Shader to RGB
com Alpha separado. Os novos nós e links persistiram após salvar e reabrir.
`smoke_material_slots.py` criou dois materiais Toon, acrescentou o segundo
slot e usou `Assign` no modo Edit para aplicar o segundo material a uma face.
`smoke_shadows.py` verificou que desligar `Cast Shadow` no objeto remove sua
sombra e desligar `Receive Shadow` no chão impede a sombra recebida.
`smoke_material_flags.py` confirmou os valores padrão e a persistência dos
dois checkboxes. `smoke_output_properties.py` confirmou a visibilidade dos
painéis nativos e gerou uma imagem de 48 × 32 pixels a partir de uma resolução
de 96 × 64 em 50%.
`smoke_outline_materials.py` comparou dois objetos com materiais diferentes:
com cada filtro ativo, só o objeto selecionado ganhou contorno. Confirmou
também dois filtros em cascata, conta-gotas por ray cast e persistência no
`.blend`. `smoke_outline_material_faces.py` conferiu a borda entre faces de
materiais diferentes no mesmo objeto. `smoke_post.py` confirmou o resultado
do Outline sem filtro.

Para testar na interface:

1. Use o ZIP de instalação `toon_render-0.20.3.zip` na raiz do projeto. Desative
   a versão anterior antes de instalar a nova versão.
2. Em Blender 4.5.9, abra `Edit > Preferences > Add-ons > Install from Disk` e
   selecione o ZIP. Ative `Toon Render`.
3. Selecione `Toon Render` em `Render Properties > Render Engine`.
4. No viewport, mude o shading para `Rendered`; depois pressione F12.
5. Para abrir o editor em uma área, use F3 e `Open Toon Shader Editor`. Clique
   em `New` no seletor central de material; o editor deve mostrar `Toon Surface`
   e `Material Output`.
   O grafo inicial deve mostrar somente `Toon Surface` e `Material Output`.
6. Para testar textura, use `Shift+A > Image Texture`, escolha uma imagem e
   conecte sua saída `Color` à entrada `Color` de `Toon Surface`. Para usar a
   transparência da imagem, conecte também `Alpha` a `Alpha`.
7. Abaixo de `Alpha` no `Toon Surface`, escolha `Blend` ou `Cutout`. Cada modo
   mostra seu `Threshold`; `Transparency Overlap` aparece em Blend. Digite um
   valor em `Render Priority` para colocar esse material acima ou abaixo de
   materiais com outros valores, mesmo que a distância à câmera seja diferente.
8. Na aba `World`, abra `Toon Render Post Processing` e clique em `+ Add`.
   Ajuste `Outline / Lineart` e confira no viewport em `Rendered` e no F12.
   Para contornar apenas materiais escolhidos, marque `Limit to Materials`;
   use `+` e o seletor de material, ou clique no conta-gotas e depois em uma
   face na 3D View. Pressione Esc para cancelar o conta-gotas.
9. Na aba `Material Properties`, abra `Toon Render` e ajuste `Double Sided`
   `Unlit`, `Cast Shadow` e `Receive Shadow` para o material ativo.
   Acima desse painel, use a lista de slots para adicionar outro material.
   Entre no modo Edit, selecione faces, escolha o slot e clique em `Assign`.
10. Selecione uma luz Sun, Point ou Spot. Em `Light Properties > Toon Render
    Shadows`, marque `Shadows`. Ajuste `Area Size` no Sun para cobrir os objetos
    que devem projetar e receber sombra; aumente `Resolution` para mais detalhe
    e `Bias` se houver artefatos de autossombreamento.
11. Em `Output Properties`, ajuste `Format`, `Frame Range` e `Output` para a
    resolução, os quadros e o formato de arquivo desejados.

O próximo teste visual é confirmar os dois materiais no viewport. FPS e tempo
por estágio devem ser medidos antes de definir metas de desempenho.
