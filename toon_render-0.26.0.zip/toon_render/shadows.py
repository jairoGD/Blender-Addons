"""Opacity-aware shadow maps and per-light controls for Toon Render."""

import math
import bpy
from mathutils import Matrix, Vector
from . import toon_graph


SHADOW_VERTEX = """
uniform mat4 model_view_projection;
uniform mat4 model_matrix;
in vec3 pos;
in vec3 normal;
in vec2 uv;
out vec2 tex_coord;
out vec3 world_position;
out vec3 world_normal;
out vec3 local_position;
out vec3 local_normal;
void main() {
    gl_Position = model_view_projection * vec4(pos, 1.0);
    tex_coord = uv;
    world_position = (model_matrix * vec4(pos, 1.0)).xyz;
    world_normal = mat3(transpose(inverse(model_matrix))) * normal;
    local_position = pos;
    local_normal = normal;
}
"""

SHADOW_FRAGMENT = """
uniform mat4 view_matrix;
uniform float material_alpha;
uniform int alpha_mode;
uniform float alpha_threshold;
uniform int radial_mode;
uniform vec3 shadow_light_position;
uniform float shadow_far;
#ifdef USE_ALPHA_TEXTURE
uniform sampler2D alpha_texture;
#endif
#ifdef PEEL_LAYER
uniform sampler2D previous_layer;
#endif
in vec2 tex_coord;
in vec3 world_position;
in vec3 world_normal;
in vec3 local_position;
in vec3 local_normal;
out vec4 frag_color;
void main() {
    float alpha = material_alpha;
#ifdef USE_ALPHA_TEXTURE
    alpha *= texture(alpha_texture, tex_coord).a;
#endif
    if (alpha_mode == 1 && alpha < alpha_threshold) discard;
    if (alpha_mode == 0 && alpha <= alpha_threshold) discard;
    if (alpha_mode == 1) alpha = 1.0;
    float shadow_depth = radial_mode != 0
        ? length(world_position - shadow_light_position) / shadow_far
        : gl_FragCoord.z;
#ifdef PEEL_LAYER
    vec4 previous = texelFetch(previous_layer, ivec2(gl_FragCoord.xy), 0);
    if (previous.a == 0.0 || shadow_depth <= previous.r + 0.00001) discard;
#endif
    frag_color = vec4(shadow_depth, alpha, 0.0, 1.0);
}
"""


def _redraw(_self=None, _context=None):
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


class TOON_PT_light_settings(bpy.types.Panel):
    bl_label = 'Toon Render Light'
    bl_idname = 'TOON_PT_light_settings'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'data'
    bl_order = 0

    @classmethod
    def poll(cls, context):
        light = getattr(context, 'light', None)
        return (context.scene is not None
                and context.scene.render.engine == 'TOON_RENDER'
                and light is not None
                and light.type in {'SUN', 'POINT', 'SPOT'})

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(context.light, 'color', text='Color')
        layout.prop(context.light, 'energy', text='Strength')


class TOON_PT_light_shadows(bpy.types.Panel):
    bl_label = 'Toon Render Shadows'
    bl_idname = 'TOON_PT_light_shadows'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'data'

    @classmethod
    def poll(cls, context):
        return (context.scene is not None
                and context.scene.render.engine == 'TOON_RENDER'
                and context.light is not None
                and context.light.type in {'SUN', 'POINT', 'SPOT'})

    def draw(self, context):
        light = context.light
        layout = self.layout
        layout.prop(light, 'toon_shadow_enabled', text='Shadows')
        column = layout.column()
        column.enabled = light.toon_shadow_enabled
        column.prop(light, 'toon_shadow_resolution', text='Resolution')
        column.prop(light, 'toon_shadow_distance', text='Distance')
        if light.type == 'SUN':
            column.prop(light, 'toon_shadow_size', text='Area Size')
        column.prop(light, 'toon_shadow_bias', text='Bias')
        column.prop(light, 'toon_shadow_softness', text='Softness')
        column.prop(light, 'toon_shadow_strength', text='Strength', slider=True)


def _orthographic(size, near, far):
    return Matrix((
        (2.0 / size, 0.0, 0.0, 0.0),
        (0.0, 2.0 / size, 0.0, 0.0),
        (0.0, 0.0, -2.0 / (far - near), -(far + near) / (far - near)),
        (0.0, 0.0, 0.0, 1.0),
    ))


def _perspective(angle, near, far):
    scale = 1.0 / math.tan(max(0.02, min(angle, math.pi - 0.02)) * 0.5)
    return Matrix((
        (scale, 0.0, 0.0, 0.0),
        (0.0, scale, 0.0, 0.0),
        (0.0, 0.0, -(far + near) / (far - near), -2.0 * far * near / (far - near)),
        (0.0, 0.0, -1.0, 0.0),
    ))


def _light_matrix(light_object, object_matrix, camera_view):
    light = light_object.data
    distance = light.toon_shadow_distance
    matrix = object_matrix
    rotation = matrix.to_quaternion()
    if light.type == 'SUN':
        camera_world = camera_view.inverted()
        forward = camera_world.to_quaternion() @ Vector((0.0, 0.0, -1.0))
        center = camera_world.translation + forward * min(10.0, distance * 0.33)
        direction = rotation @ Vector((0.0, 0.0, -1.0))
        position = center - direction * distance
        light_world = Matrix.Translation(position) @ rotation.to_matrix().to_4x4()
        return _orthographic(light.toon_shadow_size, 0.1, distance * 2.0) @ light_world.inverted()
    light_world = Matrix.Translation(matrix.translation) @ rotation.to_matrix().to_4x4()
    return _perspective(light.spot_size, 0.1, distance) @ light_world.inverted()


def _point_face_matrix(position, face, far):
    directions = (
        ((1, 0, 0), (0, -1, 0)), ((-1, 0, 0), (0, -1, 0)),
        ((0, 1, 0), (0, 0, 1)), ((0, -1, 0), (0, 0, -1)),
        ((0, 0, 1), (0, -1, 0)), ((0, 0, -1), (0, -1, 0)),
    )
    direction = Vector(directions[face][0])
    up = Vector(directions[face][1])
    right = direction.cross(up).normalized()
    corrected_up = right.cross(direction)
    view = Matrix((
        (right.x, right.y, right.z, -right.dot(position)),
        (corrected_up.x, corrected_up.y, corrected_up.z, -corrected_up.dot(position)),
        (-direction.x, -direction.y, -direction.z, direction.dot(position)),
        (0.0, 0.0, 0.0, 1.0),
    ))
    return _perspective(math.pi * 0.5, 0.1, far) @ view


def _get_shadow_shader(engine, graph, peeled):
    import gpu
    from . import _graph_vertex

    key = ('SHADOW', graph.code, peeled)
    if key not in engine._shaders:
        source = SHADOW_FRAGMENT.replace('void main() {', graph.code + '\nvoid main() {', 1)
        source = source.replace('''    float alpha = material_alpha;
#ifdef USE_ALPHA_TEXTURE
    alpha *= texture(alpha_texture, tex_coord).a;
#endif''', '    float alpha = toon_graph_alpha(vec3(1.0));')
        if graph.uses_shadow_mask:
            source = source.replace('    float alpha = toon_graph_alpha(vec3(1.0));',
                                    '    toon_shadow_mask_value = 1.0;\n'
                                    '    float alpha = toon_graph_alpha(vec3(1.0));')
        engine._shaders[key] = gpu.types.GPUShader(
            _graph_vertex(SHADOW_VERTEX, graph),
            ('#define PEEL_LAYER\n' if peeled else '') + source)
    return engine._shaders[key]


def render_shadow_maps(engine, depsgraph, camera_view, priority_queues,
                       textures, viewport=False):
    """Return light-indexed maps and transient offscreens to release after shading."""
    import gpu

    sources = []
    light_index = 0
    for instance in depsgraph.object_instances:
        obj = instance.object
        if obj.type != 'LIGHT' or obj.hide_render or obj.data.type not in {'SUN', 'POINT', 'SPOT'}:
            continue
        if obj.data.toon_shadow_enabled:
            sources.append((light_index, obj, instance.matrix_world.copy()))
        light_index += 1
        if light_index == 4:
            break
    if viewport:
        active_keys = {(obj.original.as_pointer(), int(obj.data.toon_shadow_resolution),
                        obj.data.type) for _, obj, _ in sources}
        for key in list(engine._viewport_shadow_buffers):
            if key not in active_keys:
                old = engine._viewport_shadow_buffers.pop(key)
                if isinstance(old, tuple):
                    for offscreen in old:
                        offscreen.free()
    if not sources:
        return {}, []
    if not any(item[-2] for queues in priority_queues.values()
               for queue in queues for item in queue):
        return {}, []

    def get_texture(kind, source):
        return toon_graph.gpu_texture(kind, source, textures)

    maps = {}
    transient = []

    def draw_layer(target, light_matrix, layer_index, previous_texture,
                   position, distance, point, resolution, origin=(0, 0),
                   clear_color=True):
        with target.bind():
            gpu.state.viewport_set(origin[0], origin[1], resolution, resolution)
            gpu.state.depth_test_set('LESS_EQUAL')
            gpu.state.depth_mask_set(True)
            gpu.state.blend_set('NONE')
            gpu.state.color_mask_set(True, True, True, True)
            framebuffer = gpu.state.active_framebuffer_get()
            if clear_color:
                framebuffer.clear(color=(1.0, 0.0, 0.0, 0.0), depth=1.0)
            else:
                framebuffer.clear(depth=1.0)
            for opaque_queue, transparent_queue in priority_queues.values():
                for item in opaque_queue + transparent_queue:
                    _, _, _, model, batch, graph, method, threshold, _, _, double_sided, _, cast_shadow, _ = item
                    if not cast_shadow:
                        continue
                    shader = _get_shadow_shader(engine, graph, layer_index > 0)
                    gpu.state.face_culling_set('NONE' if double_sided else 'BACK')
                    shader.bind()
                    shader.uniform_float('model_view_projection', light_matrix @ model)
                    shader.uniform_float('model_matrix', model)
                    try:
                        shader.uniform_float('view_matrix', camera_view)
                    except ValueError:
                        pass
                    graph.bind(shader, get_texture)
                    shader.uniform_int('alpha_mode', 1 if method == 'CUTOUT' else 0)
                    shader.uniform_float('alpha_threshold', threshold)
                    shader.uniform_int('radial_mode', 1 if point else 0)
                    shader.uniform_float('shadow_light_position', position)
                    shader.uniform_float('shadow_far', distance)
                    if layer_index:
                        shader.uniform_sampler('previous_layer', previous_texture)
                    batch.draw(shader)

    try:
        for light_index, light_object, object_matrix in sources:
            light = light_object.data
            resolution = int(light.toon_shadow_resolution)
            cache_key = (light_object.original.as_pointer(), resolution, light.type)
            point = light.type == 'POINT'
            buffers = engine._viewport_shadow_buffers.get(cache_key) if viewport else None
            if buffers is None:
                if point:
                    colors = tuple(gpu.types.GPUTexture(
                        (resolution * 3, resolution * 2), format='RGBA16F')
                        for _ in range(2))
                    depth = gpu.types.GPUTexture(
                        (resolution * 3, resolution * 2), format='DEPTH_COMPONENT24')
                    frames = tuple(gpu.types.GPUFrameBuffer(
                        depth_slot=depth, color_slots=[color]) for color in colors)
                    buffers = {'colors': colors, 'depth': depth, 'frames': frames}
                else:
                    buffers = tuple(gpu.types.GPUOffScreen(
                        resolution, resolution, format='RGBA16F') for _ in range(2))
                    if not viewport:
                        transient.extend(buffers)
                if viewport:
                    engine._viewport_shadow_buffers[cache_key] = buffers
            position = object_matrix.translation
            if point:
                for layer_index, target in enumerate(buffers['frames']):
                    previous = buffers['colors'][0] if layer_index else None
                    for face in range(6):
                        matrix = _point_face_matrix(position, face, light.toon_shadow_distance)
                        origin = (face % 3 * resolution, face // 3 * resolution)
                        draw_layer(target, matrix, layer_index, previous, position,
                                   light.toon_shadow_distance, True, resolution,
                                   origin, face == 0)
                maps[light_index] = ('POINT', None, buffers['colors'], light, position)
            else:
                matrix = _light_matrix(light_object, object_matrix, camera_view)
                for layer_index, target in enumerate(buffers):
                    previous = buffers[0].texture_color if layer_index else None
                    draw_layer(target, matrix, layer_index, previous, position,
                               light.toon_shadow_distance, False, resolution)
                maps[light_index] = ('MAP2D', matrix, buffers, light, position)
    except Exception:
        for offscreen in transient:
            offscreen.free()
        raise
    finally:
        gpu.state.face_culling_set('NONE')
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
    return maps, transient


def register():
    bpy.types.Light.toon_shadow_enabled = bpy.props.BoolProperty(
        name='Shadows', default=False, update=_redraw)
    bpy.types.Light.toon_shadow_resolution = bpy.props.EnumProperty(
        name='Resolution', items=tuple((str(size), str(size), '')
                                       for size in (256, 512, 1024, 2048)),
        default='512', update=_redraw)
    bpy.types.Light.toon_shadow_distance = bpy.props.FloatProperty(
        name='Distance', default=30.0, min=1.0, max=1000.0, update=_redraw)
    bpy.types.Light.toon_shadow_size = bpy.props.FloatProperty(
        name='Area Size', default=20.0, min=1.0, max=1000.0, update=_redraw)
    bpy.types.Light.toon_shadow_bias = bpy.props.FloatProperty(
        name='Bias', default=0.004, min=0.0, max=0.05, precision=4, update=_redraw)
    bpy.types.Light.toon_shadow_softness = bpy.props.FloatProperty(
        name='Softness', default=1.0, min=0.0, max=4.0, update=_redraw)
    bpy.types.Light.toon_shadow_strength = bpy.props.FloatProperty(
        name='Strength', subtype='FACTOR', default=1.0, min=0.0, max=1.0,
        update=_redraw)
    bpy.utils.register_class(TOON_PT_light_settings)
    bpy.utils.register_class(TOON_PT_light_shadows)


def unregister():
    bpy.utils.unregister_class(TOON_PT_light_shadows)
    bpy.utils.unregister_class(TOON_PT_light_settings)
    for name in ('toon_shadow_strength', 'toon_shadow_softness', 'toon_shadow_bias',
                 'toon_shadow_size', 'toon_shadow_distance', 'toon_shadow_resolution',
                 'toon_shadow_enabled'):
        delattr(bpy.types.Light, name)
