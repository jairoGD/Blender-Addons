bl_info = {
    "name": "Bake Light Angles",
    "author": "OpenAI",
    "version": (2, 3, 1),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > Bake Light Angles",
    "description": "Bake eight editable toon lighting angles, then generate a UV sprite sheet",
    "category": "Bake",
}

import math
import os
import traceback

import bpy
import numpy as np
from bpy.props import (
    BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty,
    PointerProperty, StringProperty,
)
from mathutils import Matrix, Vector
from bpy.app.handlers import persistent


FRAME_COUNT = 8
BAKE_KEYS = (
    "target", "use_selected_to_active", "use_clear", "use_pass_color",
    "use_pass_direct", "use_pass_indirect", "margin", "use_cage",
    "cage_extrusion", "max_ray_distance", "cage_object",
)


def mesh_poll(_self, obj):
    return obj is not None and obj.type == 'MESH'


def light_poll(_self, obj):
    return obj is not None and obj.type == 'LIGHT'


class BLA_SourceSlot(bpy.types.PropertyGroup):
    material: PointerProperty(type=bpy.types.Material)
    link: EnumProperty(items=[('DATA', "Data", ""), ('OBJECT', "Object", "")])


class BLA_Frame(bpy.types.PropertyGroup):
    image: PointerProperty(type=bpy.types.Image)


class BLA_ObjectData(bpy.types.PropertyGroup):
    source_slots: CollectionProperty(type=BLA_SourceSlot)
    frames: CollectionProperty(type=BLA_Frame)
    preview_material: PointerProperty(type=bpy.types.Material)
    current_angle: IntProperty(default=0, min=0, max=FRAME_COUNT - 1)
    bake_number: IntProperty(default=0, min=0)


class BLA_Settings(bpy.types.PropertyGroup):
    target: PointerProperty(name="UV Object", type=bpy.types.Object, poll=mesh_poll)
    light: PointerProperty(name="Rotating Light", type=bpy.types.Object, poll=light_poll)
    bake_mode: EnumProperty(
        name="Bake Mode",
        description="Choose the material result baked at each light angle",
        items=[
            ('TOON', "Toon Shader", "Bake banded direct light over the source material color"),
            ('CURRENT', "Current", "Bake the source materials with Blender's Combined pass"),
        ],
        default='TOON',
    )
    width: IntProperty(name="Width", default=512, min=16, max=4096)
    height: IntProperty(name="Height", default=512, min=16, max=4096)
    columns: EnumProperty(name="Columns", items=[
        ('4', "4 x 2", ""), ('8', "8 x 1", ""),
        ('2', "2 x 4", ""), ('1', "1 x 8", ""),
    ], default='4')
    samples: IntProperty(name="Samples", default=32, min=1, max=512)
    pivot: EnumProperty(name="Rotation Center", items=[
        ('OBJECT', "Object Origin", ""), ('BOUNDS', "Mesh Center", ""),
    ], default='BOUNDS')
    start_angle: FloatProperty(name="Start Angle", default=0.0, subtype='ANGLE')
    bands: IntProperty(name="Toon Bands", default=3, min=2, max=8)
    shadow_level: FloatProperty(name="Shadow Level", default=0.35, min=0.0, max=1.0)
    light_exposure: FloatProperty(name="Light Exposure", default=1.0, min=0.01, max=100.0)
    overwrite: BoolProperty(
        name="Overwrite",
        description="Replace pixels in the existing eight frame images when baking again",
        default=True,
    )
    output: StringProperty(name="Sprite Sheet PNG", subtype='FILE_PATH', default='//toon_angles.png')


def frame_name(obj, index, settings, bake_number):
    degrees = (math.degrees(settings.start_angle) - 45.0 * index) % 360.0
    if math.isclose(degrees, round(degrees), abs_tol=0.0001):
        suffix = f"{round(degrees):03d}deg"
    else:
        suffix = f"{degrees:06.2f}".rstrip('0').rstrip('.') + "deg"
    return f"{obj.name} {settings.bake_mode.title()} Bake {bake_number:03d} Angle {suffix}"


def pixels(image):
    data = np.empty(image.size[0] * image.size[1] * 4, dtype=np.float32)
    image.pixels.foreach_get(data)
    return data.reshape((image.size[1], image.size[0], 4))


def put_pixels(image, data):
    image.pixels.foreach_set(np.ascontiguousarray(data, dtype=np.float32).ravel())
    image.update()


def source_slots(obj):
    state = obj.bla_data
    if state.source_slots:
        if len(state.source_slots) != len(obj.material_slots):
            raise RuntimeError("Material slot count changed since the first bake; restore materials before changing slots")
        return [(item.material, item.link) for item in state.source_slots]
    if not obj.material_slots or any(slot.material is None for slot in obj.material_slots):
        raise RuntimeError("Every object material slot needs a material")
    return [(slot.material, slot.link) for slot in obj.material_slots]


def assign_materials(obj, materials):
    if len(materials) != len(obj.material_slots):
        raise RuntimeError("Material slot count changed")
    for slot, material in zip(obj.material_slots, materials):
        slot.link = 'OBJECT'
        slot.material = material


def restore_sources(obj):
    for slot, (material, link) in zip(obj.material_slots, source_slots(obj)):
        slot.link = 'OBJECT'
        slot.material = material
        slot.link = link


def create_bake_nodes(obj, image):
    records = []
    try:
        for material in dict.fromkeys(slot.material for slot in obj.material_slots):
            if material is None:
                raise RuntimeError("A material slot is empty")
            if not material.use_nodes:
                raise RuntimeError(f"Material '{material.name}' must use nodes")
            nodes = material.node_tree.nodes
            selection = [(node, node.select) for node in nodes]
            active = nodes.active
            node = nodes.new('ShaderNodeTexImage')
            node.name = '__BLA_BAKE_TARGET__'
            node.image = image
            records.append((nodes, node, active, selection))
            for other in nodes:
                other.select = False
            node.select = True
            nodes.active = node
            material.node_tree.update_tag()
            material.update_tag()
    except Exception:
        remove_bake_nodes(records)
        raise
    return records


def remove_bake_nodes(records):
    for nodes, node, active, selection in records:
        if nodes.get(node.name) == node:
            nodes.remove(node)
        for other, selected in selection:
            if nodes.get(other.name) == other:
                other.select = selected
        if active is not None and nodes.get(active.name) == active:
            nodes.active = active


def make_white_bake_material(image):
    material = bpy.data.materials.new('__BLA_WHITE_DIFFUSE__')
    material.use_nodes = True
    nodes = material.node_tree.nodes
    nodes.clear()
    output = nodes.new('ShaderNodeOutputMaterial')
    diffuse = nodes.new('ShaderNodeBsdfDiffuse')
    diffuse.inputs['Color'].default_value = (1, 1, 1, 1)
    tex = nodes.new('ShaderNodeTexImage')
    tex.image = image
    tex.select = True
    nodes.active = tex
    material.node_tree.links.new(diffuse.outputs['BSDF'], output.inputs['Surface'])
    return material


def ensure_preview_material(obj):
    state = obj.bla_data
    material = state.preview_material
    if material is not None and material.node_tree is not None:
        return material
    material = bpy.data.materials.new(f"BLA Preview - {obj.name}")
    material.use_nodes = True
    nodes = material.node_tree.nodes
    nodes.clear()
    output = nodes.new('ShaderNodeOutputMaterial')
    tex = nodes.new('ShaderNodeTexImage')
    tex.name = 'BLA_PAINT_IMAGE'
    tex.interpolation = 'Closest'
    emission = nodes.new('ShaderNodeEmission')
    transparent = nodes.new('ShaderNodeBsdfTransparent')
    mix = nodes.new('ShaderNodeMixShader')
    material.node_tree.links.new(tex.outputs['Color'], emission.inputs['Color'])
    material.node_tree.links.new(tex.outputs['Alpha'], mix.inputs[0])
    material.node_tree.links.new(transparent.outputs['BSDF'], mix.inputs[1])
    material.node_tree.links.new(emission.outputs['Emission'], mix.inputs[2])
    material.node_tree.links.new(mix.outputs[0], output.inputs['Surface'])
    nodes.active = tex
    state.preview_material = material
    return material


def show_frame(context, obj, index):
    state = obj.bla_data
    if len(state.frames) != FRAME_COUNT:
        raise RuntimeError("Bake all eight angles first")
    image = state.frames[index].image
    if image is None:
        raise RuntimeError(f"Image for angle {index + 1} was not found")
    material = ensure_preview_material(obj)
    tex = material.node_tree.nodes.get('BLA_PAINT_IMAGE')
    if tex is None:
        raise RuntimeError("The preview material was changed; bake again")
    tex.image = image
    for node in material.node_tree.nodes:
        node.select = node == tex
    material.node_tree.nodes.active = tex
    assign_materials(obj, [material] * len(obj.material_slots))
    state.current_angle = index
    for area in context.screen.areas if context.screen else ():
        if area.type == 'IMAGE_EDITOR':
            area.spaces.active.image = image
            area.tag_redraw()
    context.view_layer.objects.active = obj
    obj.select_set(True)


def configure_bake(scene, color=None):
    bake = scene.render.bake
    bake.target = 'IMAGE_TEXTURES'
    bake.use_selected_to_active = False
    bake.use_clear = True
    bake.margin = 2
    bake.use_cage = False
    bake.cage_extrusion = 0.0
    bake.max_ray_distance = 0.0
    bake.cage_object = None
    if color is not None:
        bake.use_pass_color = color
        bake.use_pass_direct = not color
        bake.use_pass_indirect = False


def bake_image(scene, bake_type, uv_layer, color=None):
    configure_bake(scene, color)
    if 'FINISHED' not in bpy.ops.object.bake(type=bake_type, uv_layer=uv_layer):
        raise RuntimeError("Blender cancelled the bake")


def toon_pixels(albedo, illumination, settings):
    # Same direct-diffuse principle as TextureMaker's TOON layer, with
    # several discrete levels instead of its single binary threshold.
    brightness = np.clip(
        illumination[:, :, :3].mean(axis=2) * settings.light_exposure,
        0.0, 1.0,
    )
    band = np.minimum((brightness * settings.bands).astype(np.int32), settings.bands - 1)
    levels = settings.shadow_level + (1.0 - settings.shadow_level) * band / (settings.bands - 1)
    result = np.empty_like(albedo)
    result[:, :, :3] = np.clip(albedo[:, :, :3] * levels[:, :, None], 0.0, 1.0)
    result[:, :, 3] = albedo[:, :, 3]
    return result


class BLA_OT_bake(bpy.types.Operator):
    bl_idname = 'bla.bake'
    bl_label = "Bake 8 Angles"
    bl_description = "Create eight editable UV images using the selected bake mode"
    bl_options = {'REGISTER'}

    def execute(self, context):
        settings = context.scene.bla_settings
        obj, light = settings.target, settings.light
        if obj is None or light is None:
            self.report({'ERROR'}, "Choose an object and a light")
            return {'CANCELLED'}
        if not obj.data.uv_layers.active:
            self.report({'ERROR'}, "The object needs an active UV map")
            return {'CANCELLED'}
        if settings.width * settings.height * FRAME_COUNT > 50_000_000:
            self.report({'ERROR'}, "Eight frames exceed 50 megapixels; reduce the resolution")
            return {'CANCELLED'}
        try:
            originals = source_slots(obj)
            if any(mat is None for mat, _link in originals):
                raise RuntimeError("A source material was removed")
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        scene = context.scene
        state = obj.bla_data
        old_engine = scene.render.engine
        old_samples = scene.cycles.samples
        old_world = scene.world
        old_bake = {key: getattr(scene.render.bake, key) for key in BAKE_KEYS}
        uv_name = obj.data.uv_layers.active.name
        old_render_uv = next(
            (uv.name for uv in obj.data.uv_layers if uv.active_render), None
        )
        old_light_matrix = light.matrix_world.copy()
        old_shadow = light.data.use_shadow
        other_lights = [(other, other.hide_render) for other in scene.objects if other.type == 'LIGHT' and other != light]
        old_active = context.view_layer.objects.active
        old_selected = list(context.selected_objects)
        old_mode = context.object.mode if context.object else 'OBJECT'
        old_materials = [slot.material for slot in obj.material_slots]
        old_links = [slot.link for slot in obj.material_slots]
        temporary_images = []
        new_frames = []
        old_frames = []
        previous_bake_number = state.bake_number
        replaced_frames = False
        white_material = None
        black_world = None
        committed = False
        try:
            if context.object and context.object.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            context.view_layer.objects.active = obj
            if state.source_slots:
                restore_sources(obj)
            obj.data.uv_layers[uv_name].active_render = True
            scene.render.engine = 'CYCLES'
            scene.cycles.samples = settings.samples
            if settings.bake_mode == 'TOON':
                light.data.use_shadow = False
                for other, _hidden in other_lights:
                    other.hide_render = True
                black_world = bpy.data.worlds.new('__BLA_BLACK_WORLD__')
                black_world.use_nodes = True
                background = black_world.node_tree.nodes.get('Background')
                if background:
                    background.inputs['Strength'].default_value = 0.0
                scene.world = black_world

                color_image = bpy.data.images.new('__BLA_COLOR__', settings.width, settings.height, alpha=True, float_buffer=True)
                temporary_images.append(color_image)
                records = create_bake_nodes(obj, color_image)
                try:
                    bake_image(scene, 'DIFFUSE', uv_name, color=True)
                    albedo = pixels(color_image).copy()
                finally:
                    remove_bake_nodes(records)

            if settings.bake_mode == 'TOON':
                pass_image = bpy.data.images.new('__BLA_PASS__', settings.width, settings.height, alpha=True, float_buffer=True)
                temporary_images.append(pass_image)
                white_material = make_white_bake_material(pass_image)
                assign_materials(obj, [white_material] * len(obj.material_slots))
            center = obj.matrix_world.translation.copy()
            if settings.pivot == 'BOUNDS':
                center = obj.matrix_world @ (sum((Vector(c) for c in obj.bound_box), Vector()) / 8.0)
            offset = old_light_matrix.translation - center
            for index in range(FRAME_COUNT):
                angle = settings.start_angle - math.radians(45.0 * index)
                spin = Matrix.Rotation(angle, 4, 'Z')
                rotated = spin @ old_light_matrix
                rotated.translation = center + spin.to_3x3() @ offset
                light.matrix_world = rotated
                context.view_layer.update()
                image = bpy.data.images.new(
                    f"__BLA_NEW_FRAME_{index:02d}__",
                    settings.width, settings.height, alpha=True,
                    float_buffer=(settings.bake_mode == 'CURRENT'),
                )
                new_frames.append(image)
                image.generated_color = (0.0, 0.0, 0.0, 0.0)
                if settings.bake_mode == 'TOON':
                    bake_image(scene, 'DIFFUSE', uv_name, color=False)
                    result = toon_pixels(albedo, pixels(pass_image), settings)
                    put_pixels(image, result)
                else:
                    records = create_bake_nodes(obj, image)
                    try:
                        bake_image(scene, 'COMBINED', uv_name)
                    finally:
                        remove_bake_nodes(records)
                try:
                    image.pack()
                except RuntimeError:
                    # Generated images are stored inside the blend even on
                    # Blender builds that do not allow packing them.
                    pass

            # Commit only after every bake succeeds, preserving painted frames on failure.
            if not state.source_slots:
                for material, link in originals:
                    item = state.source_slots.add()
                    item.material = material
                    item.link = link
            old_frames = [item.image for item in state.frames]
            complete_old_set = (
                len(old_frames) == FRAME_COUNT
                and all(image is not None for image in old_frames)
            )
            can_overwrite = (
                settings.overwrite and complete_old_set
                and all(image.is_float == new_frames[0].is_float for image in old_frames)
            )
            replace_format = settings.overwrite and complete_old_set and not can_overwrite
            bake_number = (
                max(state.bake_number, 1)
                if settings.overwrite and complete_old_set
                else state.bake_number + 1
            )
            if can_overwrite:
                for index, (existing, fresh) in enumerate(zip(old_frames, new_frames)):
                    if tuple(existing.size) != tuple(fresh.size):
                        existing.scale(*fresh.size)
                    put_pixels(existing, pixels(fresh))
                    existing.name = frame_name(obj, index, settings, bake_number)
                    try:
                        existing.pack()
                    except RuntimeError:
                        pass
            else:
                if not replace_format:
                    for image in old_frames:
                        if image is not None:
                            image.use_fake_user = True
                state.frames.clear()
                replaced_frames = True
                for image in new_frames:
                    state.frames.add().image = image
            state.bake_number = bake_number
            show_frame(context, obj, 0)
            committed = True
            if can_overwrite:
                for image in new_frames:
                    bpy.data.images.remove(image)
            else:
                if replace_format:
                    for image in old_frames:
                        if image and image.users == 0:
                            bpy.data.images.remove(image)
                for index, image in enumerate(new_frames):
                    image.name = frame_name(obj, index, settings, bake_number)
            self.report({'INFO'}, "Eight editable angles are ready. Paint the frames, then click Generate.")
            return {'FINISHED'}
        except Exception as exc:
            traceback.print_exc()
            self.report({'ERROR'}, f"Bake failed: {exc}")
            return {'CANCELLED'}
        finally:
            if not committed:
                if replaced_frames:
                    state.frames.clear()
                    for image in old_frames:
                        state.frames.add().image = image
                    state.bake_number = previous_bake_number
                for slot, material, link in zip(obj.material_slots, old_materials, old_links):
                    slot.link = 'OBJECT'
                    slot.material = material
                    slot.link = link
                for image in new_frames:
                    if image.name in bpy.data.images:
                        bpy.data.images.remove(image)
            for image in temporary_images:
                if image.name in bpy.data.images:
                    bpy.data.images.remove(image)
            if white_material:
                bpy.data.materials.remove(white_material)
            light.matrix_world = old_light_matrix
            light.data.use_shadow = old_shadow
            for other, hidden in other_lights:
                other.hide_render = hidden
            scene.world = old_world
            if black_world:
                bpy.data.worlds.remove(black_world)
            scene.render.engine = old_engine
            scene.cycles.samples = old_samples
            for key, value in old_bake.items():
                setattr(scene.render.bake, key, value)
            if old_render_uv and old_render_uv in obj.data.uv_layers:
                obj.data.uv_layers[old_render_uv].active_render = True
            bpy.ops.object.select_all(action='DESELECT')
            for selected in old_selected:
                if selected.name in bpy.data.objects:
                    selected.select_set(True)
            if old_active and old_active.name in bpy.data.objects:
                context.view_layer.objects.active = old_active
            if old_mode != 'OBJECT' and old_active and old_active.name in bpy.data.objects:
                try:
                    bpy.ops.object.mode_set(mode=old_mode)
                except Exception:
                    pass


class BLA_OT_change_angle(bpy.types.Operator):
    bl_idname = 'bla.change_angle'
    bl_label = "Change Angle"
    bl_description = "Show another frame for painting in Texture Paint"
    direction: IntProperty(default=1)

    def execute(self, context):
        obj = context.scene.bla_settings.target
        if obj is None:
            return {'CANCELLED'}
        try:
            show_frame(context, obj, (obj.bla_data.current_angle + self.direction) % FRAME_COUNT)
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


class BLA_OT_generate(bpy.types.Operator):
    bl_idname = 'bla.generate'
    bl_label = "Generate"
    bl_description = "Build a PNG sprite sheet from the eight frames, including manual paint"
    bl_options = {'REGISTER'}

    def execute(self, context):
        settings = context.scene.bla_settings
        obj = settings.target
        if obj is None or len(obj.bla_data.frames) != FRAME_COUNT:
            self.report({'ERROR'}, "Bake all eight angles first")
            return {'CANCELLED'}
        images = [item.image for item in obj.bla_data.frames]
        if any(image is None for image in images):
            self.report({'ERROR'}, "One or more frame images are missing")
            return {'CANCELLED'}
        width, height = images[0].size
        if any(tuple(image.size) != (width, height) for image in images):
            self.report({'ERROR'}, "All frames must have the same resolution")
            return {'CANCELLED'}
        cols = int(settings.columns)
        rows = FRAME_COUNT // cols
        if width * height * FRAME_COUNT > 50_000_000:
            self.report({'ERROR'}, "The sprite sheet exceeds 50 megapixels")
            return {'CANCELLED'}
        path = bpy.path.abspath(settings.output)
        if not path.lower().endswith('.png'):
            path += '.png'
        if not os.path.isdir(os.path.dirname(path)):
            self.report({'ERROR'}, "The output folder does not exist")
            return {'CANCELLED'}
        atlas_image = None
        render_format = context.scene.render.image_settings.file_format
        render_color_mode = context.scene.render.image_settings.color_mode
        render_color_depth = context.scene.render.image_settings.color_depth
        try:
            atlas = np.zeros((height * rows, width * cols, 4), dtype=np.float32)
            for index, image in enumerate(images):
                col = index % cols
                row_from_bottom = rows - 1 - index // cols
                atlas[row_from_bottom * height:(row_from_bottom + 1) * height,
                      col * width:(col + 1) * width] = pixels(image)
            atlas_image = bpy.data.images.new(
                f"{obj.name} Toon Sprite Sheet", width * cols, height * rows,
                alpha=True, float_buffer=images[0].is_float,
            )
            put_pixels(atlas_image, atlas)
            atlas_image.filepath_raw = path
            atlas_image.file_format = 'PNG'
            if images[0].is_float:
                # View transform HDR Combined pixels once when making a PNG.
                output = context.scene.render.image_settings
                output.file_format = 'PNG'
                output.color_mode = 'RGBA'
                output.color_depth = '8'
                atlas_image.save_render(path, scene=context.scene)
            else:
                atlas_image.save()
            self.report({'INFO'}, f"Sprite sheet saved: {path}")
            return {'FINISHED'}
        except Exception as exc:
            traceback.print_exc()
            self.report({'ERROR'}, f"Generate failed: {exc}")
            return {'CANCELLED'}
        finally:
            output = context.scene.render.image_settings
            output.file_format = render_format
            output.color_mode = render_color_mode
            output.color_depth = render_color_depth
            if atlas_image:
                bpy.data.images.remove(atlas_image)


class BLA_OT_restore_materials(bpy.types.Operator):
    bl_idname = 'bla.restore_materials'
    bl_label = "Restore Materials"
    bl_description = "Disable the preview and restore the source materials"

    def execute(self, context):
        obj = context.scene.bla_settings.target
        if obj is None or not obj.bla_data.source_slots:
            return {'CANCELLED'}
        try:
            restore_sources(obj)
            self.report({'INFO'}, "Source materials restored; frames retained")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


class BLA_PT_main(bpy.types.Panel):
    bl_label = "Bake Light Angles"
    bl_idname = 'BLA_PT_main'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Bake Light Angles'

    def draw(self, context):
        layout = self.layout
        settings = context.scene.bla_settings
        layout.prop(settings, 'target')
        layout.prop(settings, 'light')
        layout.prop(settings, 'bake_mode')
        row = layout.row(align=True)
        row.prop(settings, 'width')
        row.prop(settings, 'height')
        layout.prop(settings, 'samples')
        layout.prop(settings, 'pivot')
        layout.prop(settings, 'start_angle')
        if settings.bake_mode == 'TOON':
            layout.prop(settings, 'bands')
            layout.prop(settings, 'shadow_level')
            layout.prop(settings, 'light_exposure')
        layout.prop(settings, 'overwrite')
        layout.operator('bla.bake', icon='RENDER_STILL')
        obj = settings.target
        if obj and len(obj.bla_data.frames) == FRAME_COUNT:
            box = layout.box()
            box.label(text="Paint in Texture Paint")
            row = box.row(align=True)
            row.operator('bla.change_angle', text="", icon='TRIA_LEFT').direction = -1
            row.label(text=f"Angle {obj.bla_data.current_angle + 1} / 8")
            row.operator('bla.change_angle', text="", icon='TRIA_RIGHT').direction = 1
            image = obj.bla_data.frames[obj.bla_data.current_angle].image
            if image:
                box.label(text=image.name, icon='IMAGE_DATA')
            box.operator('bla.restore_materials', icon='MATERIAL')
        layout.separator()
        layout.prop(settings, 'columns')
        layout.prop(settings, 'output')
        layout.operator('bla.generate', icon='IMAGE_DATA')


CLASSES = (
    BLA_SourceSlot, BLA_Frame, BLA_ObjectData, BLA_Settings,
    BLA_OT_bake, BLA_OT_change_angle, BLA_OT_generate,
    BLA_OT_restore_materials, BLA_PT_main,
)


@persistent
def pack_painted_frames(_scene):
    # Painting can make a previously packed image dirty. Refresh the packed
    # copy before Blender writes the .blend file.
    for obj in bpy.data.objects:
        state = getattr(obj, 'bla_data', None)
        if state is None:
            continue
        for frame in state.frames:
            image = frame.image
            if image is not None and image.is_dirty:
                try:
                    image.pack()
                except RuntimeError:
                    pass


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Object.bla_data = PointerProperty(type=BLA_ObjectData)
    bpy.types.Scene.bla_settings = PointerProperty(type=BLA_Settings)
    if pack_painted_frames not in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.append(pack_painted_frames)


def unregister():
    if pack_painted_frames in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.remove(pack_painted_frames)
    del bpy.types.Scene.bla_settings
    del bpy.types.Object.bla_data
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == '__main__':
    register()
