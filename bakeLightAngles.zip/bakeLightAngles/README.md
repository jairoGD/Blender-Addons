# Bake Light Angles

Addon para Blender 4.5+. Instale a pasta `bakeLightAngles` como extension/addon local ou copie a pasta para o diretorio de addons do Blender. Nao precisa compactar.

## Uso

1. Abra **View3D > Sidebar > Bake Light Angles**.
2. Escolha uma malha com UV map ativo e materiais com nodes, e a luz que deve girar.
3. Escolha **Bake Mode**: **Toon Shader** ou **Current**. Ajuste resolucao e amostras; as opcoes de faixas, sombra e exposicao aparecem apenas para Toon Shader. Clique **Bake 8 Angles**.
4. O addon guarda oito imagens separadas no `.blend` e aplica um material de preview ao objeto. Entre em **Texture Paint**. Use as setas no painel para mudar a imagem ativa; cada frame tambem aparece no Image Editor, se ele estiver aberto.
5. Salve o `.blend` para conservar as pinturas. Escolha a disposicao das colunas e o caminho PNG, depois clique **Generate**. Voce pode pintar mais e clicar **Generate** de novo sem refazer o bake.

O primeiro frame usa o angulo inicial. Os seguintes giram a luz em passos de 45 graus no sentido horario, vistos de cima, em torno do eixo Z global. Os nomes terminam com o angulo em graus, por exemplo `Toon Bake 001 Angle 000deg` e `Toon Bake 001 Angle 315deg`. O atlas coloca o frame 1 no canto superior esquerdo e segue da esquerda para a direita.

**Toon Shader** usa a cor difusa dos materiais de origem e a iluminacao difusa direta de uma unica luz, sem sombras projetadas nem iluminacao do mundo. A intensidade da luz e dividida em faixas e multiplicada pela cor original.

**Current** usa o bake **Combined** dos materiais de origem aplicados ao objeto em cada angulo, seguindo a preparacao de materiais e UV do TextureMaker. Os frames desse modo usam imagens em ponto flutuante para preservar luzes mais intensas que 1.0; ao usar **Generate**, o PNG recebe a transformacao de cor da cena. Este modo conserva os passes de bake configurados na cena, o mundo, as outras luzes e as sombras; so a luz escolhida gira. A opcao **Restore Materials** recupera os materiais de origem sem apagar os frames.

O bake UV nao tem a mesma direcao de visao de uma camera; efeitos dependentes da camera, como Fresnel e alguns reflexos, podem diferir do render.

**Overwrite** vem ativado: repetir **Bake 8 Angles** atualiza as mesmas oito imagens, preservando seus datablocks e substituindo as pinturas anteriores. Desative **Overwrite** para criar outro conjunto; as imagens antigas continuam guardadas no `.blend` com o numero do bake em seus nomes. Se os slots ou materiais de origem mudarem, restaure os materiais antes de alterar a malha e refaca o bake.
