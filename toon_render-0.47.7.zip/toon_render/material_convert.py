"""Convert deliberately simple Blender Principled materials into Toon nodes."""

import bpy

from . import toon_nodes


_INPUTS = {
    'Base Color': 'Color',
    'Metallic': 'Metalness',
    'Roughness': 'Roughness',
    'Alpha': 'Alpha',
    'Emission Color': 'Emissive',
}


class UnsupportedMaterial(ValueError):
    pass


def _source_link(socket):
    link = socket.links[0] if socket and socket.is_linked else None
    visited = set()
    while link and link.from_node.bl_idname == 'NodeReroute':
        node = link.from_node
        if node.as_pointer() in visited:
            raise UnsupportedMaterial('ciclo de Reroute')
        visited.add(node.as_pointer())
        link = node.inputs[0].links[0] if node.inputs[0].is_linked else None
    return link


def _uv_chain(socket):
    link = _source_link(socket)
    if link is None:
        return None
    source = link.from_node
    if source.bl_idname == 'ShaderNodeUVMap' and link.from_socket.name == 'UV':
        if source.from_instancer:
            raise UnsupportedMaterial('UV Map de instância não suportado')
        return None, source.uv_map
    if source.bl_idname == 'ShaderNodeTexCoord' and link.from_socket.name == 'UV':
        return None, ''
    if source.bl_idname != 'ShaderNodeMapping' or link.from_socket.name != 'Vector':
        raise UnsupportedMaterial('cadeia Vector da textura não suportada')
    if source.vector_type != 'POINT':
        raise UnsupportedMaterial('Mapping precisa estar no modo Point')
    for name in ('Location', 'Rotation', 'Scale'):
        if _source_link(source.inputs.get(name)):
            raise UnsupportedMaterial(f'Mapping {name} conectado a outro node')
    inner = _uv_chain(source.inputs.get('Vector'))
    if inner is None or inner[0] is not None:
        raise UnsupportedMaterial('Mapping precisa receber UV Map ou Texture Coordinate UV')
    return source, inner[1]


def _image_source(link):
    if link is None:
        return None
    node = link.from_node
    if node.bl_idname != 'ShaderNodeTexImage' or link.from_socket.name not in {'Color', 'Alpha'}:
        raise UnsupportedMaterial('entrada ligada a node diferente de Image Texture')
    _validate_image(node)
    return node


def _validate_image(node):
    if node.image is None:
        raise UnsupportedMaterial('Image Texture sem imagem')
    if node.projection != 'FLAT' or node.extension not in {'REPEAT', 'CLIP'}:
        raise UnsupportedMaterial('projeção ou extensão da textura sem equivalente')
    if node.interpolation != 'Linear':
        raise UnsupportedMaterial('interpolação da textura sem equivalente')
    _uv_chain(node.inputs.get('Vector'))


def _upstream_images(link):
    """Find image nodes that contribute to a socket, without following UV inputs."""
    found = []
    visited = set()

    def visit(current):
        if current is None:
            return
        node = current.from_node
        pointer = node.as_pointer()
        if pointer in visited:
            return
        visited.add(pointer)
        if node.bl_idname == 'ShaderNodeTexImage':
            found.append(node)
            return
        for socket in node.inputs:
            if socket.name == 'Vector':
                continue
            visit(_source_link(socket))

    visit(link)
    return found


def _analyze(source):
    if source.toon_tree:
        raise UnsupportedMaterial('já possui material Toon')
    if not source.use_nodes or source.node_tree is None:
        raise UnsupportedMaterial('não usa nodes')
    outputs = [node for node in source.node_tree.nodes
               if node.bl_idname == 'ShaderNodeOutputMaterial' and node.is_active_output]
    if len(outputs) != 1:
        raise UnsupportedMaterial('Material Output ativo ausente ou ambíguo')
    output = outputs[0]
    output_link = _source_link(output.inputs.get('Surface'))
    if not output_link or output_link.from_node.bl_idname != 'ShaderNodeBsdfPrincipled':
        raise UnsupportedMaterial('Surface não recebe Principled BSDF diretamente')
    if output_link.from_socket.name != 'BSDF':
        raise UnsupportedMaterial('saída de shader não suportada')
    if _source_link(output.inputs.get('Volume')) or _source_link(output.inputs.get('Displacement')):
        raise UnsupportedMaterial('Volume ou Displacement conectado')
    principled = output_link.from_node
    normal = None
    images = {}
    supported = set(_INPUTS)
    notes = []
    base_color_image = None
    base_color_link = _source_link(principled.inputs.get('Base Color'))
    for candidate in _upstream_images(base_color_link):
        try:
            _validate_image(candidate)
            base_color_image = candidate
            break
        except UnsupportedMaterial as exc:
            notes.append(f'{candidate.name}: {exc}')
    for socket in principled.inputs:
        link = _source_link(socket)
        if not link:
            continue
        if socket.name in _INPUTS:
            if socket.name == 'Base Color':
                if base_color_image:
                    images[base_color_image.as_pointer()] = base_color_image
                    if link.from_node != base_color_image:
                        notes.append('Base Color: nodes intermediários não reproduzidos')
                else:
                    supported.discard(socket.name)
                    notes.append('Base Color: cadeia sem Image Texture; usada cor padrão')
                continue
            try:
                image = _image_source(link)
                images[image.as_pointer()] = image
            except UnsupportedMaterial as exc:
                supported.discard(socket.name)
                notes.append(f'{socket.name}: {exc}')
        elif socket.name == 'Normal':
            try:
                if (link.from_node.bl_idname != 'ShaderNodeNormalMap'
                        or link.from_socket.name != 'Normal'):
                    raise UnsupportedMaterial('Normal não recebe Normal Map diretamente')
                normal = link.from_node
                if _source_link(normal.inputs.get('Normal')):
                    raise UnsupportedMaterial('Normal Map encadeado a outro normal')
                image = _image_source(_source_link(normal.inputs.get('Color')))
                if image:
                    images[image.as_pointer()] = image
                if _source_link(normal.inputs.get('Strength')):
                    raise UnsupportedMaterial('Strength do Normal Map conectado')
            except UnsupportedMaterial as exc:
                normal = None
                notes.append(f'Normal: {exc}')
        else:
            notes.append(f'{socket.name}: node não suportado')
    emission_strength = principled.inputs.get('Emission Strength')
    if emission_strength and _source_link(emission_strength):
        supported.discard('Emission Color')
        notes.append('Emission Strength conectado: emissão ignorada')
    elif emission_strength and emission_strength.default_value not in {0.0, 1.0}:
        supported.discard('Emission Color')
        notes.append('Emission Strength sem equivalente: emissão ignorada')
    for candidate in source.node_tree.nodes:
        if candidate.bl_idname != 'ShaderNodeTexImage' or candidate.as_pointer() in images:
            continue
        try:
            _validate_image(candidate)
            images[candidate.as_pointer()] = candidate
        except UnsupportedMaterial as exc:
            notes.append(f'{candidate.name}: {exc}')
    return principled, normal, tuple(images.values()), supported, notes, base_color_image


def _convert(source, analysis):
    principled, normal, images, supported, _notes, base_color_image = analysis
    tree = bpy.data.node_groups.new(source.name + ' Toon', toon_nodes.ToonNodeTree.bl_idname)
    material = bpy.data.materials.new(source.name + ' Toon')
    try:
        material.toon_tree = tree
        nodes = tree.nodes
        surface = nodes.new('ToonSurfaceNode')
        surface.location = (0, 0)
        output = nodes.new('ToonMaterialOutputNode')
        output.location = (280, 0)
        tree.links.new(surface.outputs['Shader'], output.inputs['Surface'])
        converted_images = {}
        for index, image_node in enumerate(images):
            texture = nodes.new('ToonImageTextureNode')
            texture.location = (-560, -260 * index)
            texture.image = image_node.image
            texture.extension = 'TILE' if image_node.extension == 'REPEAT' else 'CLIP'
            uv_chain = _uv_chain(image_node.inputs.get('Vector'))
            if uv_chain:
                mapping_source, uv_name = uv_chain
                uv = nodes.new('ToonUVNode')
                uv.location = (-1080 if mapping_source else -820, -260 * index)
                uv.uv_map = uv_name
                if mapping_source:
                    mapping = nodes.new('ToonMappingNode')
                    mapping.location = (-820, -260 * index)
                    mapping.mapping_type = 'UV'
                    mapping.mapping_location = tuple(mapping_source.inputs['Location'].default_value)
                    mapping.mapping_rotation = tuple(mapping_source.inputs['Rotation'].default_value)
                    mapping.mapping_scale = tuple(mapping_source.inputs['Scale'].default_value)
                    tree.links.new(uv.outputs['UV'], mapping.inputs['Vector'])
                    tree.links.new(mapping.outputs['Vector'], texture.inputs['Vector'])
                else:
                    tree.links.new(uv.outputs['UV'], texture.inputs['Vector'])
            converted_images[image_node.as_pointer()] = texture

        def copy_input(source_socket, target_socket):
            link = _source_link(source_socket)
            if link:
                texture = converted_images[link.from_node.as_pointer()]
                tree.links.new(texture.outputs[link.from_socket.name], target_socket)
            elif source_socket is not None:
                target_socket.default_value = source_socket.default_value

        emission_strength = principled.inputs.get('Emission Strength')
        for source_name, target_name in _INPUTS.items():
            source_socket = principled.inputs.get(source_name)
            if source_name == 'Base Color' and base_color_image:
                texture = converted_images[base_color_image.as_pointer()]
                tree.links.new(texture.outputs['Color'], surface.inputs['Color'])
                continue
            if source_name not in supported:
                if source_name != 'Emission Color' and source_socket is not None:
                    surface.inputs[target_name].default_value = source_socket.default_value
                continue
            if (source_name == 'Emission Color' and emission_strength
                    and emission_strength.default_value == 0.0):
                continue
            if source_socket is not None:
                copy_input(source_socket, surface.inputs[target_name])
        if emission_strength and emission_strength.default_value == 0.0:
            surface.inputs['Emissive'].default_value = (0.0, 0.0, 0.0, 1.0)
        if normal:
            toon_normal = nodes.new('ToonNormalMapNode')
            toon_normal.location = (-270, -620)
            toon_normal.space = normal.space
            toon_normal.uv_map = normal.uv_map
            toon_normal.inputs['Strength'].default_value = normal.inputs['Strength'].default_value
            copy_input(normal.inputs['Color'], toon_normal.inputs['Color'])
            tree.links.new(toon_normal.outputs['Normal'], surface.inputs['Normal'])
        if hasattr(source, 'use_backface_culling'):
            material.toon_double_sided = not source.use_backface_culling
        material.diffuse_color = tuple(source.diffuse_color)
        return material
    except Exception:
        bpy.data.materials.remove(material)
        bpy.data.node_groups.remove(tree)
        raise


class TOON_OT_convert_materials(bpy.types.Operator):
    bl_idname = 'toon_render.convert_materials'
    bl_label = 'Convert Materials to Toon Render'
    bl_description = 'Convert simple Principled materials used by mesh objects in this scene'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene is not None

    def execute(self, context):
        slots = [slot for obj in context.scene.objects if obj.type == 'MESH'
                 for slot in obj.material_slots if slot.material]
        sources = {slot.material.as_pointer(): slot.material for slot in slots
                   if not slot.material.toon_tree}
        converted = {}
        skipped = {}
        partial = {}
        for pointer, source in sources.items():
            try:
                analysis = _analyze(source)
                converted[pointer] = _convert(source, analysis)
                if analysis[-2]:
                    partial[source.name] = ', '.join(analysis[-2])
            except (UnsupportedMaterial, AttributeError, ValueError) as exc:
                skipped[source.name] = str(exc)
        assigned = 0
        for slot in slots:
            replacement = converted.get(slot.material.as_pointer())
            if replacement:
                try:
                    slot.material = replacement
                    assigned += 1
                except (AttributeError, RuntimeError) as exc:
                    skipped[replacement.name] = f'não foi possível atribuir ao slot: {exc}'
        for name, reason in list(skipped.items())[:10]:
            self.report({'WARNING'}, f'{name}: {reason}')
        for name, reason in list(partial.items())[:10]:
            self.report({'WARNING'}, f'{name}: conversão parcial; {reason}')
        self.report({'INFO'},
                    f'{len(converted)} material(is) convertido(s), {assigned} slot(s) atualizado(s), '
                    f'{len(partial)} parcial(is), {len(skipped)} ignorado(s)')
        toon_nodes._tag_viewports()
        return {'FINISHED'}


class VIEW3D_MT_toon_render(bpy.types.Menu):
    bl_idname = 'VIEW3D_MT_toon_render'
    bl_label = 'Toon Render'

    def draw(self, _context):
        self.layout.operator(TOON_OT_convert_materials.bl_idname,
                             text='Convert Materials to Toon Render')


def _draw_view3d_menu(self, _context):
    self.layout.menu(VIEW3D_MT_toon_render.bl_idname)


def register():
    bpy.utils.register_class(TOON_OT_convert_materials)
    bpy.utils.register_class(VIEW3D_MT_toon_render)
    bpy.types.VIEW3D_MT_editor_menus.append(_draw_view3d_menu)


def unregister():
    bpy.types.VIEW3D_MT_editor_menus.remove(_draw_view3d_menu)
    bpy.utils.unregister_class(VIEW3D_MT_toon_render)
    bpy.utils.unregister_class(TOON_OT_convert_materials)
