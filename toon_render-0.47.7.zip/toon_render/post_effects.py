"""World-owned post-processing stack and its first screen-space effect."""

import bpy
from bpy_extras import view3d_utils


def _redraw(_self=None, _context=None):
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def _ao_quality_changed(effect, context):
    presets = {'PERFORMANCE': (24, 50), 'BALANCE': (32, 75),
               'QUALITY': (64, 100)}
    effect.ao_samples, effect.ao_resolution = presets[effect.ao_quality]
    _redraw(effect, context)


class ToonOutlineMaterial(bpy.types.PropertyGroup):
    material: bpy.props.PointerProperty(
        name='Material', type=bpy.types.Material, update=_redraw)


class ToonPostEffect(bpy.types.PropertyGroup):
    effect_type: bpy.props.EnumProperty(
        name='Effect', items=(('OUTLINE', 'Outline / Lineart', ''),
                              ('MOSAIC', 'Mosaic', 'Pixelated mosaic effect'),
                              ('COLOR_ADJUST', 'Color Adjust', 'Adjust the final image color'),
                              ('BLOOM', 'Bloom', 'Glow from emissive Toon Surface materials'),
                              ('AO', 'Ambient Occlusion', 'Screen-space ambient occlusion'),
                              ('TRANSMISSION', 'Color Transmission',
                               'Mix bright nearby surface colors into contact areas')),
        default='OUTLINE', update=_redraw)
    enabled: bpy.props.BoolProperty(name='Enabled', default=True, update=_redraw)
    color: bpy.props.FloatVectorProperty(
        name='Color', subtype='COLOR', size=3, min=0.0, max=1.0,
        default=(0.0, 0.0, 0.0), update=_redraw)
    thickness: bpy.props.FloatProperty(
        name='Thickness', description='Outline width in pixels',
        default=1.0, min=0.5, max=12.0, update=_redraw)
    depth_threshold: bpy.props.FloatProperty(
        name='Depth Threshold', description='Relative depth change needed for a line',
        default=0.1, min=0.001, max=1.0, precision=3, update=_redraw)
    normal_threshold: bpy.props.FloatProperty(
        name='Normal Threshold', description='Normal direction change needed for a line',
        default=0.25, min=0.0, max=2.0, precision=3, update=_redraw)
    opacity: bpy.props.FloatProperty(
        name='Opacity', subtype='FACTOR', default=1.0,
        min=0.0, max=1.0, update=_redraw)
    pixel_size: bpy.props.IntProperty(
        name='Pixel Size', description='Mosaic cell width and height in pixels',
        default=16, min=1, max=256, update=_redraw)
    adjust_brightness: bpy.props.FloatProperty(
        name='Brightness', description='Add or subtract brightness from all color channels',
        default=0.0, min=-1.0, max=1.0, update=_redraw)
    adjust_contrast: bpy.props.FloatProperty(
        name='Contrast', description='Contrast around middle gray; 1 leaves it unchanged',
        default=1.0, min=0.0, max=3.0, update=_redraw)
    adjust_saturation: bpy.props.FloatProperty(
        name='Saturation', description='Color intensity; 0 makes the image grayscale',
        default=1.0, min=0.0, max=3.0, update=_redraw)
    adjust_luminance: bpy.props.FloatProperty(
        name='Luminance', description='Multiply scene-linear luminance; 1 leaves it unchanged',
        default=1.0, min=0.0, max=4.0, update=_redraw)
    adjust_gamma: bpy.props.FloatProperty(
        name='Gamma', description='Adjust midtone brightness; 1 leaves it unchanged',
        default=1.0, min=0.1, max=4.0, update=_redraw)
    adjust_tint: bpy.props.FloatProperty(
        name='Tint', subtype='FACTOR',
        description='Strength of the color tint applied to the final image',
        default=0.0, min=0.0, max=1.0, update=_redraw)
    adjust_tint_color: bpy.props.FloatVectorProperty(
        name='Tint Color', subtype='COLOR', size=3, min=0.0, max=1.0,
        default=(1.0, 1.0, 1.0), update=_redraw)
    adjust_tint_mode: bpy.props.EnumProperty(
        name='Tint Blend', items=(
            ('MIX', 'Mix', 'Mix the image with the tint color'),
            ('MULTIPLY', 'Multiply', 'Multiply image and tint'),
            ('OVERLAY', 'Overlay', 'Increase contrast using the tint'),
            ('BURN', 'Color Burn', 'Darken image using the tint'),
            ('DODGE', 'Color Dodge', 'Brighten image using the tint'),
            ('ADD', 'Add', 'Add tint color'),
            ('SCREEN', 'Screen', 'Screen blend'),
            ('SOFT_LIGHT', 'Soft Light', 'Softly lighten or darken'),
            ('HARD_LIGHT', 'Hard Light', 'Contrast using tint brightness'),
            ('DIFFERENCE', 'Difference', 'Absolute difference between colors'),
            ('SUBTRACT', 'Subtract', 'Subtract tint color')),
        default='MULTIPLY', update=_redraw)
    bloom_threshold: bpy.props.FloatProperty(
        name='Threshold', description='Minimum emissive brightness that produces glow',
        default=0.05, min=0.0, soft_max=2.0, update=_redraw)
    bloom_radius: bpy.props.FloatProperty(
        name='Radius', description='Glow spread in screen pixels',
        default=24.0, min=1.0, max=1024.0, soft_max=128.0,
        update=_redraw)
    bloom_strength: bpy.props.FloatProperty(
        name='Strength', description='Amount of glow added to the image',
        default=1.0, min=0.0, soft_max=5.0, update=_redraw)
    bloom_resolution: bpy.props.IntProperty(
        name='Resolution', subtype='PERCENTAGE',
        description='Resolution of the emissive pass; lower values are faster and softer',
        default=75, min=25, max=100, update=_redraw)
    ao_quality: bpy.props.EnumProperty(
        name='Quality Preset',
        items=(('PERFORMANCE', 'Performance', '24 samples at 50% resolution'),
               ('BALANCE', 'Balance', '32 samples at 75% resolution'),
               ('QUALITY', 'Quality', '64 samples at full resolution')),
        default='BALANCE', update=_ao_quality_changed)
    ao_samples: bpy.props.IntProperty(
        name='Samples', description='Depth and normal samples per AO pixel',
        default=32, min=4, max=64, update=_redraw)
    ao_resolution: bpy.props.IntProperty(
        name='Resolution', subtype='PERCENTAGE',
        description='Resolution of the ambient occlusion pass',
        default=75, min=25, max=100, update=_redraw)
    ao_radius: bpy.props.FloatProperty(
        name='Radius', description='Occlusion radius in Blender world units',
        default=0.6, min=0.01, soft_max=5.0, update=_redraw)
    ao_strength: bpy.props.FloatProperty(
        name='Strength', description='Intensity of the contact occlusion',
        default=0.6, min=0.0, soft_max=4.0, update=_redraw)
    ao_bias: bpy.props.FloatProperty(
        name='Bias', description='Suppress self-occlusion on nearly flat surfaces',
        default=0.25, min=0.0, max=0.6, update=_redraw)
    ao_denoise: bpy.props.BoolProperty(
        name='Edge-Aware Denoise', default=True, update=_redraw)
    ao_cavity_type: bpy.props.EnumProperty(
        name='Cavity Type',
        items=(('WORLD', 'World', 'Scene-scale cavity from depth and normals'),
               ('SCREEN', 'Screen', 'Fast local curvature from neighboring normals'),
               ('BOTH', 'Both', 'Combine world cavity and screen curvature')),
        default='WORLD', update=_redraw)
    ao_world_ridge: bpy.props.FloatProperty(
        name='Ridge', default=1.0, min=0.0, soft_max=4.0, update=_redraw)
    ao_world_valley: bpy.props.FloatProperty(
        name='Valley', default=1.0, min=0.0, soft_max=4.0, update=_redraw)
    ao_screen_ridge: bpy.props.FloatProperty(
        name='Ridge', default=1.0, min=0.0, soft_max=4.0, update=_redraw)
    ao_screen_valley: bpy.props.FloatProperty(
        name='Valley', default=1.0, min=0.0, soft_max=4.0, update=_redraw)
    ao_color: bpy.props.FloatVectorProperty(
        name='AO Color', subtype='COLOR', size=3, min=0.0, max=1.0,
        default=(0.0, 0.0, 0.0), update=_redraw)
    transmission_strength: bpy.props.FloatProperty(
        name='Transmission Strength', subtype='FACTOR',
        description='Amount of bright nearby color mixed with the receiving surface',
        default=0.35, min=0.0, max=1.0, update=_redraw)
    transmission_blend_mode: bpy.props.EnumProperty(
        name='Blend Mode',
        items=(('MIX', 'Mix', 'Interpolate toward the nearby face color'),
               ('ADD', 'Additive', 'Add nearby face color to the receiving face'),
               ('SCREEN', 'Screen', 'Brighten by combining both face colors'),
               ('OVERLAY', 'Overlay', 'Blend colors according to the receiving face brightness')),
        default='OVERLAY', update=_redraw)
    occlusion_alpha_threshold: bpy.props.FloatProperty(
        name='Occlusion Alpha Threshold', subtype='FACTOR',
        description='Blend and Additive surfaces below this alpha do not hide geometry behind them in the effect mask',
        default=0.5, min=0.0, max=1.0, update=_redraw)
    limit_to_materials: bpy.props.BoolProperty(
        name='Limit to Materials', default=False, update=_redraw,
        description='Apply this effect only to the selected materials')
    invert_materials: bpy.props.BoolProperty(
        name='Invert', default=False, update=_redraw,
        description='Apply this effect to every material except the selected ones')
    materials: bpy.props.CollectionProperty(type=ToonOutlineMaterial)
    material_index: bpy.props.IntProperty(default=0)


class TOON_UL_post_effects(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname, index):
        row = layout.row(align=True)
        row.prop(item, 'enabled', text='')
        labels = {'MOSAIC': ('Mosaic', 'TEXTURE'),
                  'COLOR_ADJUST': ('Color Adjust', 'SHADING_RENDERED'),
                  'BLOOM': ('Bloom', 'LIGHT_SUN'),
                  'AO': ('Ambient Occlusion', 'MOD_SMOOTH'),
                  'TRANSMISSION': ('Color Transmission', 'LIGHT'),
                  'OUTLINE': ('Outline / Lineart', 'MOD_WIREFRAME')}
        label, item_icon = labels.get(item.effect_type, labels['OUTLINE'])
        row.label(text=item.name or label, icon=item_icon)


class TOON_UL_outline_materials(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname, index):
        layout.prop(item, 'material', text='', icon='MATERIAL')


def _active_effect(context):
    world = context.scene.world if context.scene else None
    if world and 0 <= world.toon_effect_index < len(world.toon_effects):
        return world.toon_effects[world.toon_effect_index]
    return None


def _append_material(effect, material):
    if material is None:
        return False
    if any(item.material == material for item in effect.materials):
        return False
    item = effect.materials.add()
    item.material = material
    effect.material_index = len(effect.materials) - 1
    effect.limit_to_materials = True
    _redraw()
    return True


def _material_from_ray(scene, depsgraph, origin, direction):
    hit, _location, _normal, face_index, obj, _matrix = scene.ray_cast(
        depsgraph, origin, direction)
    if not hit or obj is None or obj.type != 'MESH':
        return None
    evaluated = obj.evaluated_get(depsgraph)
    polygons = evaluated.data.polygons
    if face_index < 0 or face_index >= len(polygons):
        return None
    slot_index = polygons[face_index].material_index
    if slot_index >= len(obj.material_slots):
        return None
    return obj.material_slots[slot_index].material


class TOON_OT_add_outline_material(bpy.types.Operator):
    bl_idname = 'toon_render.add_outline_material'
    bl_label = 'Add Outline Material'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _active_effect(context) is not None

    def execute(self, context):
        effect = _active_effect(context)
        material = context.active_object.active_material if context.active_object else None
        if material and _append_material(effect, material):
            return {'FINISHED'}
        item = effect.materials.add()
        effect.material_index = len(effect.materials) - 1
        effect.limit_to_materials = True
        _redraw()
        return {'FINISHED'}


class TOON_OT_remove_outline_material(bpy.types.Operator):
    bl_idname = 'toon_render.remove_outline_material'
    bl_label = 'Remove Outline Material'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        effect = _active_effect(context)
        return effect is not None and len(effect.materials) > 0

    def execute(self, context):
        effect = _active_effect(context)
        effect.materials.remove(effect.material_index)
        effect.material_index = min(effect.material_index, len(effect.materials) - 1)
        _redraw()
        return {'FINISHED'}


class TOON_OT_pick_outline_material(bpy.types.Operator):
    bl_idname = 'toon_render.pick_outline_material'
    bl_label = 'Pick Outline Material'
    bl_description = 'Click a visible mesh face in the 3D View to add its material'
    bl_options = {'REGISTER', 'UNDO'}

    effect_index: bpy.props.IntProperty(options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return (_active_effect(context) is not None
                and context.window is not None
                and any(area.type == 'VIEW_3D' for area in context.window.screen.areas))

    def invoke(self, context, event):
        self.effect_index = context.scene.world.toon_effect_index
        context.window.cursor_modal_set('EYEDROPPER')
        context.window_manager.modal_handler_add(self)
        self.report({'INFO'}, 'Click a mesh face in the 3D View; Esc to cancel')
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            context.window.cursor_modal_restore()
            return {'CANCELLED'}
        if event.type != 'LEFTMOUSE' or event.value != 'PRESS':
            return {'RUNNING_MODAL'}
        for area in context.window.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            region = next((region for region in area.regions
                           if region.type == 'WINDOW'
                           and region.x <= event.mouse_x < region.x + region.width
                           and region.y <= event.mouse_y < region.y + region.height), None)
            if region is None:
                continue
            coordinates = (event.mouse_x - region.x, event.mouse_y - region.y)
            view = area.spaces.active.region_3d
            origin = view3d_utils.region_2d_to_origin_3d(region, view, coordinates)
            direction = view3d_utils.region_2d_to_vector_3d(region, view, coordinates)
            material = _material_from_ray(
                context.scene, context.evaluated_depsgraph_get(), origin, direction)
            if material is None:
                self.report({'INFO'}, 'No material found at this point')
                return {'RUNNING_MODAL'}
            world = context.scene.world
            if world and self.effect_index < len(world.toon_effects):
                _append_material(world.toon_effects[self.effect_index], material)
            context.window.cursor_modal_restore()
            return {'FINISHED'}
        return {'RUNNING_MODAL'}


class TOON_OT_add_post_effect(bpy.types.Operator):
    bl_idname = 'toon_render.add_post_effect'
    bl_label = 'Add Post Effect'
    bl_options = {'REGISTER', 'UNDO'}

    effect_type: bpy.props.EnumProperty(
        items=(('OUTLINE', 'Outline / Lineart', ''),
               ('MOSAIC', 'Mosaic', 'Pixelated mosaic effect'),
               ('COLOR_ADJUST', 'Color Adjust', 'Adjust the final image color'),
               ('BLOOM', 'Bloom', 'Glow from emissive Toon Surface materials'),
               ('AO', 'Ambient Occlusion', 'Screen-space ambient occlusion'),
               ('TRANSMISSION', 'Color Transmission',
                'Mix bright nearby surface colors into contact areas')),
        default='OUTLINE')

    @classmethod
    def poll(cls, context):
        return context.scene is not None and context.scene.world is not None

    def execute(self, context):
        world = context.scene.world
        effect = world.toon_effects.add()
        effect.effect_type = self.effect_type
        effect.name = {'MOSAIC': 'Mosaic', 'COLOR_ADJUST': 'Color Adjust',
                       'BLOOM': 'Bloom',
                       'AO': 'Ambient Occlusion',
                       'TRANSMISSION': 'Color Transmission',
                       'OUTLINE': 'Outline / Lineart'}[self.effect_type]
        world.toon_effect_index = len(world.toon_effects) - 1
        _redraw()
        return {'FINISHED'}


class TOON_OT_remove_post_effect(bpy.types.Operator):
    bl_idname = 'toon_render.remove_post_effect'
    bl_label = 'Remove Post Effect'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        world = context.scene.world if context.scene else None
        return world is not None and len(world.toon_effects) > 0

    def execute(self, context):
        world = context.scene.world
        index = min(world.toon_effect_index, len(world.toon_effects) - 1)
        world.toon_effects.remove(index)
        world.toon_effect_index = min(index, len(world.toon_effects) - 1)
        _redraw()
        return {'FINISHED'}


class TOON_OT_move_post_effect(bpy.types.Operator):
    bl_idname = 'toon_render.move_post_effect'
    bl_label = 'Move Post Effect'
    bl_options = {'REGISTER', 'UNDO'}

    direction: bpy.props.EnumProperty(items=(('UP', 'Up', ''), ('DOWN', 'Down', '')))

    @classmethod
    def poll(cls, context):
        world = context.scene.world if context.scene else None
        return world is not None and len(world.toon_effects) > 1

    def execute(self, context):
        world = context.scene.world
        old = world.toon_effect_index
        new = old + (-1 if self.direction == 'UP' else 1)
        if 0 <= old < len(world.toon_effects) and 0 <= new < len(world.toon_effects):
            world.toon_effects.move(old, new)
            world.toon_effect_index = new
            _redraw()
        return {'FINISHED'}


class TOON_MT_add_post_effects(bpy.types.Menu):
    bl_label = 'Add Post Effect'

    def draw(self, context):
        layout = self.layout
        layout.operator('toon_render.add_post_effect', text='Outline / Lineart',
                        icon='MOD_WIREFRAME').effect_type = 'OUTLINE'
        layout.operator('toon_render.add_post_effect', text='Mosaic',
                        icon='TEXTURE').effect_type = 'MOSAIC'
        layout.operator('toon_render.add_post_effect', text='Color Adjust',
                        icon='SHADING_RENDERED').effect_type = 'COLOR_ADJUST'
        layout.operator('toon_render.add_post_effect', text='Bloom',
                        icon='LIGHT_SUN').effect_type = 'BLOOM'
        layout.operator('toon_render.add_post_effect', text='Ambient Occlusion',
                        icon='MOD_SMOOTH').effect_type = 'AO'
        layout.operator('toon_render.add_post_effect', text='Color Transmission',
                        icon='LIGHT').effect_type = 'TRANSMISSION'


class TOON_PT_post_effects(bpy.types.Panel):
    bl_label = 'Toon Render Post Processing'
    bl_idname = 'TOON_PT_post_effects'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'world'
    bl_order = 1

    @classmethod
    def poll(cls, context):
        return context.scene is not None and context.scene.render.engine == 'TOON_RENDER'

    def draw(self, context):
        layout = self.layout
        world = context.scene.world
        if world is None:
            layout.label(text='Create a World to add effects', icon='INFO')
            return
        row = layout.row()
        row.template_list('TOON_UL_post_effects', '', world, 'toon_effects',
                          world, 'toon_effect_index', rows=3)
        buttons = row.column(align=True)
        buttons.operator('toon_render.remove_post_effect', text='', icon='REMOVE')
        buttons.separator()
        buttons.operator('toon_render.move_post_effect', text='', icon='TRIA_UP').direction = 'UP'
        buttons.operator('toon_render.move_post_effect', text='', icon='TRIA_DOWN').direction = 'DOWN'
        layout.menu('TOON_MT_add_post_effects', text='+ Add', icon='ADD')
        if 0 <= world.toon_effect_index < len(world.toon_effects):
            effect = world.toon_effects[world.toon_effect_index]
            box = layout.box()
            box.enabled = effect.enabled
            if effect.effect_type == 'MOSAIC':
                box.prop(effect, 'pixel_size')
            elif effect.effect_type == 'COLOR_ADJUST':
                box.prop(effect, 'adjust_brightness', slider=True)
                box.prop(effect, 'adjust_contrast', slider=True)
                box.prop(effect, 'adjust_saturation', slider=True)
                box.prop(effect, 'adjust_luminance', slider=True)
                box.prop(effect, 'adjust_gamma', slider=True)
                box.prop(effect, 'adjust_tint', slider=True)
                box.prop(effect, 'adjust_tint_color')
                box.prop(effect, 'adjust_tint_mode')
            elif effect.effect_type == 'BLOOM':
                box.prop(effect, 'bloom_threshold')
                box.prop(effect, 'bloom_radius')
                box.prop(effect, 'bloom_strength')
                box.prop(effect, 'bloom_resolution')
            elif effect.effect_type in {'AO', 'TRANSMISSION'}:
                if effect.effect_type == 'AO':
                    box.prop(effect, 'ao_cavity_type', text='Type')
                box.prop(effect, 'ao_quality')
                row = box.row(align=True)
                if (effect.effect_type == 'TRANSMISSION'
                        or effect.ao_cavity_type != 'SCREEN'):
                    row.prop(effect, 'ao_samples')
                row.prop(effect, 'ao_resolution')
                if (effect.effect_type == 'TRANSMISSION'
                        or effect.ao_cavity_type != 'SCREEN'):
                    box.prop(effect, 'ao_radius')
                box.prop(effect, 'ao_strength',
                         text='Contact Strength' if effect.effect_type == 'TRANSMISSION'
                         else 'Strength')
                if (effect.effect_type == 'TRANSMISSION'
                        or effect.ao_cavity_type != 'SCREEN'):
                    box.prop(effect, 'ao_bias',
                             text='Contact Bias' if effect.effect_type == 'TRANSMISSION'
                             else 'Bias')
                box.prop(effect, 'ao_denoise')
                if effect.effect_type == 'AO':
                    box.prop(effect, 'ao_color', text='Color')
                    if effect.ao_cavity_type in {'WORLD', 'BOTH'}:
                        row = box.row(align=True)
                        row.prop(effect, 'ao_world_ridge', text='World Ridge')
                        row.prop(effect, 'ao_world_valley', text='World Valley')
                    if effect.ao_cavity_type in {'SCREEN', 'BOTH'}:
                        row = box.row(align=True)
                        row.prop(effect, 'ao_screen_ridge', text='Screen Ridge')
                        row.prop(effect, 'ao_screen_valley', text='Screen Valley')
                else:
                    box.prop(effect, 'transmission_blend_mode')
                    box.prop(effect, 'transmission_strength', slider=True)
            else:
                box.prop(effect, 'color')
                box.prop(effect, 'thickness')
                box.prop(effect, 'depth_threshold')
                box.prop(effect, 'normal_threshold')
            box.prop(effect, 'opacity', slider=True)
            if effect.effect_type != 'BLOOM':
                row = box.row(align=True)
                row.prop(effect, 'limit_to_materials')
                inverse = row.row(align=True)
                inverse.enabled = effect.limit_to_materials
                inverse.prop(effect, 'invert_materials', text='Invert')
            if effect.effect_type in {'OUTLINE', 'AO', 'TRANSMISSION'} or effect.limit_to_materials:
                box.prop(effect, 'occlusion_alpha_threshold', slider=True,
                         text='Source Alpha Threshold'
                         if effect.effect_type == 'TRANSMISSION'
                         else 'Occlusion Alpha Threshold')
            if effect.limit_to_materials:
                row = box.row()
                row.template_list('TOON_UL_outline_materials', '', effect,
                                  'materials', effect, 'material_index', rows=3)
                buttons = row.column(align=True)
                buttons.operator('toon_render.add_outline_material', text='', icon='ADD')
                buttons.operator('toon_render.pick_outline_material', text='', icon='EYEDROPPER')
                buttons.operator('toon_render.remove_outline_material', text='', icon='REMOVE')


CLASSES = (ToonOutlineMaterial, ToonPostEffect, TOON_UL_post_effects,
           TOON_UL_outline_materials, TOON_OT_add_post_effect,
           TOON_OT_remove_post_effect, TOON_OT_move_post_effect,
           TOON_OT_add_outline_material, TOON_OT_remove_outline_material,
           TOON_OT_pick_outline_material, TOON_MT_add_post_effects,
           TOON_PT_post_effects)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.World.toon_effects = bpy.props.CollectionProperty(type=ToonPostEffect)
    bpy.types.World.toon_effect_index = bpy.props.IntProperty(default=0)


def unregister():
    del bpy.types.World.toon_effect_index
    del bpy.types.World.toon_effects
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
