"""Small raster render engine for Blender 4.5 and 5.x."""

bl_info = {
    "name": "Toon Render",
    "author": "Toon Render contributors",
    "version": (0, 47, 7),
    "blender": (4, 5, 0),
    "location": "Render Properties > Render Engine; Material Properties; Light Properties; World > Toon Render Post Processing",
    "description": "Raster renderer with Toon materials, per-light shadows and screen-space post effects",
    "category": "Render",
}

import bpy
import copy
import importlib
import inspect
import math
import numpy as np
import textwrap
from bpy.app.handlers import persistent
from mathutils import Matrix, Vector
from bl_ui import (properties_output, properties_world, properties_data_camera, properties_data_mesh,
                   properties_data_curves, properties_data_pointcloud)
from . import (toon_nodes, post_effects, shadows, toon_graph, gpu_compat,
               panorama, ambient_occlusion, color_transmission, color_adjust, bloom,
               material_convert)

# Blender can reload this package after installing a newer ZIP while leaving
# its pure-Python submodules in sys.modules. Keep the panorama shader and camera
# projection code from the same installed version as this engine module.
panorama = importlib.reload(panorama)
bloom = importlib.reload(bloom)
material_convert = importlib.reload(material_convert)

_MAX_LIGHTS = 4
_ENGINE_CHANGE_OWNER = object()
_SCENE_ENGINES = {}
_WORLD_VIEWPORT_DRAW = properties_world.WORLD_PT_viewport_display.draw
_PANORAMA_BONE_STATES = {}
_PANORAMA_BONE_KEYMAPS = []
_PANORAMA_OUTLINE_STATES = {}
_PANORAMA_EXTRAS_STATES = {}
_PANORAMA_LEGACY_VIEW_STATES = {}
_ORIGINAL_VIEW3D_HEADER_DRAW = None


def _panorama_camera_frame(context, camera):
    from bpy_extras.view3d_utils import location_3d_to_region_2d

    region = context.region
    view = context.region_data
    corners = [location_3d_to_region_2d(
        region, view, camera.matrix_world @ corner)
        for corner in camera.data.view_frame(scene=context.scene)]
    if any(corner is None for corner in corners):
        return None
    x0 = max(0, math.floor(min(corner.x for corner in corners)))
    y0 = max(0, math.floor(min(corner.y for corner in corners)))
    x1 = min(region.width, math.ceil(max(corner.x for corner in corners)))
    y1 = min(region.height, math.ceil(max(corner.y for corner in corners)))
    if x1 <= x0 or y1 <= y0:
        return None
    return x0, y0, x1 - x0, y1 - y0


def _on_camera_frame_border(x, y, frame_rect, tolerance=7):
    left, bottom, width, height = frame_rect
    right, top = left + width, bottom + height
    if not (left - tolerance <= x <= right + tolerance
            and bottom - tolerance <= y <= top + tolerance):
        return False
    return (min(abs(x - left), abs(x - right),
                abs(y - bottom), abs(y - top)) <= tolerance)


def _restore_bone_overlays():
    for space, original in tuple(_PANORAMA_BONE_STATES.values()):
        try:
            space.overlay.show_bones = original
        except ReferenceError:
            pass
    _PANORAMA_BONE_STATES.clear()
    for space, original in tuple(_PANORAMA_OUTLINE_STATES.values()):
        try:
            space.overlay.show_outline_selected = original
        except ReferenceError:
            pass
    _PANORAMA_OUTLINE_STATES.clear()
    for space, original in tuple(_PANORAMA_EXTRAS_STATES.values()):
        try:
            space.overlay.show_extras, space.overlay.show_cursor = original
        except ReferenceError:
            pass
    _PANORAMA_EXTRAS_STATES.clear()
    for space, overlays, gizmos in tuple(_PANORAMA_LEGACY_VIEW_STATES.values()):
        try:
            space.overlay.show_overlays = overlays
            space.show_gizmo = gizmos
        except ReferenceError:
            pass
    _PANORAMA_LEGACY_VIEW_STATES.clear()


def _bone_overlay_watchdog():
    if not (_PANORAMA_BONE_STATES or _PANORAMA_OUTLINE_STATES
            or _PANORAMA_EXTRAS_STATES or _PANORAMA_LEGACY_VIEW_STATES):
        return None
    live_bones = set()
    live_outlines = set()
    live_extras = set()
    live_legacy = set()
    for window in bpy.context.window_manager.windows:
        scene = window.scene
        active_object = window.view_layer.objects.active
        for area in window.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            space = area.spaces.active
            panoramic = (scene.render.engine == 'TOON_RENDER'
                         and scene.camera is not None
                         and scene.camera.data.type == 'PANO'
                         and scene.camera.data.panorama_type in {
                             'EQUIRECTANGULAR', 'FISHEYE_EQUISOLID'}
                         and space.shading.type in {'RENDERED', 'MATERIAL'}
                         and space.region_3d.view_perspective == 'CAMERA')
            if panoramic and (active_object is None or active_object.mode in {'POSE', 'OBJECT'}):
                live_bones.add(space.as_pointer())
            if panoramic and (active_object is None or active_object.mode == 'OBJECT'):
                live_outlines.add(space.as_pointer())
            if panoramic:
                live_extras.add(space.as_pointer())
                if bpy.app.version < (5, 0, 0):
                    live_legacy.add(space.as_pointer())
    for key, (space, original) in tuple(_PANORAMA_BONE_STATES.items()):
        if key not in live_bones:
            try:
                space.overlay.show_bones = original
            except ReferenceError:
                pass
            _PANORAMA_BONE_STATES.pop(key, None)
        elif space.overlay.show_bones:
            space.overlay.show_bones = False
    for key, (space, original) in tuple(_PANORAMA_OUTLINE_STATES.items()):
        if key not in live_outlines:
            try:
                space.overlay.show_outline_selected = original
            except ReferenceError:
                pass
            _PANORAMA_OUTLINE_STATES.pop(key, None)
        elif space.overlay.show_outline_selected:
            space.overlay.show_outline_selected = False
    for key, (space, original) in tuple(_PANORAMA_EXTRAS_STATES.items()):
        if key not in live_extras:
            try:
                space.overlay.show_extras, space.overlay.show_cursor = original
            except ReferenceError:
                pass
            _PANORAMA_EXTRAS_STATES.pop(key, None)
        else:
            if space.overlay.show_extras:
                space.overlay.show_extras = False
            if space.overlay.show_cursor:
                space.overlay.show_cursor = False
    for key, (space, overlays, gizmos) in tuple(_PANORAMA_LEGACY_VIEW_STATES.items()):
        if key not in live_legacy:
            try:
                space.overlay.show_overlays = overlays
                space.show_gizmo = gizmos
            except ReferenceError:
                pass
            _PANORAMA_LEGACY_VIEW_STATES.pop(key, None)
        else:
            if space.overlay.show_overlays:
                space.overlay.show_overlays = False
            if space.show_gizmo:
                space.show_gizmo = False
    return 0.5 if (_PANORAMA_BONE_STATES or _PANORAMA_OUTLINE_STATES
                   or _PANORAMA_EXTRAS_STATES
                   or _PANORAMA_LEGACY_VIEW_STATES) else None


def _sync_bone_overlay(space, active):
    key = space.as_pointer()
    if active:
        if key not in _PANORAMA_BONE_STATES and space.overlay.show_bones:
            _PANORAMA_BONE_STATES[key] = (space, True)
            space.overlay.show_bones = False
            if not bpy.app.timers.is_registered(_bone_overlay_watchdog):
                bpy.app.timers.register(_bone_overlay_watchdog, first_interval=0.5)
        return key in _PANORAMA_BONE_STATES
    if key in _PANORAMA_BONE_STATES:
        _, original = _PANORAMA_BONE_STATES.pop(key)
        space.overlay.show_bones = original
    return False


def _sync_outline_overlay(space, active):
    key = space.as_pointer()
    if active:
        if key not in _PANORAMA_OUTLINE_STATES and space.overlay.show_outline_selected:
            _PANORAMA_OUTLINE_STATES[key] = (space, True)
            space.overlay.show_outline_selected = False
            if not bpy.app.timers.is_registered(_bone_overlay_watchdog):
                bpy.app.timers.register(_bone_overlay_watchdog, first_interval=0.5)
        return key in _PANORAMA_OUTLINE_STATES
    if key in _PANORAMA_OUTLINE_STATES:
        _, original = _PANORAMA_OUTLINE_STATES.pop(key)
        space.overlay.show_outline_selected = original
    return False


def _sync_extras_overlay(space, active):
    key = space.as_pointer()
    if active:
        if (key not in _PANORAMA_EXTRAS_STATES
                and (space.overlay.show_extras or space.overlay.show_cursor)):
            _PANORAMA_EXTRAS_STATES[key] = (
                space, (space.overlay.show_extras, space.overlay.show_cursor))
            space.overlay.show_extras = False
            space.overlay.show_cursor = False
            if not bpy.app.timers.is_registered(_bone_overlay_watchdog):
                bpy.app.timers.register(_bone_overlay_watchdog, first_interval=0.5)
        return
    if key in _PANORAMA_EXTRAS_STATES:
        _, original = _PANORAMA_EXTRAS_STATES.pop(key)
        space.overlay.show_extras, space.overlay.show_cursor = original


def _panorama_custom_overlays_enabled(space):
    saved = _PANORAMA_LEGACY_VIEW_STATES.get(space.as_pointer())
    return saved[1] if saved else space.overlay.show_overlays


def _panorama_header_active(context):
    space = context.space_data
    camera = context.scene.camera if context.scene else None
    return (bpy.app.version < (5, 0, 0)
            and space is not None and space.type == 'VIEW_3D'
            and context.scene.render.engine == 'TOON_RENDER'
            and camera is not None and camera.data.type == 'PANO'
            and camera.data.panorama_type in {'EQUIRECTANGULAR', 'FISHEYE_EQUISOLID'}
            and space.shading.type in {'RENDERED', 'MATERIAL'}
            and space.region_3d.view_perspective == 'CAMERA')


def _install_panorama_header_toggle():
    """Proxy the native 4.x overlay button while its perspective pass is hidden."""
    global _ORIGINAL_VIEW3D_HEADER_DRAW
    if bpy.app.version >= (5, 0, 0) or _ORIGINAL_VIEW3D_HEADER_DRAW:
        return
    from bl_ui import space_view3d

    header = space_view3d.VIEW3D_HT_header
    draw_funcs = getattr(header.draw, '_draw_funcs', None)
    if not draw_funcs:
        raise RuntimeError('Blender 4.x viewport header draw callbacks unavailable')
    original = draw_funcs[0]
    source = textwrap.dedent(inspect.getsource(original))
    prop = 'row.prop(overlay, "show_overlays", icon=\'OVERLAY\', text="")'
    active = 'sub.active = overlay.show_overlays'
    if source.count(prop) != 1 or source.count(active) != 1:
        raise RuntimeError(f'Blender 4.x viewport overlay header layout changed: '
                           f'{inspect.getsourcefile(original)}, '
                           f'{source.count(prop)}, {source.count(active)}')
    source = source.replace(
        prop,
        'if _toon_panorama_header_active(context):\n'
        '        row.operator("view3d.toon_toggle_panorama_overlays", '
        'text="", icon=\'OVERLAY\', '
        'depress=_toon_panorama_custom_overlays_enabled(view))\n'
        '    else:\n'
        '        ' + prop)
    source = source.replace(
        active,
        'sub.active = (_toon_panorama_custom_overlays_enabled(view) '
        'if _toon_panorama_header_active(context) else overlay.show_overlays)')
    namespace = original.__globals__
    namespace['_toon_panorama_header_active'] = _panorama_header_active
    namespace['_toon_panorama_custom_overlays_enabled'] = _panorama_custom_overlays_enabled
    compiled = {}
    exec(compile(source, inspect.getsourcefile(original), 'exec'), namespace, compiled)
    draw_funcs[0] = compiled['draw']
    _ORIGINAL_VIEW3D_HEADER_DRAW = original


def _restore_panorama_header_toggle():
    global _ORIGINAL_VIEW3D_HEADER_DRAW
    if _ORIGINAL_VIEW3D_HEADER_DRAW:
        from bl_ui import space_view3d
        draw_funcs = getattr(space_view3d.VIEW3D_HT_header.draw, '_draw_funcs', None)
        if draw_funcs:
            draw_funcs[0] = _ORIGINAL_VIEW3D_HEADER_DRAW
        _ORIGINAL_VIEW3D_HEADER_DRAW = None


class TOON_OT_toggle_panorama_overlays(bpy.types.Operator):
    bl_idname = 'view3d.toon_toggle_panorama_overlays'
    bl_label = 'Toggle Panoramic Overlays'
    bl_options = {'INTERNAL'}

    def execute(self, context):
        space = context.space_data
        key = space.as_pointer()
        if key not in _PANORAMA_LEGACY_VIEW_STATES:
            _sync_legacy_view(space, True)
        _, overlays, gizmos = _PANORAMA_LEGACY_VIEW_STATES[key]
        _PANORAMA_LEGACY_VIEW_STATES[key] = (space, not overlays, gizmos)
        context.area.tag_redraw()
        return {'FINISHED'}


def _sync_legacy_view(space, active):
    """Blender 4.x keeps drawing selected origins and gizmos in perspective."""
    key = space.as_pointer()
    if active:
        if key not in _PANORAMA_LEGACY_VIEW_STATES:
            _PANORAMA_LEGACY_VIEW_STATES[key] = (
                space, space.overlay.show_overlays, space.show_gizmo)
            if not bpy.app.timers.is_registered(_bone_overlay_watchdog):
                bpy.app.timers.register(_bone_overlay_watchdog, first_interval=0.5)
        if space.overlay.show_overlays:
            space.overlay.show_overlays = False
        if space.show_gizmo:
            space.show_gizmo = False
    elif key in _PANORAMA_LEGACY_VIEW_STATES:
        _, overlays, gizmos = _PANORAMA_LEGACY_VIEW_STATES.pop(key)
        space.overlay.show_overlays = overlays
        space.show_gizmo = gizmos


@persistent
def _toon_save_pre(_dummy):
    # Do not persist the temporary hidden-bones viewport setting in .blend.
    for space, original in _PANORAMA_BONE_STATES.values():
        try:
            space.overlay.show_bones = original
        except ReferenceError:
            pass
    for space, original in _PANORAMA_OUTLINE_STATES.values():
        try:
            space.overlay.show_outline_selected = original
        except ReferenceError:
            pass
    for space, original in _PANORAMA_EXTRAS_STATES.values():
        try:
            space.overlay.show_extras, space.overlay.show_cursor = original
        except ReferenceError:
            pass
    for space, overlays, gizmos in _PANORAMA_LEGACY_VIEW_STATES.values():
        try:
            space.overlay.show_overlays = overlays
            space.show_gizmo = gizmos
        except ReferenceError:
            pass


@persistent
def _toon_save_post(_dummy):
    for space, _original in _PANORAMA_BONE_STATES.values():
        try:
            space.overlay.show_bones = False
        except ReferenceError:
            pass
    for space, _original in _PANORAMA_OUTLINE_STATES.values():
        try:
            space.overlay.show_outline_selected = False
        except ReferenceError:
            pass
    for space, _original in _PANORAMA_EXTRAS_STATES.values():
        try:
            space.overlay.show_extras = False
            space.overlay.show_cursor = False
        except ReferenceError:
            pass
    for space, _overlays, _gizmos in _PANORAMA_LEGACY_VIEW_STATES.values():
        try:
            space.overlay.show_overlays = False
            space.show_gizmo = False
        except ReferenceError:
            pass


def _project_pose_bones(context, camera, frame_rect):
    """Yield projected line segments for visible pose bones."""
    camera_inverse = camera.matrix_world.inverted()
    pixel_aspect = (context.scene.render.pixel_aspect_x,
                    context.scene.render.pixel_aspect_y)
    objects = (context.objects_in_mode if context.mode == 'POSE'
               else context.visible_objects)
    armatures = [obj for obj in objects if obj.type == 'ARMATURE']
    for armature in armatures:
        for pose_bone in armature.pose.bones:
            if pose_bone.bone.hide:
                continue
            head = armature.matrix_world @ pose_bone.head
            tail = armature.matrix_world @ pose_bone.tail
            points = []
            for step in range(13):
                position = head.lerp(tail, step / 12.0)
                local = camera_inverse @ position
                points.append(panorama.project_point(
                    local, camera.data, frame_rect, *pixel_aspect))
            segments = []
            for first, second in zip(points, points[1:]):
                if first is None or second is None:
                    continue
                if (camera.data.panorama_type == 'EQUIRECTANGULAR'
                        and abs(first[0] - second[0]) > frame_rect[2] * 0.5):
                    continue
                segments.append((first, second))
            if segments:
                yield armature, pose_bone, segments


def _pose_bone_selected(pose_bone):
    return bool(pose_bone.select if hasattr(pose_bone, 'select')
                else pose_bone.bone.select)


def _set_pose_bone_selected(pose_bone, selected):
    if hasattr(pose_bone, 'select'):
        pose_bone.select = selected
    else:
        pose_bone.bone.select = selected


def _sync_color_management():
    """Use Standard when a scene enters Toon Render, preserving later user edits."""
    scenes = getattr(bpy.data, 'scenes', None)
    if scenes is None:  # Add-on registration runs with Blender's restricted bpy.data.
        return
    current = {}
    for scene in scenes:
        key = scene.as_pointer()
        engine = scene.render.engine
        current[key] = engine
        if engine == 'TOON_RENDER' and _SCENE_ENGINES.get(key) != 'TOON_RENDER':
            scene.view_settings.view_transform = 'Standard'
    _SCENE_ENGINES.clear()
    _SCENE_ENGINES.update(current)


def _deferred_initial_sync():
    if getattr(bpy.data, 'scenes', None) is None:
        return 0.1
    _sync_color_management()
    toon_nodes.ensure_image_vector_inputs()
    toon_nodes.ensure_surface_pbr_inputs()
    toon_nodes.refresh_time_nodes()
    return None


def _subscribe_engine_changes():
    bpy.msgbus.clear_by_owner(_ENGINE_CHANGE_OWNER)
    bpy.msgbus.subscribe_rna(
        key=(bpy.types.RenderSettings, 'engine'),
        owner=_ENGINE_CHANGE_OWNER,
        args=(),
        notify=_sync_color_management,
    )


@persistent
def _toon_load_post(_filepath):
    _SCENE_ENGINES.clear()
    _subscribe_engine_changes()
    _sync_color_management()
    toon_nodes.ensure_image_vector_inputs()
    toon_nodes.ensure_surface_pbr_inputs()
    toon_nodes.refresh_time_nodes()


_OUTPUT_PANELS = (
    properties_output.RENDER_PT_format,
    properties_output.RENDER_PT_frame_range,
    properties_output.RENDER_PT_time_stretching,
    properties_output.RENDER_PT_output,
    properties_output.RENDER_PT_output_color_management,
    properties_output.RENDER_PT_output_pixel_density,
    properties_output.RENDER_PT_encoding,
    properties_output.RENDER_PT_encoding_video,
    properties_output.RENDER_PT_encoding_audio,
)

_DATA_PANELS = tuple(
    panel for module in (properties_data_mesh, properties_data_curves,
                         properties_data_pointcloud)
    for panel in module.classes if hasattr(panel, 'COMPAT_ENGINES')
)

_CAMERA_PANELS = tuple(
    getattr(properties_data_camera, name) for name in (
        'DATA_PT_context_camera',
        'DATA_PT_camera_background_image',
        'DATA_PT_camera_display',
        'DATA_PT_camera_display_composition_guides',
        'DATA_PT_camera_safe_areas',
        'DATA_PT_camera_safe_areas_center_cut',
        'DATA_PT_camera_animation',
        'DATA_PT_custom_props_camera',
    ) if hasattr(properties_data_camera, name)
)


def _draw_world_viewport_display(self, context):
    if context.engine != 'TOON_RENDER':
        _WORLD_VIEWPORT_DRAW(self, context)
        return
    self.layout.use_property_split = True
    self.layout.prop(context.world, 'toon_background_color', text='Background Color')


class TOON_PT_world_ambient(bpy.types.Panel):
    bl_label = 'Ambient Lighting'
    bl_idname = 'TOON_PT_world_ambient'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'world'

    @classmethod
    def poll(cls, context):
        return (context.scene is not None
                and context.scene.render.engine == 'TOON_RENDER')

    def draw(self, context):
        world = context.scene.world
        if world is None:
            self.layout.label(text='Create a World to set ambient lighting', icon='INFO')
            return
        layout = self.layout
        layout.use_property_split = True
        layout.prop(world, 'toon_ambient_mode', text='Ambient Mode')
        if world.toon_ambient_mode == 'HEMISPHERE':
            layout.prop(world, 'toon_ambient_sky_color', text='Sky Color')
            layout.prop(world, 'toon_ambient_ground_color', text='Ground Color')
            layout.prop(world, 'toon_ambient_tilt_x', text='Tilt X')
            layout.prop(world, 'toon_ambient_tilt_z', text='Tilt Z')
        else:
            layout.prop(world, 'toon_ambient_color', text='Color')
        layout.prop(world, 'toon_ambient_intensity', text='Ambient Intensity', slider=True)


def _set_world_viewport_draw(draw):
    # Blender captures a panel's draw callback when registering its class.
    bpy.utils.unregister_class(properties_world.WORLD_PT_viewport_display)
    properties_world.WORLD_PT_viewport_display.draw = draw
    bpy.utils.register_class(properties_world.WORLD_PT_viewport_display)


def _update_transparent_png(scene, _context):
    if scene.toon_transparent and scene.render.image_settings.file_format == 'PNG':
        scene.render.image_settings.color_mode = 'RGBA'

_GEOMETRY_FRAGMENT_SHADER = """
uniform mat4 model_matrix;
uniform float material_alpha;
uniform int alpha_mode;
uniform float alpha_threshold;
uniform mat4 view_matrix;
#ifdef USE_ALPHA_TEXTURE
uniform sampler2D alpha_texture;
#endif
in vec3 world_normal;
in vec3 world_position;
in vec3 local_normal;
in vec3 local_position;
in vec2 tex_coord;
out vec4 frag_color;
void main() {
    float alpha = material_alpha;
#ifdef USE_ALPHA_TEXTURE
    alpha *= texture(alpha_texture, tex_coord).a;
#endif
    if (alpha_mode == 1 && alpha < alpha_threshold) discard;
    if (alpha_mode == 0 && alpha <= alpha_threshold) discard;
    float distance_to_camera = max(-(view_matrix * vec4(world_position, 1.0)).z, 0.0001);
    frag_color = vec4(normalize(world_normal) * 0.5 + 0.5, distance_to_camera);
}
"""

_PROXIMITY_FRAGMENT_SHADER = """
uniform mat4 model_matrix;
uniform int alpha_mode;
uniform float alpha_threshold;
uniform mat4 view_matrix;
in vec3 world_normal;
in vec3 world_position;
in vec3 local_normal;
in vec3 local_position;
in vec2 tex_coord;
out vec4 frag_color;
void main() {
    float alpha = toon_graph_alpha(vec3(1.0));
    if (alpha_mode == 1 && alpha < alpha_threshold) discard;
    if (alpha_mode == 0 && alpha <= alpha_threshold) discard;
    frag_color = vec4(world_position, alpha);
}
"""

_POST_VERTEX_SHADER = """
in vec2 pos;
void main() {
    gl_Position = vec4(pos, 0.0, 1.0);
}
"""

_VIEWPORT_BLIT_FRAGMENT_SHADER = """
uniform sampler2D source_color;
uniform vec2 viewport_origin;
uniform vec2 viewport_size;
out vec4 frag_color;
void main() {
    vec2 uv = (gl_FragCoord.xy - viewport_origin) / viewport_size;
    frag_color = texture(source_color, uv);
}
"""

_BONE_VERTEX_SHADER = """
in vec2 pos;
uniform vec2 region_size;
void main() {
    gl_Position = vec4(pos / region_size * 2.0 - 1.0, 0.0, 1.0);
}
"""

_BONE_FRAGMENT_SHADER = """
uniform vec4 bone_color;
out vec4 frag_color;
void main() {
    frag_color = bone_color;
}
"""

_OUTLINE_FRAGMENT_SHADER = """
uniform sampler2D source_color;
uniform sampler2D geometry_texture;
uniform sampler2D material_id_texture;
uniform vec3 line_color;
uniform float thickness;
uniform float depth_threshold;
uniform float normal_threshold;
uniform float opacity;
uniform ivec2 target_origin;
out vec4 frag_color;

float edge_at(ivec2 pixel, ivec2 offset, ivec2 size) {
    vec4 center = texelFetch(geometry_texture, pixel, 0);
    vec4 neighbor = texelFetch(geometry_texture,
        clamp(pixel + offset, ivec2(0), size - ivec2(1)), 0);
    if (center.a <= 0.0 && neighbor.a <= 0.0) return 0.0;
    if (center.a <= 0.0 || neighbor.a <= 0.0) return 1.0;
    float depth_change = abs(center.a - neighbor.a) / max(min(center.a, neighbor.a), 0.01);
    vec3 normal_a = normalize(center.rgb * 2.0 - 1.0);
    vec3 normal_b = normalize(neighbor.rgb * 2.0 - 1.0);
    float normal_change = 1.0 - dot(normal_a, normal_b);
    return max(step(depth_threshold, depth_change),
               step(normal_threshold, normal_change));
}

/* MATERIAL_SELECTION */

float edge_for_effect(ivec2 pixel, ivec2 offset, ivec2 size) {
    ivec2 neighbor = clamp(pixel + offset, ivec2(0), size - ivec2(1));
    bool selected_center = selected_material(pixel);
    bool selected_neighbor = selected_material(neighbor);
    if (selected_center != selected_neighbor) return 1.0;
    if (!selected_center) return 0.0;
    return edge_at(pixel, offset, size);
}

void main() {
    ivec2 size = textureSize(source_color, 0);
    ivec2 pixel = clamp(ivec2(gl_FragCoord.xy) - target_origin,
                        ivec2(0), size - ivec2(1));
    int radius = max(1, int(round(thickness)));
    float edge = 0.0;
    edge = max(edge, edge_for_effect(pixel, ivec2(radius, 0), size));
    edge = max(edge, edge_for_effect(pixel, ivec2(-radius, 0), size));
    edge = max(edge, edge_for_effect(pixel, ivec2(0, radius), size));
    edge = max(edge, edge_for_effect(pixel, ivec2(0, -radius), size));
    edge = max(edge, edge_for_effect(pixel, ivec2(radius, radius), size));
    edge = max(edge, edge_for_effect(pixel, ivec2(-radius, radius), size));
    edge = max(edge, edge_for_effect(pixel, ivec2(radius, -radius), size));
    edge = max(edge, edge_for_effect(pixel, ivec2(-radius, -radius), size));
    vec4 source = texelFetch(source_color, pixel, 0);
    float line_alpha = edge * opacity;
    frag_color = vec4(mix(source.rgb, line_color, line_alpha),
                      source.a + line_alpha * (1.0 - source.a));
}
"""


_MOSAIC_FRAGMENT_SHADER = """
uniform sampler2D source_color;
uniform sampler2D material_id_texture;
uniform int pixel_size;
uniform float opacity;
uniform ivec2 target_origin;
out vec4 frag_color;

/* MATERIAL_SELECTION */

void main() {
    ivec2 size = textureSize(source_color, 0);
    ivec2 pixel = clamp(ivec2(gl_FragCoord.xy) - target_origin,
                        ivec2(0), size - ivec2(1));
    vec4 base = texelFetch(source_color, pixel, 0);
    int cell_size = max(pixel_size, 1);
    ivec2 cell_center = clamp((pixel / cell_size) * cell_size + ivec2(cell_size / 2),
                              ivec2(0), size - ivec2(1));
    vec3 mosaic_color = texelFetch(source_color, cell_center, 0).rgb;
    float amount = selected_material(pixel) ? clamp(opacity, 0.0, 1.0) : 0.0;
    frag_color = vec4(mix(base.rgb, mosaic_color, amount), base.a);
}
"""


_VERTEX_SHADER = """
uniform mat4 model_view_projection;
uniform mat4 model_matrix;
uniform float toon_depth_priority;
uniform vec4 toon_depth_projection;
in vec3 pos;
in vec3 normal;
in vec2 uv;
out vec3 world_normal;
out vec3 world_position;
out vec3 local_normal;
out vec3 local_position;
out vec2 tex_coord;
void main() {
    gl_Position = model_view_projection * vec4(pos, 1.0);
    if (abs(toon_depth_priority) > 0.000001) {
        if (toon_depth_projection.w > 0.5) {
            gl_Position.z = clamp(gl_Position.z
                + toon_depth_projection.x * toon_depth_priority,
                -0.99999, 0.99999);
        } else {
            float shifted_distance = max(gl_Position.w - toon_depth_priority,
                                         toon_depth_projection.z + 0.00001);
            float shifted_ndc = -toon_depth_projection.x
                                + toon_depth_projection.y / shifted_distance;
            gl_Position.z = clamp(shifted_ndc, -0.99999, 0.99999)
                            * gl_Position.w;
        }
    }
    world_normal = mat3(transpose(inverse(model_matrix))) * normal;
    world_position = (model_matrix * vec4(pos, 1.0)).xyz;
    local_normal = normal;
    local_position = pos;
    tex_coord = uv;
}
"""

_FRAGMENT_SHADER = """
uniform vec4 base_color;
uniform mat4 model_matrix;
uniform mat4 view_matrix;
uniform vec3 camera_position;
uniform float material_alpha;
uniform int alpha_mode;
uniform float alpha_threshold;
uniform int unlit;
uniform int light_count;
uniform int ambient_mode;
uniform vec3 ambient_color;
uniform vec3 ambient_sky_color;
uniform vec3 ambient_ground_color;
uniform vec3 ambient_direction;
uniform float ambient_intensity;
uniform vec4 light_position_type_0;
uniform vec4 light_color_energy_0;
uniform vec4 light_direction_angle_0;
uniform vec4 light_spot_inner_0;
uniform vec4 light_position_type_1;
uniform vec4 light_color_energy_1;
uniform vec4 light_direction_angle_1;
uniform vec4 light_spot_inner_1;
uniform vec4 light_position_type_2;
uniform vec4 light_color_energy_2;
uniform vec4 light_direction_angle_2;
uniform vec4 light_spot_inner_2;
uniform vec4 light_position_type_3;
uniform vec4 light_color_energy_3;
uniform vec4 light_direction_angle_3;
uniform vec4 light_spot_inner_3;
uniform int shadow_enabled_0;
uniform mat4 shadow_matrix_0;
uniform vec4 shadow_settings_0;
uniform sampler2D shadow_map_0_0;
uniform sampler2D shadow_map_0_1;
uniform vec3 shadow_position_0;
uniform vec4 shadow_splits_0;
uniform vec4 shadow_cascade_meta_0;
uniform vec4 shadow_transform_0_0;
uniform vec2 shadow_shift_0_0;
uniform vec4 shadow_transform_0_1;
uniform vec2 shadow_shift_0_1;
uniform vec4 shadow_transform_0_2;
uniform vec2 shadow_shift_0_2;
uniform vec4 shadow_transform_0_3;
uniform vec2 shadow_shift_0_3;
uniform int shadow_enabled_1;
uniform mat4 shadow_matrix_1;
uniform vec4 shadow_settings_1;
uniform sampler2D shadow_map_1_0;
uniform sampler2D shadow_map_1_1;
uniform vec3 shadow_position_1;
uniform vec4 shadow_splits_1;
uniform vec4 shadow_cascade_meta_1;
uniform vec4 shadow_transform_1_0;
uniform vec2 shadow_shift_1_0;
uniform vec4 shadow_transform_1_1;
uniform vec2 shadow_shift_1_1;
uniform vec4 shadow_transform_1_2;
uniform vec2 shadow_shift_1_2;
uniform vec4 shadow_transform_1_3;
uniform vec2 shadow_shift_1_3;
uniform int shadow_enabled_2;
uniform mat4 shadow_matrix_2;
uniform vec4 shadow_settings_2;
uniform sampler2D shadow_map_2_0;
uniform sampler2D shadow_map_2_1;
uniform vec3 shadow_position_2;
uniform vec4 shadow_splits_2;
uniform vec4 shadow_cascade_meta_2;
uniform vec4 shadow_transform_2_0;
uniform vec2 shadow_shift_2_0;
uniform vec4 shadow_transform_2_1;
uniform vec2 shadow_shift_2_1;
uniform vec4 shadow_transform_2_2;
uniform vec2 shadow_shift_2_2;
uniform vec4 shadow_transform_2_3;
uniform vec2 shadow_shift_2_3;
uniform int shadow_enabled_3;
uniform mat4 shadow_matrix_3;
uniform vec4 shadow_settings_3;
uniform sampler2D shadow_map_3_0;
uniform sampler2D shadow_map_3_1;
uniform vec3 shadow_position_3;
uniform vec4 shadow_splits_3;
uniform vec4 shadow_cascade_meta_3;
uniform vec4 shadow_transform_3_0;
uniform vec2 shadow_shift_3_0;
uniform vec4 shadow_transform_3_1;
uniform vec2 shadow_shift_3_1;
uniform vec4 shadow_transform_3_2;
uniform vec2 shadow_shift_3_2;
uniform vec4 shadow_transform_3_3;
uniform vec2 shadow_shift_3_3;
#ifdef USE_TEXTURE
uniform sampler2D base_texture;
#endif
#ifdef USE_ALPHA_TEXTURE
uniform sampler2D alpha_texture;
#endif
in vec3 world_normal;
in vec3 world_position;
in vec3 local_normal;
in vec3 local_position;
in vec2 tex_coord;
out vec4 frag_color;
float shadow_blocked_pixel(ivec2 pixel, float receiver_depth,
                           sampler2D map0, sampler2D map1, float bias) {
    vec4 first = texelFetch(map0, pixel, 0);
    vec4 second = texelFetch(map1, pixel, 0);
    float transmission = 1.0;
    if (first.a > 0.0 && receiver_depth > first.r + first.b / 1024.0 + bias)
        transmission *= 1.0 - first.g;
    if (second.a > 0.0 && receiver_depth > second.r + second.b / 1024.0 + bias)
        transmission *= 1.0 - second.g;
    return 1.0 - transmission;
}
float shadow_visibility_projected(vec3 projected, sampler2D map0,
                                  sampler2D map1, vec4 settings,
                                  ivec2 tile_origin, int tile_size) {
    if (projected.x < 0.0 || projected.x > 1.0 ||
        projected.y < 0.0 || projected.y > 1.0 ||
        projected.z < 0.0 || projected.z > 1.0) return 1.0;
    ivec2 lower = tile_origin;
    ivec2 upper = tile_origin + ivec2(tile_size - 1);
    vec2 pixel_position = projected.xy * float(tile_size) - 0.5;
    ivec2 base = tile_origin + ivec2(floor(pixel_position));
    vec2 fraction = fract(pixel_position);
    int radius = int(round(settings.z));
    float blocked = 0.0;
    if (radius <= 1) {
        // Bilinear comparison filtering avoids locking the edge to texel corners.
        // A radius of one combines three taps into a four-by-four weighted grid.
        for (int y = -1; y <= 2; y++) {
            if (radius == 0 && (y < 0 || y > 1)) continue;
            float weight_y = y == -1 ? 1.0 - fraction.y
                             : y == 2 ? fraction.y
                             : radius == 0 ? (y == 0 ? 1.0 - fraction.y
                                                     : fraction.y) : 1.0;
            for (int x = -1; x <= 2; x++) {
                if (radius == 0 && (x < 0 || x > 1)) continue;
                float weight_x = x == -1 ? 1.0 - fraction.x
                                 : x == 2 ? fraction.x
                                 : radius == 0 ? (x == 0 ? 1.0 - fraction.x
                                                         : fraction.x) : 1.0;
                ivec2 pixel = clamp(base + ivec2(x, y), lower, upper);
                blocked += weight_x * weight_y * shadow_blocked_pixel(
                    pixel, projected.z, map0, map1, settings.x);
            }
        }
        blocked /= radius == 0 ? 1.0 : 9.0;
    } else {
        for (int y = -1; y <= 1; y++) {
            for (int x = -1; x <= 1; x++) {
                vec2 sample_position = pixel_position + vec2(x, y) * float(radius);
                ivec2 sample_base = tile_origin + ivec2(floor(sample_position));
                vec2 sample_fraction = fract(sample_position);
                for (int dy = 0; dy <= 1; dy++) {
                    for (int dx = 0; dx <= 1; dx++) {
                        ivec2 pixel = clamp(sample_base + ivec2(dx, dy),
                                            lower, upper);
                        float weight = (dx == 0 ? 1.0 - sample_fraction.x
                                                 : sample_fraction.x)
                                     * (dy == 0 ? 1.0 - sample_fraction.y
                                                 : sample_fraction.y);
                        blocked += weight * shadow_blocked_pixel(
                            pixel, projected.z, map0, map1, settings.x);
                    }
                }
            }
        }
        blocked /= 9.0;
    }
    return 1.0 - settings.y * blocked;
}
float shadow_visibility(vec3 position, mat4 light_matrix, sampler2D map0,
                        sampler2D map1, vec4 settings) {
    vec4 clip = light_matrix * vec4(position, 1.0);
    return shadow_visibility_projected(clip.xyz / clip.w * 0.5 + 0.5,
                                       map0, map1, settings,
                                       ivec2(0), textureSize(map0, 0).x);
}
float cascade_sample(vec3 far_ndc, int cascade, int cascade_count,
                     float depth_scale,
                     float far_xy_scale, float normal_slope,
                     sampler2D map0,
                     sampler2D map1, vec4 settings,
                     vec4 transform0, vec2 shift0,
                     vec4 transform1, vec2 shift1,
                     vec4 transform2, vec2 shift2,
                     vec4 transform3, vec2 shift3) {
    vec3 ndc = far_ndc;
    if (cascade == 0)
        ndc = far_ndc * transform0.xyz + vec3(transform0.w, shift0);
    else if (cascade == 1)
        ndc = far_ndc * transform1.xyz + vec3(transform1.w, shift1);
    else if (cascade == 2 && cascade_count == 5)
        ndc = far_ndc * transform2.xyz + vec3(transform2.w, shift2);
    else if (cascade == 3 && cascade_count == 5)
        ndc = far_ndc * transform3.xyz + vec3(transform3.w, shift3);
    int resolution = int(settings.w + 0.5);
    int full_size_count = cascade_count == 5 ? 3 : 2;
    int half_size = max(64, resolution / 2);
    int tile_size = cascade < full_size_count ? resolution : half_size;
    int offset = min(cascade, full_size_count) * resolution
                 + max(cascade - full_size_count, 0) * half_size;
    float cascade_scale = cascade == 0 ? transform0.x
                          : cascade == 1 ? transform1.x
                          : cascade == 2 && cascade_count == 5 ? transform2.x
                          : cascade == 3 && cascade_count == 5 ? transform3.x
                          : 1.0;
    float world_texel = 2.0 / max(far_xy_scale * cascade_scale
                                  * float(tile_size), 0.00001);
    float world_bias = settings.x + world_texel * normal_slope
                       * max(1.0, round(settings.z)) * 2.0;
    vec4 sample_settings = settings;
    sample_settings.x = world_bias * depth_scale
                        * (cascade == 0 ? transform0.z
                           : cascade == 1 ? transform1.z
                           : cascade == 2 && cascade_count == 5 ? transform2.z
                           : cascade == 3 && cascade_count == 5 ? transform3.z
                           : 1.0);
    return shadow_visibility_projected(ndc * 0.5 + 0.5,
                                       map0, map1, sample_settings,
                                       ivec2(offset, 0), tile_size);
}
float cascaded_shadow_visibility(vec3 position, vec3 normal,
                                 mat4 far_matrix,
                                 sampler2D map0, sampler2D map1,
                                 vec4 settings, vec4 splits, vec4 cascade_meta,
                                 vec4 transform0, vec2 shift0,
                                 vec4 transform1, vec2 shift1,
                                 vec4 transform2, vec2 shift2,
                                 vec4 transform3, vec2 shift3) {
    float depth = -(view_matrix * vec4(position, 1.0)).z;
    if (depth > cascade_meta.x) return 1.0;
    int cascade_count = int(cascade_meta.z + 0.5);
    int cascade = depth < splits.x ? 0 : depth < splits.y ? 1
                  : depth < splits.z ? 2 : depth < splits.w ? 3 : 4;
    cascade = min(cascade, cascade_count - 1);
    vec4 clip = far_matrix * vec4(position, 1.0);
    vec3 far_ndc = clip.xyz / clip.w;
    float depth_scale = 0.5 * length(vec3(
        far_matrix[0][2], far_matrix[1][2], far_matrix[2][2]));
    float far_xy_scale = length(vec3(
        far_matrix[0][0], far_matrix[1][0], far_matrix[2][0]));
    vec3 light_axis = normalize(vec3(
        far_matrix[0][2], far_matrix[1][2], far_matrix[2][2]));
    float face_angle = abs(dot(normalize(normal), light_axis));
    float normal_slope = min(sqrt(max(1.0 - face_angle * face_angle, 0.0))
                             / max(face_angle, 0.15), 4.0);
    float visibility = cascade_sample(far_ndc, cascade, cascade_count, depth_scale,
                                      far_xy_scale, normal_slope, map0, map1,
                                      settings, transform0, shift0,
                                      transform1, shift1, transform2, shift2,
                                      transform3, shift3);
    if (cascade < cascade_count - 1 && cascade_meta.y > 0.0) {
        float upper = splits[cascade];
        float lower = cascade == 0 ? 0.0 : splits[cascade - 1];
        float fade_width = max((upper - lower) * cascade_meta.y, 0.0001);
        if (depth > upper - fade_width) {
            float next_visibility = cascade_sample(
                far_ndc, cascade + 1, cascade_count, depth_scale, far_xy_scale,
                normal_slope, map0, map1, settings,
                transform0, shift0, transform1, shift1,
                transform2, shift2, transform3, shift3);
            visibility = mix(visibility, next_visibility,
                             smoothstep(upper - fade_width, upper, depth));
        }
    }
    return visibility;
}
ivec2 point_atlas_pixel(vec3 direction, ivec2 atlas_size) {
    vec3 axis = abs(direction);
    float major;
    vec2 face_uv;
    int face;
    if (axis.x >= axis.y && axis.x >= axis.z) {
        major = axis.x;
        face = direction.x >= 0.0 ? 0 : 1;
        face_uv = vec2(direction.x >= 0.0 ? -direction.z : direction.z, -direction.y);
    } else if (axis.y >= axis.z) {
        major = axis.y;
        face = direction.y >= 0.0 ? 2 : 3;
        face_uv = vec2(direction.x,
                       direction.y >= 0.0 ? direction.z : -direction.z);
    } else {
        major = axis.z;
        face = direction.z >= 0.0 ? 4 : 5;
        face_uv = vec2(direction.z >= 0.0 ? direction.x : -direction.x, -direction.y);
    }
    ivec2 face_size = atlas_size / ivec2(3, 2);
    ivec2 local = clamp(ivec2((face_uv / major * 0.5 + 0.5) * vec2(face_size)),
                        ivec2(0), face_size - ivec2(1));
    return ivec2(face % 3, face / 3) * face_size + local;
}
float point_shadow_visibility(vec3 position, vec3 light_position,
                              sampler2D map0, sampler2D map1, vec4 settings) {
    vec3 delta = position - light_position;
    float distance_to_light = length(delta);
    float receiver_depth = distance_to_light / settings.w;
    if (receiver_depth >= 1.0 || distance_to_light < 0.0001) return 1.0;
    vec3 direction = delta / distance_to_light;
    vec3 helper = abs(direction.z) < 0.9 ? vec3(0.0, 0.0, 1.0) : vec3(0.0, 1.0, 0.0);
    vec3 tangent = normalize(cross(helper, direction));
    vec3 bitangent = cross(direction, tangent);
    ivec2 atlas_size = textureSize(map0, 0);
    float angular_step = settings.z * 2.0 / float(atlas_size.x / 3);
    int radius = settings.z > 0.0 ? 1 : 0;
    float blocked = 0.0;
    int count = 0;
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            if (radius == 0 && (x != 0 || y != 0)) continue;
            vec3 sample_direction = normalize(direction +
                (tangent * float(x) + bitangent * float(y)) * angular_step);
            ivec2 pixel = point_atlas_pixel(sample_direction, atlas_size);
            vec4 first = texelFetch(map0, pixel, 0);
            vec4 second = texelFetch(map1, pixel, 0);
            float transmission = 1.0;
            if (first.a > 0.0 && receiver_depth > first.r + first.b / 1024.0 + settings.x)
                transmission *= 1.0 - first.g;
            if (second.a > 0.0 && receiver_depth > second.r + second.b / 1024.0 + settings.x)
                transmission *= 1.0 - second.g;
            blocked += 1.0 - transmission;
            count++;
        }
    }
    return 1.0 - settings.y * blocked / float(count);
}
vec3 shade_light(vec4 position_type, vec4 color_energy,
                 vec4 direction_angle, vec4 spot_inner,
                 vec3 normal, float roughness, out vec3 specular) {
    normal = normalize(normal);
    vec3 to_light;
    float strength = color_energy.w;
    int light_type = int(position_type.w);
    if (light_type == 0) {
        to_light = normalize(-direction_angle.xyz);
    } else {
        vec3 delta = position_type.xyz - world_position;
        float distance_squared = max(dot(delta, delta), 0.25);
        to_light = normalize(delta);
        float falloff = strength * 0.5 / (12.5663706 * distance_squared);
        strength = falloff / (1.0 + falloff);
        if (light_type == 2) {
            float angle = dot(normalize(direction_angle.xyz), -to_light);
            float outer = direction_angle.w;
            float inner = max(spot_inner.x, outer + 0.0001);
            strength *= smoothstep(outer, inner, angle);
        }
    }
    float ndotl = max(dot(normal, to_light), 0.0);
    vec3 view_direction = normalize(camera_position - world_position);
    vec3 half_direction = normalize(to_light + view_direction);
    float gloss = 1.0 - clamp(roughness, 0.0, 1.0);
    float gloss_squared = gloss * gloss;
    float polish = gloss_squared * gloss_squared;
    float exponent = mix(8.0, 512.0, polish);
    float peak = mix(0.1, 5.0, polish);
    specular = color_energy.rgb * (pow(max(dot(normal, half_direction), 0.0), exponent)
                                   * ndotl * strength * peak);
    return color_energy.rgb * (ndotl * strength);
}
void main() {
    vec4 color = base_color;
#ifdef USE_TEXTURE
    color *= texture(base_texture, tex_coord);
#endif
    float alpha = material_alpha;
#ifdef USE_ALPHA_TEXTURE
    alpha *= texture(alpha_texture, tex_coord).a;
#endif
    if (alpha_mode == 1 && alpha < alpha_threshold) discard;
    if (alpha_mode == 0 && alpha <= alpha_threshold) discard;
    if (alpha_mode == 1) alpha = 1.0;
    vec3 toon_shading_normal = toon_graph_normal();
    vec3 lighting = vec3(1.0);
    toon_surface_unlit = float(unlit);
    if (unlit == 0) {
        if (ambient_mode == 1) {
            float hemi_weight = clamp(0.5 * dot(toon_shading_normal,
                                                ambient_direction) + 0.5, 0.0, 1.0);
            lighting = mix(ambient_ground_color, ambient_sky_color,
                           hemi_weight) * ambient_intensity;
        } else {
            lighting = ambient_color * ambient_intensity;
        }
        float roughness = toon_graph_roughness();
        toon_specular_light = lighting * 0.08;
        if (light_count > 0) {
            vec3 specular;
            vec3 contribution = shade_light(light_position_type_0, light_color_energy_0,
                                            light_direction_angle_0, light_spot_inner_0,
                                            toon_shading_normal, roughness, specular);
            float visibility = 1.0;
            if (shadow_enabled_0 == 1) visibility = shadow_visibility(
                world_position, shadow_matrix_0, shadow_map_0_0, shadow_map_0_1, shadow_settings_0);
            else if (shadow_enabled_0 == 2) visibility = point_shadow_visibility(
                world_position, shadow_position_0, shadow_map_0_0, shadow_map_0_1, shadow_settings_0);
            else if (shadow_enabled_0 == 3) visibility = cascaded_shadow_visibility(
                world_position, toon_shading_normal, shadow_matrix_0, shadow_map_0_0, shadow_map_0_1,
                shadow_settings_0, shadow_splits_0, shadow_cascade_meta_0,
                shadow_transform_0_0, shadow_shift_0_0,
                shadow_transform_0_1, shadow_shift_0_1,
                shadow_transform_0_2, shadow_shift_0_2,
                shadow_transform_0_3, shadow_shift_0_3);
            lighting += contribution * visibility;
            toon_specular_light += specular * visibility;
        }
        if (light_count > 1) {
            vec3 specular;
            vec3 contribution = shade_light(light_position_type_1, light_color_energy_1,
                                            light_direction_angle_1, light_spot_inner_1,
                                            toon_shading_normal, roughness, specular);
            float visibility = 1.0;
            if (shadow_enabled_1 == 1) visibility = shadow_visibility(
                world_position, shadow_matrix_1, shadow_map_1_0, shadow_map_1_1, shadow_settings_1);
            else if (shadow_enabled_1 == 2) visibility = point_shadow_visibility(
                world_position, shadow_position_1, shadow_map_1_0, shadow_map_1_1, shadow_settings_1);
            else if (shadow_enabled_1 == 3) visibility = cascaded_shadow_visibility(
                world_position, toon_shading_normal, shadow_matrix_1, shadow_map_1_0, shadow_map_1_1,
                shadow_settings_1, shadow_splits_1, shadow_cascade_meta_1,
                shadow_transform_1_0, shadow_shift_1_0,
                shadow_transform_1_1, shadow_shift_1_1,
                shadow_transform_1_2, shadow_shift_1_2,
                shadow_transform_1_3, shadow_shift_1_3);
            lighting += contribution * visibility;
            toon_specular_light += specular * visibility;
        }
        if (light_count > 2) {
            vec3 specular;
            vec3 contribution = shade_light(light_position_type_2, light_color_energy_2,
                                            light_direction_angle_2, light_spot_inner_2,
                                            toon_shading_normal, roughness, specular);
            float visibility = 1.0;
            if (shadow_enabled_2 == 1) visibility = shadow_visibility(
                world_position, shadow_matrix_2, shadow_map_2_0, shadow_map_2_1, shadow_settings_2);
            else if (shadow_enabled_2 == 2) visibility = point_shadow_visibility(
                world_position, shadow_position_2, shadow_map_2_0, shadow_map_2_1, shadow_settings_2);
            else if (shadow_enabled_2 == 3) visibility = cascaded_shadow_visibility(
                world_position, toon_shading_normal, shadow_matrix_2, shadow_map_2_0, shadow_map_2_1,
                shadow_settings_2, shadow_splits_2, shadow_cascade_meta_2,
                shadow_transform_2_0, shadow_shift_2_0,
                shadow_transform_2_1, shadow_shift_2_1,
                shadow_transform_2_2, shadow_shift_2_2,
                shadow_transform_2_3, shadow_shift_2_3);
            lighting += contribution * visibility;
            toon_specular_light += specular * visibility;
        }
        if (light_count > 3) {
            vec3 specular;
            vec3 contribution = shade_light(light_position_type_3, light_color_energy_3,
                                            light_direction_angle_3, light_spot_inner_3,
                                            toon_shading_normal, roughness, specular);
            float visibility = 1.0;
            if (shadow_enabled_3 == 1) visibility = shadow_visibility(
                world_position, shadow_matrix_3, shadow_map_3_0, shadow_map_3_1, shadow_settings_3);
            else if (shadow_enabled_3 == 2) visibility = point_shadow_visibility(
                world_position, shadow_position_3, shadow_map_3_0, shadow_map_3_1, shadow_settings_3);
            else if (shadow_enabled_3 == 3) visibility = cascaded_shadow_visibility(
                world_position, toon_shading_normal, shadow_matrix_3, shadow_map_3_0, shadow_map_3_1,
                shadow_settings_3, shadow_splits_3, shadow_cascade_meta_3,
                shadow_transform_3_0, shadow_shift_3_0,
                shadow_transform_3_1, shadow_shift_3_1,
                shadow_transform_3_2, shadow_shift_3_2,
                shadow_transform_3_3, shadow_shift_3_3);
            lighting += contribution * visibility;
            toon_specular_light += specular * visibility;
        }
    }
    frag_color = vec4(color.rgb * lighting, alpha);
}
"""


_SHADOW_MASK_FUNCTION = 'float toon_scene_shadow_mask() {\n    float mask = 0.0;\n' + ''.join(
    f'''    if (light_count > {index}) {{
        if (shadow_enabled_{index} == 1)
            mask = max(mask, 1.0 - shadow_visibility(
                world_position, shadow_matrix_{index}, shadow_map_{index}_0,
                shadow_map_{index}_1, shadow_settings_{index}));
        else if (shadow_enabled_{index} == 2)
            mask = max(mask, 1.0 - point_shadow_visibility(
                world_position, shadow_position_{index}, shadow_map_{index}_0,
                shadow_map_{index}_1, shadow_settings_{index}));
        else if (shadow_enabled_{index} == 3)
            mask = max(mask, 1.0 - cascaded_shadow_visibility(
                world_position, world_normal, shadow_matrix_{index}, shadow_map_{index}_0,
                shadow_map_{index}_1, shadow_settings_{index}, shadow_splits_{index},
                shadow_cascade_meta_{index},
                shadow_transform_{index}_0, shadow_shift_{index}_0,
                shadow_transform_{index}_1, shadow_shift_{index}_1,
                shadow_transform_{index}_2, shadow_shift_{index}_2,
                shadow_transform_{index}_3, shadow_shift_{index}_3));
    }}
''' for index in range(_MAX_LIGHTS)) + '    return clamp(mask, 0.0, 1.0);\n}\n'


def _graph_fragment(source, graph, compute_shadows=False):
    helpers = graph.code + (_SHADOW_MASK_FUNCTION if compute_shadows and graph.uses_shadow_mask else '')
    source = source.replace('void main() {', helpers + '\nvoid main() {', 1)
    source = source.replace('''    vec4 color = base_color;
#ifdef USE_TEXTURE
    color *= texture(base_texture, tex_coord);
#endif''', '')
    source = source.replace('''    float alpha = material_alpha;
#ifdef USE_ALPHA_TEXTURE
    alpha *= texture(alpha_texture, tex_coord).a;
#endif''', '    float alpha = toon_graph_alpha(vec3(1.0));')
    if compute_shadows and graph.uses_shadow_mask:
        source = source.replace('    float alpha = toon_graph_alpha(vec3(1.0));',
                                '    toon_shadow_mask_value = toon_scene_shadow_mask();\n'
                                '    float alpha = toon_graph_alpha(vec3(1.0));')
    source = source.replace('    frag_color = vec4(color.rgb * lighting, alpha);',
                            '    vec4 color = toon_graph_color(lighting);\n'
                            '    frag_color = vec4(color.rgb + toon_graph_emission(lighting), alpha);')
    return source


def _graph_vertex(source, graph):
    if not graph.vertex_attributes:
        return source
    declarations = ''.join(
        (f'in vec2 {attribute};\nout vec2 toon_vuv_{attribute};\n'
         if attribute.startswith('toon_uv_') else
         f'in vec4 {attribute};\nout vec4 toon_vcol_{attribute};\n')
        for attribute in graph.vertex_attributes)
    assignments = ''.join(
        (f'    toon_vuv_{attribute} = {attribute};\n'
         if attribute.startswith('toon_uv_') else
         f'    toon_vcol_{attribute} = {attribute};\n')
        for attribute in graph.vertex_attributes)
    return source.replace('void main() {', declarations + 'void main() {', 1).replace(
        'void main() {', 'void main() {\n' + assignments, 1)


def _bind_depth_priority(shader, priority, projection_matrix):
    a = projection_matrix[2][2]
    b = projection_matrix[2][3]
    orthographic = abs(projection_matrix[3][3]) > 0.5
    near = 0.0 if orthographic else max(b / (a - 1.0), 0.00001)
    shader.uniform_float('toon_depth_priority', float(priority))
    shader.uniform_float('toon_depth_projection',
                         (a, b, near, 1.0 if orthographic else 0.0))


def _ordered_scene_items(priority_queues):
    opaque = []
    transparent = []
    for priority in sorted(priority_queues):
        opaque_queue, transparent_queue = priority_queues[priority]
        opaque.extend(opaque_queue)
        transparent.extend(transparent_queue)
    transparent.sort(key=lambda item: (item[6] == 'ADDITIVE', item[2] + item[9]))
    return opaque, transparent


def _mesh_batches(obj, attributes=()):
    """Build one vertex buffer and one indexed batch per used material slot."""
    import gpu

    mesh = obj.to_mesh()
    if mesh is None:
        return []
    try:
        mesh.calc_loop_triangles()
        triangle_count = len(mesh.loop_triangles)
        if triangle_count == 0:
            return []
        vertices = np.empty((len(mesh.vertices), 3), dtype=np.float32)
        mesh.vertices.foreach_get('co', vertices.ravel())
        loop_vertex_indices = np.empty(len(mesh.loops), dtype=np.int32)
        mesh.loops.foreach_get('vertex_index', loop_vertex_indices)
        positions = vertices[loop_vertex_indices]
        normals = np.empty((len(mesh.loops), 3), dtype=np.float32)
        mesh.corner_normals.foreach_get('vector', normals.ravel())
        uv_layer = mesh.uv_layers.active
        uvs = np.zeros((len(mesh.loops), 2), dtype=np.float32)
        if uv_layer:
            uv_layer.data.foreach_get('uv', uvs.ravel())
        triangles = np.empty((triangle_count, 3), dtype=np.int32)
        mesh.loop_triangles.foreach_get('loops', triangles.ravel())
        triangle_polygons = np.empty(triangle_count, dtype=np.int32)
        mesh.loop_triangles.foreach_get('polygon_index', triangle_polygons)
        polygon_materials = np.empty(len(mesh.polygons), dtype=np.int32)
        mesh.polygons.foreach_get('material_index', polygon_materials)
        triangle_materials = polygon_materials[triangle_polygons]

        vertex_format = gpu.types.GPUVertFormat()
        vertex_format.attr_add(id='pos', comp_type='F32', len=3, fetch_mode='FLOAT')
        vertex_format.attr_add(id='normal', comp_type='F32', len=3, fetch_mode='FLOAT')
        vertex_format.attr_add(id='uv', comp_type='F32', len=2, fetch_mode='FLOAT')
        attribute_arrays = {}
        for attribute_id, name in attributes:
            if attribute_id.startswith('toon_uv_'):
                layer = mesh.uv_layers.get(name)
                values = np.zeros((len(mesh.loops), 2), dtype=np.float32)
                if layer:
                    layer.data.foreach_get('uv', values.ravel())
                components = 2
            else:
                attribute = mesh.color_attributes.get(name)
                if attribute and attribute.domain in {'POINT', 'CORNER'}:
                    values = np.empty((len(attribute.data), 4), dtype=np.float32)
                    attribute.data.foreach_get('color', values.ravel())
                    values = (values[loop_vertex_indices]
                              if attribute.domain == 'POINT' else values)
                else:
                    values = np.ones((len(mesh.loops), 4), dtype=np.float32)
                components = 4
            attribute_arrays[attribute_id] = values
            vertex_format.attr_add(id=attribute_id, comp_type='F32', len=components,
                                   fetch_mode='FLOAT')
        vertex_buffer = gpu.types.GPUVertBuf(vertex_format, len(mesh.loops))
        vertex_buffer.attr_fill('pos', positions)
        vertex_buffer.attr_fill('normal', normals)
        vertex_buffer.attr_fill('uv', uvs)
        for attribute_id, values in attribute_arrays.items():
            vertex_buffer.attr_fill(attribute_id, values)
        return [
            (int(slot), gpu.types.GPUBatch(
                type='TRIS', buf=vertex_buffer,
                elem=gpu.types.GPUIndexBuf(
                    type='TRIS', seq=triangles[triangle_materials == slot])))
            for slot in np.unique(triangle_materials)
        ]
    finally:
        obj.to_mesh_clear()


def _needs_frame_rebuild(obj):
    """Identify meshes whose evaluated vertices can change during playback."""
    source = obj.original
    if source.data.shape_keys or source.data.animation_data:
        return True
    static_modifiers = {'MIRROR', 'BEVEL', 'SOLIDIFY', 'SUBSURF',
                        'TRIANGULATE', 'DECIMATE', 'WELD', 'EDGE_SPLIT',
                        'WEIGHTED_NORMAL'}
    return any(modifier.type not in static_modifiers for modifier in source.modifiers)


def _material_surface(material):
    """Evaluate the small Toon Render graph for a material."""
    if material is None:
        return (toon_graph.compile_material(None, None, None), 'BLEND', 0.001,
                True, 0.0, False, False, True, True)
    tree = material.toon_tree
    output = next((node for node in tree.nodes
                   if node.bl_idname == toon_nodes.ToonMaterialOutputNode.bl_idname), None) if tree else None
    def upstream_surface(node, visited):
        if node.as_pointer() in visited:
            return None
        visited.add(node.as_pointer())
        if node.bl_idname == toon_nodes.ToonSurfaceNode.bl_idname:
            return node
        for socket in node.inputs:
            if socket.is_linked:
                found = upstream_surface(socket.links[0].from_node, visited)
                if found:
                    return found
        return None

    surface = None
    if output:
        source = output.inputs['Surface'].links[0].from_node if output.inputs['Surface'].is_linked else None
        if source and source.bl_idname == toon_nodes.ToonSurfaceNode.bl_idname:
            surface = source
        else:
            surface = upstream_surface(output, set())
    graph = toon_graph.compile_material(material, output, surface)
    if graph.additive:
        return (graph, 'ADDITIVE', 0.001, True, 0.0,
                material.toon_double_sided, True,
                material.toon_cast_shadow, material.toon_receive_shadow)
    if surface:
        method = surface.transparency_method
        return (graph, method, surface.cutout_threshold if method == 'CUTOUT'
                else surface.blend_threshold, surface.transparency_overlap,
                surface.render_priority, material.toon_double_sided,
                material.toon_unlit, material.toon_cast_shadow,
                material.toon_receive_shadow)
    return (graph, 'BLEND', 0.001, True, 0.0,
            material.toon_double_sided, material.toon_unlit,
            material.toon_cast_shadow, material.toon_receive_shadow)


def _scene_lights(depsgraph):
    """Pack Sun, Point and Spot instances for the small forward shader."""
    positions = []
    colors = []
    directions = []
    spot_inner = []
    for instance in depsgraph.object_instances:
        obj = instance.object
        if obj.type != 'LIGHT' or obj.hide_render:
            continue
        light = obj.data
        if light.type not in {'SUN', 'POINT', 'SPOT'}:
            continue
        matrix = instance.matrix_world
        direction = (matrix.to_quaternion() @ Vector((0.0, 0.0, -1.0))).normalized()
        position = matrix.translation
        kind = {'SUN': 0.0, 'POINT': 1.0, 'SPOT': 2.0}[light.type]
        half_angle = light.spot_size * 0.5 if light.type == 'SPOT' else 0.0
        outer = math.cos(half_angle) if light.type == 'SPOT' else 0.0
        inner = math.cos(half_angle * (1.0 - light.spot_blend)) if light.type == 'SPOT' else 0.0
        positions.append((position.x, position.y, position.z, kind))
        colors.append((*light.color, max(0.0, light.energy)))
        directions.append((direction.x, direction.y, direction.z, outer))
        spot_inner.append((inner, 0.0, 0.0, 0.0))
        if len(positions) == _MAX_LIGHTS:
            break
    padding = _MAX_LIGHTS - len(positions)
    return (len(positions),
            positions + [(0.0, 0.0, 0.0, 0.0)] * padding,
            colors + [(0.0, 0.0, 0.0, 0.0)] * padding,
            directions + [(0.0, 0.0, -1.0, 0.0)] * padding,
            spot_inner + [(0.0, 0.0, 0.0, 0.0)] * padding)


def _scene_ambient(depsgraph):
    world = depsgraph.scene_eval.world
    if world is None:
        return (0, (1.0, 1.0, 1.0), (0.75, 0.86, 1.0),
                (0.36, 0.31, 0.38), (0.0, 1.0, 0.0), 0.16)
    x = world.toon_ambient_tilt_x
    z = world.toon_ambient_tilt_z
    direction = (-math.sin(z) * math.cos(x),
                 math.cos(z) * math.cos(x), math.sin(x))
    return (int(world.toon_ambient_mode == 'HEMISPHERE'),
            tuple(world.toon_ambient_color),
            tuple(world.toon_ambient_sky_color),
            tuple(world.toon_ambient_ground_color),
            direction, world.toon_ambient_intensity)


class ToonRenderEngine(bpy.types.RenderEngine):
    bl_idname = "TOON_RENDER"
    bl_label = "Toon Render"
    bl_use_preview = False
    bl_use_gpu_context = True
    bl_use_shading_nodes_custom = True

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._shaders = {}
        self._viewport_batches = {}
        self._viewport_batch_frames = {}
        self._viewport_dynamic_keys = set()
        self._viewport_textures = {}
        self._material_graph_cache = {}
        self._blur_graph_cache = {}
        self._viewport_post_buffers = None
        self._viewport_shadow_buffers = {}
        self._viewport_panorama_buffers = None
        self._viewport_panorama_bloom_buffers = None
        self._viewport_resolution_buffer = None

    def _cached_material_info(self, material):
        if material is None:
            key = 0
            signature = None
        else:
            key = material.original.as_pointer()
            tree = material.toon_tree
            signature = (tree.as_pointer() if tree else 0,
                         toon_nodes.tree_revision(tree),
                         material.toon_double_sided,
                         material.toon_unlit,
                         material.toon_cast_shadow,
                         material.toon_receive_shadow,
                         tuple(material.diffuse_color) if not tree else None)
        cached = self._material_graph_cache.get(key)
        if cached is None or cached[0] != signature:
            blur_names = ()
            attribute_names = {}
            if material is not None and tree:
                blur_names = tuple(node.name for node in tree.nodes
                                   if node.bl_idname == 'ToonBlurNode')
                attribute_names = {
                    toon_graph.vertex_color_attribute_id(node.attribute_name): node.attribute_name
                    for node in tree.nodes
                    if node.bl_idname == 'ToonVertexColorNode' and node.attribute_name
                }
                attribute_names.update({
                    toon_graph.uv_map_attribute_id(node.uv_map): node.uv_map
                    for node in tree.nodes
                    if node.bl_idname in {'ToonUVNode', 'ToonMappingNode',
                                          'ToonNormalMapNode'} and node.uv_map
                })
            cached = (signature, _material_surface(material), blur_names,
                      attribute_names)
            self._material_graph_cache[key] = cached
        return cached[1:]

    def _cached_blur_source(self, material, node_name):
        tree = material.toon_tree
        key = (material.original.as_pointer(), node_name)
        signature = (tree.as_pointer(), toon_nodes.tree_revision(tree))
        cached = self._blur_graph_cache.get(key)
        if cached is None or cached[0] != signature:
            cached = (signature, toon_graph.compile_blur_source(material, node_name))
            self._blur_graph_cache[key] = cached
        return copy.copy(cached[1])

    def _get_panorama_shader(self):
        key = ('PANORAMA',)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _POST_VERTEX_SHADER, panorama.COMPOSITE_FRAGMENT_SHADER)
        return self._shaders[key]

    def _draw_viewport_blit(self, texture, viewport):
        import gpu
        from gpu_extras.batch import batch_for_shader

        key = ('VIEWPORT_BLIT',)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _POST_VERTEX_SHADER, _VIEWPORT_BLIT_FRAGMENT_SHADER)
        shader = self._shaders[key]
        quad = batch_for_shader(gpu_compat.raw_shader(shader), 'TRIS', {'pos': (
            (-1.0, -1.0), (1.0, -1.0), (1.0, 1.0),
            (-1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))})
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('NONE')
        gpu_compat.bind_shader(shader)
        shader.uniform_sampler('source_color', texture)
        shader.uniform_float('viewport_origin', viewport[:2])
        shader.uniform_float('viewport_size', viewport[2:])
        gpu_compat.draw_batch(quad, shader)

    def _draw_panorama_composite(self, camera_data, faces, width, height,
                                 origin=(0, 0), outside_color=(0, 0, 0, 1),
                                 pixel_aspect=(1.0, 1.0)):
        import gpu
        from gpu_extras.batch import batch_for_shader

        shader = self._get_panorama_shader()
        quad = batch_for_shader(gpu_compat.raw_shader(shader), 'TRIS', {'pos': (
            (-1.0, -1.0), (1.0, -1.0), (1.0, 1.0),
            (-1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))})
        sensor = panorama.fisheye_sensor(camera_data, width, height,
                                        *pixel_aspect)
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('NONE')
        gpu.state.color_mask_set(True, True, True, True)
        gpu_compat.bind_shader(shader)
        for index, offscreen in enumerate(faces):
            shader.uniform_sampler(f'face_{index}', offscreen.texture_color)
        shader.uniform_int('projection_type',
                           int(camera_data.panorama_type == 'FISHEYE_EQUISOLID'))
        shader.uniform_float('angular_limits', (
            camera_data.longitude_min, camera_data.longitude_max,
            camera_data.latitude_min, camera_data.latitude_max))
        shader.uniform_float('fisheye_sensor_size', sensor)
        shader.uniform_float('fisheye_lens', max(camera_data.fisheye_lens, 1e-6))
        shader.uniform_float('fisheye_fov', camera_data.fisheye_fov)
        shader.uniform_float('outside_color', outside_color)
        shader.uniform_float('image_size', (width, height))
        shader.uniform_float('image_origin', origin)
        gpu_compat.draw_batch(quad, shader)

    def _panorama_bloom_buffers(self, width, height, bloom_effects, viewport):
        import gpu

        resolutions = tuple(sorted({effect.bloom_resolution for effect in bloom_effects}))
        key = (width, height, resolutions)
        if viewport and self._viewport_panorama_bloom_buffers:
            old_key, old_buffers = self._viewport_panorama_bloom_buffers
            if old_key == key:
                return old_buffers
            for buffer in old_buffers:
                buffer.free()
            self._viewport_panorama_bloom_buffers = None
        buffers = [gpu.types.GPUOffScreen(width, height, format='RGBA16F')
                   for _ in range(4)]
        for _ in range(2):
            buffers.extend(gpu.types.GPUOffScreen(
                max(1, round(width * resolution / 100.0 / 2 ** (level + 1))),
                max(1, round(height * resolution / 100.0 / 2 ** (level + 1))),
                format='RGBA16F')
                for resolution in resolutions for level in range(bloom.LEVEL_COUNT))
        if viewport:
            self._viewport_panorama_bloom_buffers = (key, buffers)
        return buffers

    def _draw_panorama_bloom_composite(self, camera_data, scene_faces,
                                       emission_faces, width, height,
                                       bloom_effects, background, pixel_aspect,
                                       buffers):
        import gpu

        with buffers[0].bind():
            gpu.state.viewport_set(0, 0, width, height)
            self._draw_panorama_composite(camera_data, scene_faces, width, height,
                                          outside_color=background,
                                          pixel_aspect=pixel_aspect)
        with buffers[1].bind():
            gpu.state.viewport_set(0, 0, width, height)
            self._draw_panorama_composite(camera_data, emission_faces, width, height,
                                          outside_color=(0.0, 0.0, 0.0, 0.0),
                                          pixel_aspect=pixel_aspect)
        resolutions = tuple(sorted({effect.bloom_resolution for effect in bloom_effects}))
        mip_start = 4
        up_start = mip_start + len(resolutions) * bloom.LEVEL_COUNT
        source = buffers[0].texture_color
        for index, effect in enumerate(bloom_effects):
            resolution_index = resolutions.index(effect.bloom_resolution)
            first = resolution_index * bloom.LEVEL_COUNT
            mips = buffers[mip_start + first:mip_start + first + bloom.LEVEL_COUNT]
            up_mips = buffers[up_start + first:up_start + first + bloom.LEVEL_COUNT]
            result = self._prepare_bloom_mips(
                buffers[1].texture_color, mips, up_mips,
                effect.bloom_threshold, effect.bloom_radius, width)
            target = buffers[2 + index % 2]
            with target.bind():
                gpu.state.viewport_set(0, 0, width, height)
                self._draw_bloom(source, result, effect)
            source = target.texture_color
        return source

    def _draw_panorama_bones(self, context, camera, frame_rect):
        import gpu
        from gpu_extras.batch import batch_for_shader

        key = ('BONE_LINES',)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _BONE_VERTEX_SHADER, _BONE_FRAGMENT_SHADER)
        shader = self._shaders[key]
        groups = {'NORMAL': [], 'SELECTED': [], 'ACTIVE': []}
        for armature, pose_bone, segments in _project_pose_bones(
                context, camera, frame_rect):
            if context.mode == 'POSE':
                active = armature.data.bones.active
                selected = _pose_bone_selected(pose_bone)
                kind = ('ACTIVE' if selected and active == pose_bone.bone else
                        'SELECTED' if selected else 'NORMAL')
            else:
                kind = ('ACTIVE' if context.active_object == armature else
                        'SELECTED' if armature.select_get() else 'NORMAL')
            for first, second in segments:
                groups[kind].extend((first, second))

        colors = {
            'NORMAL': (0.55, 0.8, 1.0, 0.95),
            'SELECTED': (1.0, 0.48, 0.08, 1.0),
            'ACTIVE': (1.0, 0.9, 0.18, 1.0),
        }
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('ALPHA')
        gpu.state.line_width_set(2.5)
        for kind, positions in groups.items():
            if not positions:
                continue
            batch = batch_for_shader(gpu_compat.raw_shader(shader), 'LINES',
                                     {'pos': positions})
            gpu_compat.bind_shader(shader)
            shader.uniform_float('region_size', (context.region.width,
                                                 context.region.height))
            shader.uniform_float('bone_color', colors[kind])
            gpu_compat.draw_batch(batch, shader)
        gpu.state.line_width_set(1.0)
        gpu.state.blend_set('NONE')

    def _draw_panorama_object_selection(self, context, camera, frame_rect):
        import gpu
        from gpu_extras.batch import batch_for_shader

        selected = [obj for obj in context.selected_objects if obj.visible_get()
                    and obj.type in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT',
                                     'ARMATURE', 'LATTICE'}]
        if not selected:
            return
        key = ('BONE_LINES',)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _BONE_VERTEX_SHADER, _BONE_FRAGMENT_SHADER)
        shader = self._shaders[key]
        inverse = camera.matrix_world.inverted()
        pixel_aspect = (context.scene.render.pixel_aspect_x,
                        context.scene.render.pixel_aspect_y)
        edges = ((0, 1), (1, 2), (2, 3), (3, 0),
                 (4, 5), (5, 6), (6, 7), (7, 4),
                 (0, 4), (1, 5), (2, 6), (3, 7))
        positions = []
        for obj in selected:
            corners = [inverse @ (obj.matrix_world @ Vector(corner))
                       for corner in obj.bound_box]
            for first, second in edges:
                previous = None
                for index in range(13):
                    point = corners[first].lerp(corners[second], index / 12)
                    projected = panorama.project_point(
                        point, camera.data, frame_rect, *pixel_aspect)
                    if previous is not None and projected is not None:
                        # Do not draw a seam-spanning edge across the whole image.
                        if abs(projected[0] - previous[0]) < frame_rect[2] * 0.25:
                            positions.extend((previous, projected))
                    previous = projected
        if not positions:
            return
        batch = batch_for_shader(gpu_compat.raw_shader(shader), 'LINES',
                                 {'pos': positions})
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('ALPHA')
        gpu.state.line_width_set(2.0)
        gpu_compat.bind_shader(shader)
        shader.uniform_float('region_size', (context.region.width,
                                             context.region.height))
        shader.uniform_float('bone_color', (1.0, 0.52, 0.08, 1.0))
        gpu_compat.draw_batch(batch, shader)
        gpu.state.line_width_set(1.0)
        gpu.state.blend_set('NONE')

    def _get_shader(self, graph):
        import gpu

        key = ('MATERIAL', graph.code)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _graph_vertex(_VERTEX_SHADER, graph),
                _graph_fragment(_FRAGMENT_SHADER, graph, compute_shadows=True))
        return self._shaders[key]

    def _get_geometry_shader(self, graph, material_ids=False):
        import gpu

        key = ('MATERIAL_ID' if material_ids else 'GEOMETRY', graph.code)
        if key not in self._shaders:
            source = _graph_fragment(_GEOMETRY_FRAGMENT_SHADER, graph)
            if material_ids:
                source = source.replace('out vec4 frag_color;',
                                        'uniform vec2 material_id;\nuniform float material_transmission_strength;\nout vec4 frag_color;')
                source = source.replace(
                    'frag_color = vec4(normalize(world_normal) * 0.5 + 0.5, distance_to_camera);',
                    'frag_color = vec4(material_id, material_transmission_strength, 1.0);')
            self._shaders[key] = gpu_compat.create_shader(
                _graph_vertex(_VERTEX_SHADER, graph), source)
        return self._shaders[key]

    def _get_emission_shader(self, graph):
        key = ('EMISSION', graph.code)
        if key not in self._shaders:
            source = _graph_fragment(_GEOMETRY_FRAGMENT_SHADER, graph)
            source = source.replace(
                'frag_color = vec4(normalize(world_normal) * 0.5 + 0.5, distance_to_camera);',
                'frag_color = vec4(toon_graph_emission(vec3(1.0)), alpha);')
            self._shaders[key] = gpu_compat.create_shader(
                _graph_vertex(_VERTEX_SHADER, graph), source)
        return self._shaders[key]

    def _get_proximity_shader(self, graph):
        import gpu

        key = ('PROXIMITY', graph.code)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _graph_vertex(_VERTEX_SHADER, graph),
                _graph_fragment(_PROXIMITY_FRAGMENT_SHADER, graph))
        return self._shaders[key]

    @staticmethod
    def _bind_proximity(shader, graph, proximity_buffers):
        if not graph.uses_proximity or not proximity_buffers:
            return
        try:
            shader.uniform_int('toon_proximity_active', 1)
        except ValueError:
            # Color-only proximity nodes are removed from alpha-only passes.
            return
        for sampler_name, specification in graph.proximity_filters.items():
            target, matrix = proximity_buffers[(graph.object_pointer, specification)]
            try:
                shader.uniform_sampler(sampler_name, target.texture_color)
            except ValueError:
                pass
            try:
                shader.uniform_float(sampler_name.replace('texture', 'matrix'), matrix)
            except ValueError:
                pass

    @staticmethod
    def _bind_blur(shader, graph, blur_buffers, origin):
        if not graph.blur_sources or not blur_buffers:
            return
        try:
            shader.uniform_int('toon_blur_origin', origin)
        except ValueError:
            return  # The alpha-only shader does not use a color-only Blur.
        for sampler, node_name in graph.blur_sources.items():
            key = (graph.object_pointer, graph.material_pointer, node_name)
            try:
                shader.uniform_sampler(sampler, blur_buffers[key].texture_color)
            except ValueError:
                pass

    def _draw_blur_buffers(self, depsgraph, view_matrix, projection_matrix,
                           priority_queues, textures, width, height,
                           shadow_maps, proximity_buffers):
        import gpu

        groups = {}
        required = set()
        for queues in priority_queues.values():
            for queue in queues:
                for item in queue:
                    graph = item[5]
                    group = (graph.object_pointer, graph.material_pointer)
                    groups.setdefault(group, []).append(item)
                    required.update((group[0], group[1], node_name)
                                    for node_name in graph.blur_sources.values())
        if not required:
            return {}
        materials = {material.as_pointer(): material for material in bpy.data.materials}
        buffers = {}

        def ensure(key, visiting):
            if key in buffers:
                return
            if key in visiting:
                raise ValueError('Blur nodes cannot form a cycle')
            object_pointer, material_pointer, node_name = key
            material = materials[material_pointer]
            source_graph = self._cached_blur_source(material, node_name)
            source_graph.object_pointer = object_pointer
            source_graph.material_pointer = material_pointer
            for dependency in source_graph.blur_sources.values():
                ensure((object_pointer, material_pointer, dependency), visiting | {key})
            target = gpu.types.GPUOffScreen(width, height, format='RGBA16F')
            buffers[key] = target
            source_items = []
            for item in groups[(object_pointer, material_pointer)]:
                source_item = list(item)
                source_item[0] = source_graph.code
                source_item[5] = source_graph
                source_item[6] = 'BLEND'
                source_item[7] = 0.0
                source_item[8] = True
                source_item[9] = 0.0
                source_items.append(tuple(source_item))
            with target.bind():
                gpu.state.viewport_set(0, 0, width, height)
                gpu.state.active_framebuffer_get().clear(
                    color=(0.0, 0.0, 0.0, 0.0), depth=1.0)
                self._draw_scene(depsgraph, view_matrix, projection_matrix,
                                 {}, textures, {0.0: (source_items, [])}, shadow_maps,
                                 proximity_buffers=proximity_buffers,
                                 blur_buffers=buffers)

        try:
            for key in required:
                ensure(key, set())
        except Exception:
            for target in buffers.values():
                target.free()
            raise
        return buffers

    def _get_outline_shader(self, selected_ids=None):
        import gpu

        key = ('OUTLINE', selected_ids)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _POST_VERTEX_SHADER,
                _OUTLINE_FRAGMENT_SHADER.replace(
                    '/* MATERIAL_SELECTION */', self._material_selection_code(selected_ids)))
        return self._shaders[key]

    @staticmethod
    def _material_selection_code(selected_ids):
        if selected_ids is None:
            return 'bool selected_material(ivec2 pixel) { return true; }'
        if not selected_ids:
            return 'bool selected_material(ivec2 pixel) { return false; }'
        inverted = selected_ids[0] == -1
        values = selected_ids[1:] if inverted else selected_ids
        comparisons = ' || '.join(
            f'all(equal(material_id, ivec2({value % 2048}, {value // 2048})))'
            for value in values)
        if inverted:
            selected = (f'!({comparisons})' if comparisons else 'true')
            selected = (f'!(all(equal(material_id, ivec2(0)))) && {selected}')
        else:
            selected = comparisons
        return ('bool selected_material(ivec2 pixel) {\n'
                '    ivec2 material_id = ivec2(texelFetch(material_id_texture, pixel, 0).rg + 0.5);\n'
                f'    return {selected};\n}}')

    def _get_mosaic_shader(self, selected_ids=None):
        import gpu

        key = ('MOSAIC', selected_ids)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _POST_VERTEX_SHADER,
                _MOSAIC_FRAGMENT_SHADER.replace(
                    '/* MATERIAL_SELECTION */', self._material_selection_code(selected_ids)))
        return self._shaders[key]

    def _get_color_adjust_shader(self, selected_ids=None):
        key = ('COLOR_ADJUST', selected_ids)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _POST_VERTEX_SHADER,
                color_adjust.FRAGMENT_SHADER.replace(
                    '/* MATERIAL_SELECTION */',
                    self._material_selection_code(selected_ids)))
        return self._shaders[key]

    def _get_bloom_shader(self):
        key = ('BLOOM',)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _POST_VERTEX_SHADER, bloom.composite_source())
        return self._shaders[key]

    def _get_bloom_downsample_shader(self, width, height):
        key = ('BLOOM_DOWNSAMPLE', width, height)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _POST_VERTEX_SHADER, bloom.downsample_source(width, height))
        return self._shaders[key]

    def _get_bloom_upsample_shader(self):
        key = ('BLOOM_UPSAMPLE',)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _POST_VERTEX_SHADER, bloom.upsample_source())
        return self._shaders[key]

    def _get_contact_mask_shader(self, transmission=False):
        import gpu

        key = ('CONTACT_MASK', transmission)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _POST_VERTEX_SHADER,
                ('#define TRANSMISSION\n' if transmission else '')
                + ambient_occlusion.MASK_FRAGMENT_SHADER)
        return self._shaders[key]

    def _get_ao_composite_shader(self, selected_ids=None):
        import gpu

        key = ('AO_COMPOSITE', selected_ids)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _POST_VERTEX_SHADER,
                ambient_occlusion.COMPOSITE_FRAGMENT_SHADER.replace(
                    '/* MATERIAL_SELECTION */',
                    self._material_selection_code(selected_ids)))
        return self._shaders[key]

    def _get_transmission_composite_shader(self, selected_ids=None):
        import gpu

        key = ('TRANSMISSION_COMPOSITE', selected_ids)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _POST_VERTEX_SHADER,
                color_transmission.COMPOSITE_FRAGMENT_SHADER.replace(
                    '/* MATERIAL_SELECTION */',
                    self._material_selection_code(selected_ids)))
        return self._shaders[key]

    def view_update(self, context, depsgraph):
        dirty_objects = set()
        dirty_meshes = set()
        armature_changed = False
        for update in depsgraph.updates:
            datablock = update.id
            if isinstance(datablock, bpy.types.Image):
                self._viewport_textures.pop(('IMAGE', datablock.as_pointer()), None)
            elif isinstance(datablock, bpy.types.Object):
                if datablock.type == 'MESH' and update.is_updated_geometry:
                    dirty_objects.add(datablock.original.as_pointer())
                elif datablock.type == 'ARMATURE':
                    armature_changed = True
            elif isinstance(datablock, bpy.types.Mesh):
                dirty_meshes.add(datablock.original.as_pointer())
            elif isinstance(datablock, (bpy.types.Armature, bpy.types.Key)):
                armature_changed = True
            elif isinstance(datablock, bpy.types.NodeTree):
                if datablock.bl_idname == 'ToonRenderNodeTree':
                    toon_nodes.invalidate_tree(datablock)
            elif isinstance(datablock, bpy.types.Material):
                self._material_graph_cache.pop(datablock.original.as_pointer(), None)
            elif isinstance(datablock, bpy.types.Texture):
                self._material_graph_cache.clear()
                self._blur_graph_cache.clear()
        if dirty_meshes:
            for obj in context.scene.objects:
                if obj.type == 'MESH' and obj.data.as_pointer() in dirty_meshes:
                    dirty_objects.add(obj.as_pointer())
        if armature_changed:
            dirty_objects.update(self._viewport_dynamic_keys)
        for key in dirty_objects:
            self._viewport_batches.pop(key, None)
        self.tag_redraw()

    def _collect_scene_items(self, depsgraph, view_matrix, cache):
        # Vertex buffers are shared by materials on the mesh, including their
        # requested color attributes.
        # Priority shifts the depth comparison by scene units. Keep one depth
        # buffer across materials so distant surfaces cannot jump to the front.
        priority_queues = {}
        viewport_cache = cache is self._viewport_batches
        frame_key = (depsgraph.scene_eval.frame_current,
                     depsgraph.scene_eval.frame_subframe) if viewport_cache else None
        seen_keys = set()
        for instance in depsgraph.object_instances:
            obj = instance.object
            if obj.type != 'MESH' or obj.hide_render:
                continue
            key = obj.original.as_pointer()
            if viewport_cache:
                seen_keys.add(key)
                if _needs_frame_rebuild(obj):
                    self._viewport_dynamic_keys.add(key)
                    if self._viewport_batch_frames.get(key) != frame_key:
                        cache.pop(key, None)
                        self._viewport_batch_frames[key] = frame_key
                else:
                    self._viewport_dynamic_keys.discard(key)
                    self._viewport_batch_frames.pop(key, None)
            materials = [slot.material for slot in obj.material_slots]
            material_infos = [self._cached_material_info(material)
                              for material in materials]
            material_graphs = [info[0] for info in material_infos]
            blur_graphs = [self._cached_blur_source(material, node_name)
                           for material, info in zip(materials, material_infos)
                           for node_name in info[1]]
            attribute_ids = tuple(sorted({attribute
                for graph in [entry[0] for entry in material_graphs] + blur_graphs
                for attribute in graph.vertex_attributes}))
            attribute_names = {}
            for info in material_infos:
                attribute_names.update(info[2])
            active_uv = obj.data.uv_layers.active
            cache_key = (attribute_ids, active_uv.name if active_uv else None)
            if key not in cache or cache[key][0] != cache_key:
                cache[key] = (cache_key, _mesh_batches(
                    obj, tuple((attribute, attribute_names[attribute])
                               for attribute in attribute_ids)))
            for slot, batch in cache[key][1]:
                material = obj.material_slots[slot].material if slot < len(obj.material_slots) else None
                graph, method, threshold, overlap, priority, double_sided, unlit, cast_shadow, receive_shadow = (
                    material_graphs[slot] if slot < len(material_graphs)
                    else self._cached_material_info(None)[0])
                graph = copy.copy(graph)
                graph.uniforms = graph.uniforms.copy()
                if 'toon_object_color' in graph.uniforms:
                    graph.uniforms['toon_object_color'] = tuple(obj.color)
                graph.object_pointer = obj.original.as_pointer()
                graph.material_pointer = material.original.as_pointer() if material else 0
                model = instance.matrix_world.copy()
                item = (graph.code, material.original.as_pointer() if material else 0,
                        (view_matrix @ model.translation).z, model, batch,
                        graph, method, threshold, overlap, priority,
                        double_sided, unlit, cast_shadow, receive_shadow)
                opaque_queue, transparent_queue = priority_queues.setdefault(priority, ([], []))
                if method == 'ADDITIVE' or (method == 'BLEND' and graph.dynamic_alpha):
                    transparent_queue.append(item)
                else:
                    opaque_queue.append(item)
        if viewport_cache:
            for key in cache.keys() - seen_keys:
                cache.pop(key, None)
                self._viewport_dynamic_keys.discard(key)
                self._viewport_batch_frames.pop(key, None)
        for opaque_queue, transparent_queue in priority_queues.values():
            opaque_queue.sort(key=lambda item: (item[0], item[1]))
            transparent_queue.sort(key=lambda item: (item[6] == 'ADDITIVE', item[2]))
        return priority_queues

    def _draw_proximity_buffers(self, depsgraph, view_matrix, projection_matrix,
                                priority_queues, textures, width, height):
        import gpu

        receivers = {(item[5].object_pointer, specification)
                     for queues in priority_queues.values()
                     for queue in queues for item in queue
                     for specification in item[5].proximity_filters.values()}
        materials = {material.as_pointer(): material for material in bpy.data.materials}
        for queues in priority_queues.values():
            for queue in queues:
                for item in queue:
                    graph = item[5]
                    if not graph.blur_sources:
                        continue
                    material = materials.get(graph.material_pointer)
                    if not material or not material.toon_tree:
                        continue
                    for node in material.toon_tree.nodes:
                        if node.bl_idname != 'ToonBlurNode':
                            continue
                        source_graph = self._cached_blur_source(material, node.name)
                        receivers.update((graph.object_pointer, specification)
                                         for specification in source_graph.proximity_filters.values())
        if not receivers:
            return {}
        buffers = {}
        receiver_bounds = {}
        receiver_ids = {receiver for receiver, _ in receivers}
        for instance in depsgraph.object_instances:
            obj = instance.object
            pointer = obj.original.as_pointer()
            if pointer not in receiver_ids or obj.type != 'MESH':
                continue
            receiver_bounds.setdefault(pointer, []).extend(
                instance.matrix_world @ Vector(corner) for corner in obj.bound_box)

        def get_texture(kind, source):
            return toon_graph.gpu_texture(kind, source, textures)

        try:
            for receiver, specification in receivers:
                selected_materials, direction_values, resolution, alpha_limit, distance = specification
                if direction_values == 'CAMERA':
                    light_matrix = projection_matrix @ view_matrix
                    buffer_width, buffer_height = width, height
                else:
                    direction = Vector(direction_values)
                    if direction.length_squared < 1e-10:
                        direction = Vector((0.0, 0.0, -1.0))
                    direction.normalize()
                    up_hint = (Vector((0.0, 0.0, 1.0)) if abs(direction.z) < 0.9
                               else Vector((0.0, 1.0, 0.0)))
                    right = direction.cross(up_hint).normalized()
                    up = right.cross(direction).normalized()
                    light_view = Matrix(((right.x, right.y, right.z, 0.0),
                                         (up.x, up.y, up.z, 0.0),
                                         (-direction.x, -direction.y, -direction.z, 0.0),
                                         (0.0, 0.0, 0.0, 1.0)))
                    corners = [light_view @ point for point in receiver_bounds[receiver]]
                    minimum = [min(point[axis] for point in corners) for axis in range(3)]
                    maximum = [max(point[axis] for point in corners) for axis in range(3)]
                    center = [(minimum[axis] + maximum[axis]) * 0.5 for axis in range(3)]
                    size = max(maximum[0] - minimum[0], maximum[1] - minimum[1], 0.1) * 1.05
                    depth_span = max(maximum[2] - minimum[2] + 2.0 * distance, 0.2)
                    light_projection = Matrix((
                        (2.0 / size, 0.0, 0.0, -2.0 * center[0] / size),
                        (0.0, 2.0 / size, 0.0, -2.0 * center[1] / size),
                        (0.0, 0.0, -2.0 / depth_span, 2.0 * center[2] / depth_span),
                        (0.0, 0.0, 0.0, 1.0)))
                    light_matrix = light_projection @ light_view
                    buffer_width = buffer_height = resolution
                target = gpu.types.GPUOffScreen(buffer_width, buffer_height, format='RGBA32F')
                buffers[(receiver, specification)] = (target, light_matrix)
                with target.bind():
                    gpu.state.viewport_set(0, 0, buffer_width, buffer_height)
                    gpu.state.active_framebuffer_get().clear(
                        color=(0.0, 0.0, 0.0, 0.0), depth=1.0)
                    gpu.state.depth_test_set('LESS_EQUAL')
                    gpu.state.depth_mask_set(True)
                    gpu.state.blend_set('NONE')
                    for opaque_queue, transparent_queue in priority_queues.values():
                        for item in opaque_queue + transparent_queue:
                            _, material_pointer, _, model, batch, graph, method, threshold, _, _, double_sided, _, _, _ = item
                            if graph.object_pointer == receiver:
                                continue
                            if (selected_materials is not None
                                    and material_pointer not in selected_materials):
                                continue
                            gpu.state.face_culling_set('NONE' if double_sided else 'BACK')
                            shader = self._get_proximity_shader(graph)
                            gpu_compat.bind_shader(shader)
                            _bind_depth_priority(shader, 0.0, projection_matrix)
                            shader.uniform_float('model_view_projection',
                                                 light_matrix @ model)
                            try:
                                shader.uniform_float('model_matrix', model)
                            except ValueError:
                                pass
                            try:
                                shader.uniform_float('view_matrix', view_matrix)
                            except ValueError:
                                pass
                            graph.bind(shader, get_texture, depsgraph)
                            shader.uniform_int('alpha_mode', 1 if method == 'CUTOUT' else 0)
                            shader.uniform_float('alpha_threshold', max(threshold, alpha_limit))
                            gpu_compat.draw_batch(batch, shader)
        except Exception:
            for target, _ in buffers.values():
                target.free()
            raise
        finally:
            gpu.state.depth_mask_set(False)
            gpu.state.depth_test_set('NONE')
            gpu.state.face_culling_set('NONE')
        return buffers

    def _draw_scene(self, depsgraph, view_matrix, projection_matrix, cache, textures,
                    priority_queues=None, shadow_maps=None, transparent_background=False,
                    proximity_buffers=None, blur_buffers=None, blur_origin=(0, 0)):
        import gpu

        if priority_queues is None:
            priority_queues = self._collect_scene_items(depsgraph, view_matrix, cache)
        if shadow_maps is None:
            shadow_maps = {}
        if proximity_buffers is None:
            proximity_buffers = {}
        if blur_buffers is None:
            blur_buffers = {}
        light_count, light_positions, light_colors, light_directions, light_inner = _scene_lights(depsgraph)
        ambient = _scene_ambient(depsgraph)
        camera_position = view_matrix.inverted().translation

        def get_texture(kind, source):
            return toon_graph.gpu_texture(kind, source, textures)

        try:
            gpu.state.depth_test_set('LESS_EQUAL')
            gpu.state.depth_mask_set(True)
            gpu.state.blend_set('NONE')
            gpu.state.face_culling_set('NONE')
            lit_shaders = set()
            for opaque_queue, transparent_queue in (_ordered_scene_items(priority_queues),):
                gpu.state.depth_mask_set(True)
                gpu.state.depth_test_set('LESS_EQUAL')
                gpu.state.blend_set('NONE')
                for index, item in enumerate(opaque_queue + transparent_queue):
                    if index == len(opaque_queue):
                        gpu.state.depth_mask_set(False)
                        gpu.state.blend_set('ALPHA')
                    shader_key, _, _, model, batch, graph, method, threshold, overlap, _priority, double_sided, unlit, _, receive_shadow = item
                    if method == 'ADDITIVE':
                        gpu.state.blend_set('ADDITIVE')
                    gpu.state.face_culling_set('NONE' if double_sided else 'BACK')
                    shader = self._get_shader(graph)
                    gpu_compat.bind_shader(shader)
                    _bind_depth_priority(shader, _priority, projection_matrix)
                    if shader_key not in lit_shaders and (graph.needs_lighting or graph.uses_shadow_mask):
                        shader.uniform_int('light_count', light_count)
                        if graph.needs_lighting:
                            try:
                                shader.uniform_float('camera_position', camera_position)
                            except ValueError:
                                pass
                            shader.uniform_int('ambient_mode', ambient[0])
                            shader.uniform_float('ambient_color', ambient[1])
                            shader.uniform_float('ambient_sky_color', ambient[2])
                            shader.uniform_float('ambient_ground_color', ambient[3])
                            shader.uniform_float('ambient_direction', ambient[4])
                            shader.uniform_float('ambient_intensity', ambient[5])
                        for light_index in range(_MAX_LIGHTS):
                            if graph.needs_lighting:
                                shader.uniform_float(f'light_position_type_{light_index}', light_positions[light_index])
                                shader.uniform_float(f'light_color_energy_{light_index}', light_colors[light_index])
                                shader.uniform_float(f'light_direction_angle_{light_index}', light_directions[light_index])
                                shader.uniform_float(f'light_spot_inner_{light_index}', light_inner[light_index])
                            shadow = shadow_maps.get(light_index)
                            if shadow:
                                kind, light_matrix, buffers, light, position, cascade = shadow
                                shader.uniform_float(f'shadow_settings_{light_index}', (
                                    light.toon_shadow_cascade_bias if kind == 'CASCADE'
                                    else light.toon_shadow_bias,
                                    light.toon_shadow_strength,
                                    light.toon_shadow_softness,
                                    light.toon_shadow_distance if kind == 'POINT'
                                    else float(cascade[3] if kind == 'CASCADE'
                                               else buffers[0].width)))
                                if kind == 'POINT':
                                    shader.uniform_float(f'shadow_position_{light_index}', position)
                                    shader.uniform_sampler(f'shadow_map_{light_index}_0', buffers[0])
                                    shader.uniform_sampler(f'shadow_map_{light_index}_1', buffers[1])
                                else:
                                    shader.uniform_float(f'shadow_matrix_{light_index}', light_matrix)
                                    shader.uniform_sampler(f'shadow_map_{light_index}_0',
                                                           buffers[0].texture_color)
                                    shader.uniform_sampler(f'shadow_map_{light_index}_1',
                                                           buffers[1].texture_color)
                                    if kind == 'CASCADE':
                                        splits, meta, transforms, _ = cascade
                                        shader.uniform_float(
                                            f'shadow_splits_{light_index}', splits)
                                        shader.uniform_float(
                                            f'shadow_cascade_meta_{light_index}', meta)
                                        for cascade_index in range(4):
                                            if cascade_index < len(transforms):
                                                transform, shift = transforms[cascade_index]
                                            else:
                                                transform = (1.0, 1.0, 1.0, 0.0)
                                                shift = (0.0, 0.0)
                                            shader.uniform_float(
                                                f'shadow_transform_{light_index}_{cascade_index}',
                                                transform)
                                            shader.uniform_float(
                                                f'shadow_shift_{light_index}_{cascade_index}',
                                                shift)
                        lit_shaders.add(shader_key)
                    if graph.needs_lighting or graph.uses_shadow_mask:
                        for light_index in range(_MAX_LIGHTS):
                            shadow = shadow_maps.get(light_index) if receive_shadow else None
                            shader.uniform_int(f'shadow_enabled_{light_index}',
                                               2 if shadow and shadow[0] == 'POINT'
                                                else 3 if shadow and shadow[0] == 'CASCADE'
                                                else 1 if shadow else 0)
                    shader.uniform_float('model_view_projection', projection_matrix @ view_matrix @ model)
                    shader.uniform_float('model_matrix', model)
                    try:
                        shader.uniform_float('view_matrix', view_matrix)
                    except ValueError:
                        pass
                    graph.bind(shader, get_texture, depsgraph)
                    self._bind_proximity(shader, graph, proximity_buffers)
                    self._bind_blur(shader, graph, blur_buffers, blur_origin)
                    shader.uniform_int('alpha_mode', 1 if method == 'CUTOUT' else 0)
                    shader.uniform_float('alpha_threshold', threshold)
                    if graph.needs_lighting:
                        shader.uniform_int('unlit', 1 if unlit else 0)
                    if method == 'BLEND' and not overlap and index >= len(opaque_queue):
                        gpu.state.blend_set('NONE')
                        gpu.state.color_mask_set(False, False, False, False)
                        gpu.state.depth_mask_set(True)
                        gpu_compat.draw_batch(batch, shader)
                        gpu.state.color_mask_set(True, True, True, True)
                        gpu.state.depth_mask_set(False)
                        gpu.state.depth_test_set('EQUAL')
                        gpu.state.blend_set('ALPHA')
                        gpu_compat.draw_batch(batch, shader)
                        gpu.state.depth_test_set('LESS_EQUAL')
                    else:
                        gpu_compat.draw_batch(batch, shader)
                    if method == 'ADDITIVE' and transparent_background:
                        gpu.state.color_mask_set(False, False, False, True)
                        gpu.state.blend_set('ALPHA')
                        gpu_compat.draw_batch(batch, shader)
                        gpu.state.color_mask_set(True, True, True, True)
                        gpu.state.blend_set('ADDITIVE')
        finally:
            gpu.state.color_mask_set(True, True, True, True)
            gpu.state.blend_set('NONE')
            gpu.state.depth_mask_set(False)
            gpu.state.depth_test_set('NONE')
            gpu.state.face_culling_set('NONE')

    def _draw_scene_shadows(self, depsgraph, view_matrix, projection_matrix,
                            cache, textures, width, height, viewport=False,
                            output_offscreen=None, transparent_background=False,
                            retain_proximity=False):
        import gpu

        priority_queues = self._collect_scene_items(depsgraph, view_matrix, cache)
        framebuffer = gpu.state.active_framebuffer_get()
        target_viewport = gpu.state.viewport_get()
        if target_viewport[2] == 0 or target_viewport[3] == 0:
            target_viewport = (0, 0, width, height)
        scene = depsgraph.scene_eval
        if ((viewport and not scene.toon_viewport_shadows)
                or (not viewport and not scene.toon_render_shadows)):
            shadow_maps, transient = {}, []
        else:
            shadow_maps, transient = shadows.render_shadow_maps(
                self, depsgraph, view_matrix, projection_matrix,
                priority_queues, textures, viewport)
        proximity_buffers = {}
        blur_buffers = {}
        world = depsgraph.scene_eval.world
        background = tuple(world.toon_background_color) if world else (0.05, 0.05, 0.05)
        clear_color = ((0.0, 0.0, 0.0, 0.0) if transparent_background
                       else (*background, 1.0))
        completed = False
        try:
            proximity_buffers = self._draw_proximity_buffers(
                depsgraph, view_matrix, projection_matrix, priority_queues,
                textures, width, height)
            blur_buffers = self._draw_blur_buffers(
                depsgraph, view_matrix, projection_matrix, priority_queues,
                textures, width, height, shadow_maps, proximity_buffers)
            if shadow_maps or proximity_buffers or blur_buffers:
                binding = output_offscreen.bind() if output_offscreen else framebuffer.bind()
                with binding:
                    gpu.state.viewport_set(*target_viewport)
                    gpu.state.active_framebuffer_get().clear(
                        color=clear_color, depth=1.0)
                    self._draw_scene(depsgraph, view_matrix, projection_matrix,
                                     cache, textures, priority_queues, shadow_maps,
                                     transparent_background, proximity_buffers,
                                     blur_buffers, target_viewport[:2])
            else:
                gpu.state.viewport_set(*target_viewport)
                framebuffer.clear(color=clear_color, depth=1.0)
                self._draw_scene(depsgraph, view_matrix, projection_matrix,
                                 cache, textures, priority_queues,
                                 transparent_background=transparent_background,
                                 proximity_buffers=proximity_buffers,
                                 blur_buffers=blur_buffers,
                                 blur_origin=target_viewport[:2])
            completed = True
        finally:
            for offscreen in transient:
                offscreen.free()
            if not retain_proximity or not completed:
                for offscreen, _ in proximity_buffers.values():
                    offscreen.free()
                for offscreen in blur_buffers.values():
                    offscreen.free()
        return ((priority_queues, proximity_buffers, blur_buffers)
                if retain_proximity else priority_queues)

    def _draw_geometry(self, depsgraph, view_matrix, projection_matrix, priority_queues,
                       textures, material_ids=None, occlusion_alpha_threshold=None,
                       selected_material_pointers=(), proximity_buffers=None,
                       blur_buffers=None):
        import gpu

        def get_texture(kind, source):
            return toon_graph.gpu_texture(kind, source, textures)

        materials = ({material.original.as_pointer(): material
                      for material in bpy.data.materials} if material_ids is not None else {})
        try:
            gpu.state.depth_test_set('LESS_EQUAL')
            gpu.state.depth_mask_set(True)
            gpu.state.blend_set('NONE')
            gpu.state.face_culling_set('NONE')
            for opaque_queue, transparent_queue in (_ordered_scene_items(priority_queues),):
                for item in opaque_queue + transparent_queue:
                    _, material_pointer, _, model, batch, graph, method, threshold, _, priority, double_sided, _, _, _ = item
                    gpu.state.face_culling_set('NONE' if double_sided else 'BACK')
                    shader = self._get_geometry_shader(graph, material_ids is not None)
                    gpu_compat.bind_shader(shader)
                    _bind_depth_priority(shader, priority, projection_matrix)
                    shader.uniform_float('model_view_projection', projection_matrix @ view_matrix @ model)
                    try:
                        shader.uniform_float('model_matrix', model)
                    except ValueError:
                        pass
                    try:
                        shader.uniform_float('view_matrix', view_matrix)
                    except ValueError:
                        pass
                    if material_ids is not None:
                        material_id = material_ids[material_pointer]
                        shader.uniform_float('material_id',
                                             (float(material_id % 2048),
                                              float(material_id // 2048)))
                        material = materials.get(material_pointer)
                        shader.uniform_float('material_transmission_strength',
                                             material.toon_transmission_strength if material else 1.0)
                    graph.bind(shader, get_texture, depsgraph)
                    self._bind_proximity(shader, graph, proximity_buffers)
                    self._bind_blur(shader, graph, blur_buffers, (0, 0))
                    shader.uniform_int('alpha_mode', 1 if method == 'CUTOUT' else 0)
                    effective_threshold = threshold
                    if (occlusion_alpha_threshold is not None
                            and method in {'BLEND', 'ADDITIVE'}
                            and material_pointer not in selected_material_pointers):
                        effective_threshold = max(threshold, min(occlusion_alpha_threshold, 0.999))
                    shader.uniform_float('alpha_threshold', effective_threshold)
                    gpu_compat.draw_batch(batch, shader)
        finally:
            gpu.state.depth_mask_set(False)
            gpu.state.depth_test_set('NONE')
            gpu.state.face_culling_set('NONE')

    def _draw_emission(self, depsgraph, view_matrix, projection_matrix,
                       priority_queues, textures, proximity_buffers, blur_buffers):
        import gpu

        def get_texture(kind, source):
            return toon_graph.gpu_texture(kind, source, textures)

        try:
            gpu.state.depth_test_set('LESS_EQUAL')
            gpu.state.face_culling_set('NONE')
            for opaque, transparent in (_ordered_scene_items(priority_queues),):
                for index, item in enumerate(opaque + transparent):
                    _, _, _, model, batch, graph, method, threshold, _, priority, double_sided, _, _, _ = item
                    if index == len(opaque):
                        gpu.state.depth_mask_set(False)
                        gpu.state.blend_set('ALPHA')
                    elif index == 0:
                        gpu.state.depth_mask_set(True)
                        gpu.state.blend_set('NONE')
                    gpu.state.face_culling_set('NONE' if double_sided else 'BACK')
                    shader = self._get_emission_shader(graph)
                    gpu_compat.bind_shader(shader)
                    _bind_depth_priority(shader, priority, projection_matrix)
                    shader.uniform_float('model_view_projection', projection_matrix @ view_matrix @ model)
                    try:
                        shader.uniform_float('model_matrix', model)
                    except ValueError:
                        pass
                    try:
                        shader.uniform_float('view_matrix', view_matrix)
                    except ValueError:
                        pass
                    graph.bind(shader, get_texture, depsgraph)
                    self._bind_proximity(shader, graph, proximity_buffers)
                    self._bind_blur(shader, graph, blur_buffers, (0, 0))
                    shader.uniform_int('alpha_mode', 1 if method == 'CUTOUT' else 0)
                    shader.uniform_float('alpha_threshold', threshold)
                    if method == 'ADDITIVE':
                        gpu.state.blend_set('ADDITIVE')
                    gpu_compat.draw_batch(batch, shader)
                    if method == 'ADDITIVE':
                        gpu.state.blend_set('ALPHA')
        finally:
            gpu.state.depth_mask_set(False)
            gpu.state.depth_test_set('NONE')
            gpu.state.blend_set('NONE')
            gpu.state.face_culling_set('NONE')

    def _draw_emission_to_offscreen(self, target, depsgraph, view_matrix,
                                    projection_matrix, priority_queues, textures,
                                    proximity_buffers, blur_buffers):
        import gpu

        with target.bind():
            gpu.state.viewport_set(0, 0, target.width, target.height)
            gpu.state.active_framebuffer_get().clear(
                color=(0.0, 0.0, 0.0, 0.0), depth=1.0)
            if any(item[5].has_emission for queues in priority_queues.values()
                   for queue in queues for item in queue):
                self._draw_emission(depsgraph, view_matrix, projection_matrix,
                                    priority_queues, textures, proximity_buffers,
                                    blur_buffers)

    def _draw_outline(self, source_texture, geometry_texture, effect,
                      origin=(0, 0), material_id_texture=None, selected_ids=None):
        import gpu
        from gpu_extras.batch import batch_for_shader

        shader = self._get_outline_shader(selected_ids)
        quad = batch_for_shader(gpu_compat.raw_shader(shader), 'TRIS', {'pos': (
            (-1.0, -1.0), (1.0, -1.0), (1.0, 1.0),
            (-1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))})
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('NONE')
        gpu.state.color_mask_set(True, True, True, True)
        gpu_compat.bind_shader(shader)
        shader.uniform_sampler('source_color', source_texture)
        if selected_ids == ():
            shader.uniform_int('target_origin', origin)
            gpu_compat.draw_batch(quad, shader)
            return
        shader.uniform_sampler('geometry_texture', geometry_texture)
        if selected_ids:
            shader.uniform_sampler('material_id_texture', material_id_texture)
        shader.uniform_float('line_color', effect.color)
        shader.uniform_float('thickness', effect.thickness)
        shader.uniform_float('depth_threshold', effect.depth_threshold)
        shader.uniform_float('normal_threshold', effect.normal_threshold)
        shader.uniform_float('opacity', effect.opacity)
        shader.uniform_int('target_origin', origin)
        gpu_compat.draw_batch(quad, shader)

    def _draw_mosaic(self, source_texture, effect, origin=(0, 0),
                     material_id_texture=None, selected_ids=None):
        import gpu
        from gpu_extras.batch import batch_for_shader

        shader = self._get_mosaic_shader(selected_ids)
        quad = batch_for_shader(gpu_compat.raw_shader(shader), 'TRIS', {'pos': (
            (-1.0, -1.0), (1.0, -1.0), (1.0, 1.0),
            (-1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))})
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('NONE')
        gpu.state.color_mask_set(True, True, True, True)
        gpu_compat.bind_shader(shader)
        shader.uniform_sampler('source_color', source_texture)
        shader.uniform_int('target_origin', origin)
        if selected_ids != ():
            if selected_ids:
                shader.uniform_sampler('material_id_texture', material_id_texture)
            shader.uniform_int('pixel_size', effect.pixel_size)
            shader.uniform_float('opacity', effect.opacity)
        gpu_compat.draw_batch(quad, shader)

    def _draw_color_adjust(self, source_texture, effect, origin=(0, 0),
                           material_id_texture=None, selected_ids=None):
        import gpu
        from gpu_extras.batch import batch_for_shader

        shader = self._get_color_adjust_shader(selected_ids)
        quad = batch_for_shader(gpu_compat.raw_shader(shader), 'TRIS', {'pos': (
            (-1.0, -1.0), (1.0, -1.0), (1.0, 1.0),
            (-1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))})
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('NONE')
        gpu.state.color_mask_set(True, True, True, True)
        gpu_compat.bind_shader(shader)
        shader.uniform_sampler('source_color', source_texture)
        shader.uniform_int('target_origin', origin)
        if selected_ids != ():
            if selected_ids:
                shader.uniform_sampler('material_id_texture', material_id_texture)
            shader.uniform_float('brightness', effect.adjust_brightness)
            shader.uniform_float('contrast', effect.adjust_contrast)
            shader.uniform_float('saturation', effect.adjust_saturation)
            shader.uniform_float('luminance', effect.adjust_luminance)
            shader.uniform_float('gamma_value', effect.adjust_gamma)
            shader.uniform_float('tint', effect.adjust_tint)
            shader.uniform_float('tint_color', effect.adjust_tint_color)
            shader.uniform_int('tint_mode', ('MIX', 'MULTIPLY', 'OVERLAY', 'BURN',
                'DODGE', 'ADD', 'SCREEN', 'SOFT_LIGHT', 'HARD_LIGHT', 'DIFFERENCE',
                'SUBTRACT').index(effect.adjust_tint_mode))
            shader.uniform_float('opacity', effect.opacity)
        gpu_compat.draw_batch(quad, shader)

    def _prepare_bloom_mips(self, emission_texture, levels, up_levels,
                            threshold, radius, full_width):
        import gpu
        from gpu_extras.batch import batch_for_shader

        previous = emission_texture
        for index, target in enumerate(levels):
            with target.bind():
                gpu.state.viewport_set(0, 0, target.width, target.height)
                shader = self._get_bloom_downsample_shader(target.width, target.height)
                quad = batch_for_shader(gpu_compat.raw_shader(shader), 'TRIS', {'pos': (
                    (-1.0, -1.0), (1.0, -1.0), (1.0, 1.0),
                    (-1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))})
                gpu.state.depth_test_set('NONE')
                gpu.state.depth_mask_set(False)
                gpu.state.blend_set('NONE')
                gpu_compat.bind_shader(shader)
                shader.uniform_sampler('source_texture', previous)
                shader.uniform_float('threshold', threshold)
                shader.uniform_int('prefilter', 1 if index == 0 else 0)
                gpu_compat.draw_batch(quad, shader)
            previous = target.texture_color

        weights = []
        for level in levels:
            footprint = max(float(full_width) / level.width, 1.0)
            distance_scale = math.log2(max(radius, 1.0) / footprint)
            weights.append(math.exp(-0.4 * distance_scale * distance_scale))
        shader = self._get_bloom_upsample_shader()
        quad = batch_for_shader(gpu_compat.raw_shader(shader), 'TRIS', {'pos': (
            (-1.0, -1.0), (1.0, -1.0), (1.0, 1.0),
            (-1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))})
        for index in range(len(levels) - 1, -1, -1):
            target = up_levels[index]
            with target.bind():
                gpu.state.viewport_set(0, 0, target.width, target.height)
                gpu.state.depth_test_set('NONE')
                gpu.state.depth_mask_set(False)
                gpu.state.blend_set('NONE')
                gpu_compat.bind_shader(shader)
                shader.uniform_sampler('source_detail', levels[index].texture_color)
                shader.uniform_sampler('source_small',
                    up_levels[index + 1].texture_color if index + 1 < len(levels)
                    else levels[index].texture_color)
                shader.uniform_float('detail_weight', weights[index])
                shader.uniform_int('include_small', 1 if index + 1 < len(levels) else 0)
                gpu_compat.draw_batch(quad, shader)
        return up_levels[0], 1.0 / max(sum(weights), 0.0001)

    def _draw_bloom(self, source_texture, bloom_result, effect, origin=(0, 0)):
        import gpu
        from gpu_extras.batch import batch_for_shader

        shader = self._get_bloom_shader()
        quad = batch_for_shader(gpu_compat.raw_shader(shader), 'TRIS', {'pos': (
            (-1.0, -1.0), (1.0, -1.0), (1.0, 1.0),
            (-1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))})
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('NONE')
        gpu_compat.bind_shader(shader)
        shader.uniform_sampler('source_color', source_texture)
        shader.uniform_sampler('bloom_texture', bloom_result[0].texture_color)
        shader.uniform_int('target_origin', origin)
        shader.uniform_float('normalization', bloom_result[1])
        shader.uniform_float('strength', effect.bloom_strength)
        shader.uniform_float('opacity', effect.opacity)
        gpu_compat.draw_batch(quad, shader)

    def _draw_contact_mask(self, source_texture, geometry_texture, effect,
                           view_matrix, projection_matrix, width, height,
                           material_strength_texture=None):
        import gpu
        from gpu_extras.batch import batch_for_shader

        transmission = effect.effect_type == 'TRANSMISSION'
        shader = self._get_contact_mask_shader(transmission)
        quad = batch_for_shader(gpu_compat.raw_shader(shader), 'TRIS', {'pos': (
            (-1.0, -1.0), (1.0, -1.0), (1.0, 1.0),
            (-1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))})
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('NONE')
        gpu.state.color_mask_set(True, True, True, True)
        gpu_compat.bind_shader(shader)
        if transmission:
            shader.uniform_sampler('source_color', source_texture)
            shader.uniform_sampler('material_strength_texture',
                                   material_strength_texture)
        shader.uniform_sampler('geometry_texture', geometry_texture)
        shader.uniform_float('inverse_projection', projection_matrix.inverted())
        shader.uniform_float('view_matrix', view_matrix)
        shader.uniform_float('projection_y_scale', abs(projection_matrix[1][1]))
        shader.uniform_float('radius', effect.ao_radius)
        shader.uniform_float('strength', effect.ao_strength)
        shader.uniform_float('bias', effect.ao_bias)
        if transmission:
            shader.uniform_float('transmission_strength', effect.transmission_strength)
        else:
            shader.uniform_int('cavity_type',
                               {'WORLD': 0, 'SCREEN': 1, 'BOTH': 2}[effect.ao_cavity_type])
        shader.uniform_int('sample_count', effect.ao_samples)
        shader.uniform_int('orthographic_camera',
                           1 if abs(projection_matrix[3][3]) > 0.5 else 0)
        shader.uniform_float('ao_resolution', (width, height))
        gpu_compat.draw_batch(quad, shader)

    def _draw_contact_effect(self, source_texture, geometry_texture, ao_texture,
                             effect, origin=(0, 0), material_id_texture=None,
                             selected_ids=None):
        import gpu
        from gpu_extras.batch import batch_for_shader

        transmission = effect.effect_type == 'TRANSMISSION'
        shader = (self._get_transmission_composite_shader(selected_ids)
                  if transmission else self._get_ao_composite_shader(selected_ids))
        quad = batch_for_shader(gpu_compat.raw_shader(shader), 'TRIS', {'pos': (
            (-1.0, -1.0), (1.0, -1.0), (1.0, 1.0),
            (-1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))})
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('NONE')
        gpu.state.color_mask_set(True, True, True, True)
        gpu_compat.bind_shader(shader)
        shader.uniform_sampler('source_color', source_texture)
        shader.uniform_sampler('geometry_texture', geometry_texture)
        shader.uniform_sampler('ao_texture', ao_texture)
        if selected_ids:
            shader.uniform_sampler('material_id_texture', material_id_texture)
        shader.uniform_float('opacity', effect.opacity)
        shader.uniform_float('radius', effect.ao_radius)
        shader.uniform_int('denoise', 1 if effect.ao_denoise else 0)
        if transmission:
            shader.uniform_int('blend_mode', {
                'MIX': 0, 'ADD': 1, 'SCREEN': 2, 'OVERLAY': 3,
            }[effect.transmission_blend_mode])
        else:
            shader.uniform_float('effect_color', effect.ao_color)
            shader.uniform_int('cavity_type',
                               {'WORLD': 0, 'SCREEN': 1, 'BOTH': 2}[effect.ao_cavity_type])
            shader.uniform_float('world_ridge', effect.ao_world_ridge)
            shader.uniform_float('world_valley', effect.ao_world_valley)
            shader.uniform_float('screen_ridge', effect.ao_screen_ridge)
            shader.uniform_float('screen_valley', effect.ao_screen_valley)
        shader.uniform_int('target_origin', origin)
        gpu_compat.draw_batch(quad, shader)

    def _draw_post_effect(self, source_texture, geometry_texture, effect,
                          origin=(0, 0), material_id_texture=None, selected_ids=None,
                          ao_texture=None, emission_texture=None):
        if effect.effect_type == 'MOSAIC':
            self._draw_mosaic(source_texture, effect, origin,
                              material_id_texture, selected_ids)
        elif effect.effect_type == 'COLOR_ADJUST':
            self._draw_color_adjust(source_texture, effect, origin,
                                    material_id_texture, selected_ids)
        elif effect.effect_type == 'BLOOM':
            self._draw_bloom(source_texture, emission_texture, effect, origin)
        elif effect.effect_type in {'AO', 'TRANSMISSION'}:
            self._draw_contact_effect(source_texture, geometry_texture,
                                      ao_texture, effect, origin,
                                      material_id_texture, selected_ids)
        else:
            self._draw_outline(source_texture, geometry_texture, effect, origin,
                               material_id_texture, selected_ids)

    @staticmethod
    def _ao_mask_key(effect):
        # The AO mask reads geometry only. Color, opacity, denoise and material
        # selection belong to the later composite pass and may differ freely.
        return (effect.occlusion_alpha_threshold, effect.ao_resolution,
                effect.ao_radius, effect.ao_strength, effect.ao_bias,
                effect.ao_samples, effect.ao_cavity_type)

    @staticmethod
    def _bloom_key(effect):
        # Emission is rendered before the post stack; strength and opacity
        # affect only the final composite, not the mip chain.
        return (effect.bloom_resolution, effect.bloom_threshold,
                effect.bloom_radius)

    def _draw_with_effects(self, depsgraph, view_matrix, projection_matrix,
                           cache, textures, width, height, effects, viewport=False,
                           output_offscreen=None, transparent_background=False,
                           emission_output=None):
        import gpu

        # On Vulkan, creating a GPUOffScreen can change the active framebuffer.
        # Capture the destination before allocating intermediate passes.
        target_framebuffer = gpu.state.active_framebuffer_get()
        target_viewport = gpu.state.viewport_get()

        def selected_pointers(effect):
            if not effect.limit_to_materials:
                return ()
            return tuple(sorted({item.material.original.as_pointer()
                                 for item in effect.materials if item.material}))

        effect_selections = [selected_pointers(effect) for effect in effects]
        all_material_pointers = None
        if any(effect.limit_to_materials and effect.invert_materials
               for effect in effects):
            all_material_pointers = {0}
            all_material_pointers.update(
                slot.material.original.as_pointer()
                for obj in depsgraph.scene_eval.objects if obj.type == 'MESH'
                for slot in obj.material_slots if slot.material)
        geometry_selections = [
            tuple(sorted(all_material_pointers.difference(effect_selections[index])))
            if effect.limit_to_materials and effect.invert_materials
            else effect_selections[index] if effect.limit_to_materials else ()
            for index, effect in enumerate(effects)]
        geometry_keys = list(dict.fromkeys(
            (effect.occlusion_alpha_threshold,
             geometry_selections[index] if effect.effect_type == 'OUTLINE' else ())
            for index, effect in enumerate(effects)
            if effect.effect_type in {'OUTLINE', 'AO', 'TRANSMISSION'}))
        id_keys = []
        for index, effect in enumerate(effects):
            if effect.effect_type == 'TRANSMISSION':
                key = (effect.occlusion_alpha_threshold, ())
                if key not in id_keys:
                    id_keys.append(key)
            if effect.limit_to_materials and (effect_selections[index]
                                              or effect.invert_materials):
                key = (effect.occlusion_alpha_threshold,
                       geometry_selections[index])
                if key not in id_keys:
                    id_keys.append(key)
        count = (1 + len(geometry_keys) + len(id_keys)
                 + min(2, max(0, len(effects) - 1)))
        ao_mask_counts = {}
        for effect in effects:
            if effect.effect_type == 'AO':
                key = self._ao_mask_key(effect)
                ao_mask_counts[key] = ao_mask_counts.get(key, 0) + 1
        shared_ao_keys = tuple(key for key, count in ao_mask_counts.items()
                               if count > 1)
        shared_ao_resolutions = tuple(key[1] for key in shared_ao_keys)
        ao_resolutions = tuple(sorted({effect.ao_resolution for effect in effects
            if effect.effect_type == 'TRANSMISSION'
            or (effect.effect_type == 'AO'
                and self._ao_mask_key(effect) not in shared_ao_keys)}))
        bloom_resolutions = tuple(sorted({effect.bloom_resolution for effect in effects
                                          if effect.effect_type == 'BLOOM'}))
        bloom_counts = {}
        for effect in effects:
            if effect.effect_type == 'BLOOM':
                key = self._bloom_key(effect)
                bloom_counts[key] = bloom_counts.get(key, 0) + 1
        shared_bloom_keys = tuple(key for key, count in bloom_counts.items()
                                  if count > 1)
        shared_bloom_resolutions = tuple(key[0] for key in shared_bloom_keys)
        bloom_scratch_resolutions = tuple(sorted({effect.bloom_resolution
            for effect in effects if effect.effect_type == 'BLOOM'
            and self._bloom_key(effect) not in shared_bloom_keys}))
        size_key = (width, height, count, len(geometry_keys), len(id_keys),
                    ao_resolutions, shared_ao_resolutions, bloom_resolutions,
                    bloom_scratch_resolutions, shared_bloom_resolutions)
        if viewport and self._viewport_post_buffers and self._viewport_post_buffers[0] != size_key:
            for offscreen in self._viewport_post_buffers[1]:
                offscreen.free()
            self._viewport_post_buffers = None
        if viewport and self._viewport_post_buffers:
            buffers = self._viewport_post_buffers[1]
        else:
            buffers = [gpu.types.GPUOffScreen(width, height, format='RGBA16F')
                       for _ in range(count)]
            buffers.extend(gpu.types.GPUOffScreen(
                max(1, round(width * resolution / 100.0)),
                max(1, round(height * resolution / 100.0)), format='RGBA16F')
                for resolution in ao_resolutions)
            buffers.extend(gpu.types.GPUOffScreen(
                max(1, round(width * resolution / 100.0)),
                max(1, round(height * resolution / 100.0)), format='RGBA16F')
                for resolution in shared_ao_resolutions)
            buffers.extend(gpu.types.GPUOffScreen(
                max(1, round(width * resolution / 100.0)),
                max(1, round(height * resolution / 100.0)), format='RGBA16F')
                for resolution in bloom_resolutions)
            buffers.extend(gpu.types.GPUOffScreen(
                max(1, round(width * resolution / 100.0 / (2 ** (level + 1)))),
                max(1, round(height * resolution / 100.0 / (2 ** (level + 1)))),
                format='RGBA16F')
                for resolution in bloom_scratch_resolutions
                for level in range(bloom.LEVEL_COUNT))
            buffers.extend(gpu.types.GPUOffScreen(
                max(1, round(width * resolution / 100.0 / (2 ** (level + 1)))),
                max(1, round(height * resolution / 100.0 / (2 ** (level + 1)))),
                format='RGBA16F')
                for resolution in bloom_scratch_resolutions
                for level in range(bloom.LEVEL_COUNT))
            buffers.extend(gpu.types.GPUOffScreen(
                max(1, round(width * resolution / 100.0 / (2 ** (level + 1)))),
                max(1, round(height * resolution / 100.0 / (2 ** (level + 1)))),
                format='RGBA16F')
                for resolution in shared_bloom_resolutions
                for level in range(bloom.LEVEL_COUNT))
            buffers.extend(gpu.types.GPUOffScreen(
                max(1, round(width * resolution / 100.0 / (2 ** (level + 1)))),
                max(1, round(height * resolution / 100.0 / (2 ** (level + 1)))),
                format='RGBA16F')
                for resolution in shared_bloom_resolutions
                for level in range(bloom.LEVEL_COUNT))
            if viewport:
                self._viewport_post_buffers = (size_key, buffers)
        scene_buffer = buffers[0]
        geometry_buffers = dict(zip(geometry_keys, buffers[1:1 + len(geometry_keys)]))
        id_buffers = dict(zip(id_keys,
                              buffers[1 + len(geometry_keys):
                                      1 + len(geometry_keys) + len(id_keys)]))
        ping_buffers = buffers[1 + len(geometry_keys) + len(id_keys):count]
        ao_buffers = dict(zip(ao_resolutions, buffers[count:count + len(ao_resolutions)]))
        shared_start = count + len(ao_resolutions)
        shared_ao_buffers = dict(zip(shared_ao_keys,
                                     buffers[shared_start:shared_start + len(shared_ao_keys)]))
        bloom_start = shared_start + len(shared_ao_keys)
        bloom_buffers = dict(zip(bloom_resolutions,
                                 buffers[bloom_start:bloom_start + len(bloom_resolutions)]))
        mip_start = bloom_start + len(bloom_resolutions)
        bloom_mips = {resolution: buffers[
            mip_start + index * bloom.LEVEL_COUNT:
            mip_start + (index + 1) * bloom.LEVEL_COUNT]
            for index, resolution in enumerate(bloom_scratch_resolutions)}
        up_start = mip_start + len(bloom_scratch_resolutions) * bloom.LEVEL_COUNT
        bloom_up_mips = {resolution: buffers[
            up_start + index * bloom.LEVEL_COUNT:
            up_start + (index + 1) * bloom.LEVEL_COUNT]
            for index, resolution in enumerate(bloom_scratch_resolutions)}
        shared_mip_start = up_start + len(bloom_scratch_resolutions) * bloom.LEVEL_COUNT
        shared_bloom_mips = {key: buffers[
            shared_mip_start + index * bloom.LEVEL_COUNT:
            shared_mip_start + (index + 1) * bloom.LEVEL_COUNT]
            for index, key in enumerate(shared_bloom_keys)}
        shared_up_start = shared_mip_start + len(shared_bloom_keys) * bloom.LEVEL_COUNT
        shared_bloom_up_mips = {key: buffers[
            shared_up_start + index * bloom.LEVEL_COUNT:
            shared_up_start + (index + 1) * bloom.LEVEL_COUNT]
            for index, key in enumerate(shared_bloom_keys)}
        if target_viewport[2] == 0 or target_viewport[3] == 0:
            target_viewport = (0, 0, width, height)
        proximity_buffers = {}
        blur_buffers = {}
        try:
            with scene_buffer.bind():
                gpu.state.viewport_set(0, 0, width, height)
                priority_queues, proximity_buffers, blur_buffers = self._draw_scene_shadows(
                    depsgraph, view_matrix, projection_matrix, cache, textures,
                    width, height, viewport, scene_buffer, transparent_background,
                    retain_proximity=True)
            if emission_output is not None:
                self._draw_emission_to_offscreen(
                    emission_output, depsgraph, view_matrix, projection_matrix,
                    priority_queues, textures, proximity_buffers, blur_buffers)
            if bloom_buffers:
                for emission_buffer in bloom_buffers.values():
                    self._draw_emission_to_offscreen(
                        emission_buffer, depsgraph, view_matrix, projection_matrix,
                        priority_queues, textures, proximity_buffers, blur_buffers)
            for (threshold, selected), geometry_buffer in geometry_buffers.items():
                with geometry_buffer.bind():
                    gpu.state.viewport_set(0, 0, width, height)
                    gpu.state.active_framebuffer_get().clear(
                        color=(0.0, 0.0, 0.0, 0.0), depth=1.0)
                    self._draw_geometry(depsgraph, view_matrix, projection_matrix,
                                        priority_queues, textures,
                                        occlusion_alpha_threshold=threshold,
                                        selected_material_pointers=selected,
                                        proximity_buffers=proximity_buffers,
                                        blur_buffers=blur_buffers)
            material_ids = {
                pointer: index + 1
                for index, pointer in enumerate(sorted({item[1] for queues in priority_queues.values()
                                                        for queue in queues for item in queue}))
            } if id_keys else {}
            for (threshold, selected), id_buffer in id_buffers.items():
                with id_buffer.bind():
                    gpu.state.viewport_set(0, 0, width, height)
                    gpu.state.active_framebuffer_get().clear(
                        color=(0.0, 0.0, 0.0, 0.0), depth=1.0)
                    self._draw_geometry(depsgraph, view_matrix, projection_matrix,
                                        priority_queues, textures, material_ids,
                                        occlusion_alpha_threshold=threshold,
                                        selected_material_pointers=selected,
                                        proximity_buffers=proximity_buffers,
                                        blur_buffers=blur_buffers)
            source = scene_buffer.texture_color
            computed_ao_masks = set()
            computed_bloom = {}
            for index, effect in enumerate(effects):
                selected_ids = None
                if effect.limit_to_materials:
                    selected_ids = tuple(sorted(material_ids[pointer]
                        for pointer in effect_selections[index] if pointer in material_ids))
                    if effect.invert_materials:
                        selected_ids = (-1,) + selected_ids
                id_key = (effect.occlusion_alpha_threshold,
                          geometry_selections[index])
                id_buffer = id_buffers.get(id_key) if selected_ids else None
                strength_buffer = (id_buffers.get((effect.occlusion_alpha_threshold, ()))
                                   if effect.effect_type == 'TRANSMISSION' else None)
                geometry_key = (id_key if effect.effect_type == 'OUTLINE' else
                                (effect.occlusion_alpha_threshold, ()))
                geometry_buffer = (geometry_buffers.get(geometry_key)
                                   if effect.effect_type in {'OUTLINE', 'AO', 'TRANSMISSION'} else None)
                ao_buffer = None
                if effect.effect_type in {'AO', 'TRANSMISSION'}:
                    mask_key = (self._ao_mask_key(effect)
                                if effect.effect_type == 'AO' else None)
                    ao_buffer = (shared_ao_buffers[mask_key]
                                 if mask_key in shared_ao_buffers
                                 else ao_buffers[effect.ao_resolution])
                    if mask_key not in computed_ao_masks:
                        with ao_buffer.bind():
                            gpu.state.viewport_set(0, 0, ao_buffer.width, ao_buffer.height)
                            gpu.state.active_framebuffer_get().clear(
                                color=(0.0, 0.0, 0.0, 0.0))
                            self._draw_contact_mask(
                                source, geometry_buffer.texture_color, effect,
                                view_matrix, projection_matrix,
                                ao_buffer.width, ao_buffer.height,
                                strength_buffer.texture_color if strength_buffer else None)
                        if mask_key is not None:
                            computed_ao_masks.add(mask_key)
                bloom_result = None
                if effect.effect_type == 'BLOOM':
                    bloom_key = self._bloom_key(effect)
                    bloom_result = computed_bloom.get(bloom_key)
                    if bloom_result is None:
                        bloom_result = self._prepare_bloom_mips(
                            bloom_buffers[effect.bloom_resolution].texture_color,
                            shared_bloom_mips.get(bloom_key)
                            or bloom_mips[effect.bloom_resolution],
                            shared_bloom_up_mips.get(bloom_key)
                            or bloom_up_mips[effect.bloom_resolution],
                            effect.bloom_threshold, effect.bloom_radius, width)
                        if bloom_key in shared_bloom_mips:
                            computed_bloom[bloom_key] = bloom_result
                if index == len(effects) - 1:
                    binding = target_framebuffer.bind()
                    with binding:
                        gpu.state.viewport_set(*target_viewport)
                        self._draw_post_effect(source, geometry_buffer.texture_color if geometry_buffer else None,
                                               effect, target_viewport[:2],
                                               id_buffer.texture_color if id_buffer else None,
                                               selected_ids,
                                               ao_buffer.texture_color if ao_buffer else None,
                                               bloom_result
                                               if effect.effect_type == 'BLOOM' else None)
                else:
                    target = ping_buffers[index % len(ping_buffers)]
                    with target.bind():
                        gpu.state.viewport_set(0, 0, width, height)
                        self._draw_post_effect(
                            source, geometry_buffer.texture_color if geometry_buffer else None, effect,
                            material_id_texture=id_buffer.texture_color if id_buffer else None,
                            selected_ids=selected_ids,
                            ao_texture=ao_buffer.texture_color if ao_buffer else None,
                            emission_texture=(bloom_result
                                              if effect.effect_type == 'BLOOM' else None))
                    source = target.texture_color
        finally:
            for offscreen, _ in proximity_buffers.values():
                offscreen.free()
            for offscreen in blur_buffers.values():
                offscreen.free()
            if not viewport:
                for offscreen in buffers:
                    offscreen.free()

    @staticmethod
    def _active_effects(scene):
        # Custom World collections can stay stale on scene_eval after an item
        # is removed. Read the editable World so the viewport drops it now.
        world = scene.original.world
        return [effect for effect in world.toon_effects if effect.enabled] if world else []

    def view_draw(self, context, depsgraph):
        import gpu

        region = context.region
        if region.width < 1 or region.height < 1:
            return
        view = context.region_data
        scene = depsgraph.scene_eval
        effects = (self._active_effects(scene)
                   if scene.toon_viewport_effects else [])
        camera = depsgraph.scene_eval.camera
        if (view.view_perspective == 'CAMERA' and camera is not None
                and camera.data.type == 'PANO'
                and camera.data.panorama_type in {'EQUIRECTANGULAR', 'FISHEYE_EQUISOLID'}):
            if self._viewport_resolution_buffer:
                gpu_compat.forget_shaders(self._shaders.values())
                self._shaders = {}
                self._viewport_resolution_buffer[1].free()
                self._viewport_resolution_buffer = None
            frame_rect = _panorama_camera_frame(context, camera)
            show_custom_overlays = _panorama_custom_overlays_enabled(
                context.space_data)
            _sync_extras_overlay(
                context.space_data, show_custom_overlays)
            draw_bones = _sync_bone_overlay(
                context.space_data,
                context.mode in {'POSE', 'OBJECT'}
                and show_custom_overlays)
            draw_objects = _sync_outline_overlay(
                context.space_data,
                context.mode == 'OBJECT' and show_custom_overlays)
            _sync_legacy_view(context.space_data, bpy.app.version < (5, 0, 0))
            self._draw_panorama_viewport(depsgraph, camera, region.width,
                                         region.height, effects, frame_rect,
                                         context if draw_bones or draw_objects else None)
            return
        _sync_bone_overlay(context.space_data, False)
        _sync_outline_overlay(context.space_data, False)
        _sync_extras_overlay(context.space_data, False)
        _sync_legacy_view(context.space_data, False)
        if self._viewport_panorama_buffers:
            gpu_compat.forget_shaders(self._shaders.values())
            self._shaders = {}
            for offscreen in self._viewport_panorama_buffers[1]:
                offscreen.free()
            self._viewport_panorama_buffers = None
        if self._viewport_panorama_bloom_buffers:
            for offscreen in self._viewport_panorama_bloom_buffers[1]:
                offscreen.free()
            self._viewport_panorama_bloom_buffers = None
        scale = scene.toon_viewport_resolution / 100.0
        width = max(1, round(region.width * scale))
        height = max(1, round(region.height * scale))
        reduced = (width, height) != (region.width, region.height)
        if self._viewport_resolution_buffer and (
                not reduced or self._viewport_resolution_buffer[0] != (width, height)):
            gpu_compat.forget_shaders(self._shaders.values())
            self._shaders = {}
            self._viewport_resolution_buffer[1].free()
            self._viewport_resolution_buffer = None
        if reduced:
            target_framebuffer = gpu.state.active_framebuffer_get()
            target_viewport = gpu.state.viewport_get()
            if target_viewport[2] == 0 or target_viewport[3] == 0:
                target_viewport = (0, 0, region.width, region.height)
            if self._viewport_resolution_buffer is None:
                offscreen = gpu.types.GPUOffScreen(width, height, format='RGBA16F')
                self._viewport_resolution_buffer = ((width, height), offscreen)
            offscreen = self._viewport_resolution_buffer[1]
            with offscreen.bind():
                gpu.state.viewport_set(0, 0, width, height)
                self._draw_standard_viewport(
                    depsgraph, view, effects, width, height)
            with target_framebuffer.bind():
                gpu.state.viewport_set(*target_viewport)
                self._draw_viewport_blit(offscreen.texture_color, target_viewport)
        else:
            self._draw_standard_viewport(
                depsgraph, view, effects, region.width, region.height)

    def _draw_standard_viewport(self, depsgraph, view, effects, width, height):
        if effects:
            self._draw_with_effects(depsgraph, view.view_matrix, view.window_matrix,
                                    self._viewport_batches, self._viewport_textures,
                                    width, height, effects, viewport=True)
        else:
            self._draw_scene_shadows(
                depsgraph, view.view_matrix, view.window_matrix,
                self._viewport_batches, self._viewport_textures,
                width, height, viewport=True)

    def _draw_panorama_viewport(self, depsgraph, camera, width, height, effects,
                                frame_rect=None, context=None):
        import gpu

        target_framebuffer = gpu.state.active_framebuffer_get()
        target_viewport = gpu.state.viewport_get()
        frame_rect = frame_rect or (0, 0, width, height)
        frame_width, frame_height = frame_rect[2:]
        bloom_effects = [effect for effect in effects if effect.effect_type == 'BLOOM']
        face_effects = [effect for effect in effects if effect.effect_type != 'BLOOM']
        if not bloom_effects and self._viewport_panorama_bloom_buffers:
            for old in self._viewport_panorama_bloom_buffers[1]:
                old.free()
            self._viewport_panorama_bloom_buffers = None
        face_size = self._panorama_face_size(
            camera.data, frame_width, frame_height,
            camera.data.toon_panorama_viewport_quality
            * depsgraph.scene_eval.toon_viewport_resolution / 100.0)
        if (self._viewport_panorama_buffers is None
                or self._viewport_panorama_buffers[0] != (face_size, bool(bloom_effects))):
            if self._viewport_panorama_buffers:
                gpu_compat.forget_shaders(self._shaders.values())
                self._shaders = {}
                for old in self._viewport_panorama_buffers[1]:
                    old.free()
            buffers = [gpu.types.GPUOffScreen(face_size, face_size, format='RGBA16F')
                       for _ in range(len(panorama.FACE_ROTATIONS) *
                                      (2 if bloom_effects else 1))]
            self._viewport_panorama_buffers = ((face_size, bool(bloom_effects)), buffers)
        else:
            buffers = self._viewport_panorama_buffers[1]

        scene_faces = buffers[:len(panorama.FACE_ROTATIONS)]
        emission_faces = buffers[len(panorama.FACE_ROTATIONS):] if bloom_effects else []

        projection = panorama.face_projection(camera.data.clip_start,
                                              camera.data.clip_end)
        visible_faces = set(panorama.visible_face_indices(camera.data))
        world = depsgraph.scene_eval.world
        background = (*world.toon_background_color, 1.0) if world else (0.05, 0.05, 0.05, 1.0)
        for index, (rotation, offscreen) in enumerate(zip(panorama.FACE_ROTATIONS, scene_faces)):
            if index not in visible_faces:
                with offscreen.bind():
                    gpu.state.active_framebuffer_get().clear(color=background)
                if bloom_effects:
                    with emission_faces[index].bind():
                        gpu.state.active_framebuffer_get().clear(color=(0.0, 0.0, 0.0, 0.0))
                continue
            view = (camera.matrix_world @ rotation).inverted()
            with offscreen.bind():
                gpu.state.viewport_set(0, 0, face_size, face_size)
                self._draw_face_with_emission(
                    depsgraph, view, projection, self._viewport_batches,
                    self._viewport_textures, face_size, face_size, face_effects,
                    offscreen, emission_faces[index] if bloom_effects else None,
                    viewport=True)
        panorama_texture = None
        if bloom_effects:
            bloom_buffers = self._panorama_bloom_buffers(
                frame_width, frame_height, bloom_effects, viewport=True)
            panorama_texture = self._draw_panorama_bloom_composite(
                camera.data, scene_faces, emission_faces, frame_width,
                frame_height, bloom_effects, background,
                (depsgraph.scene_eval.render.pixel_aspect_x,
                 depsgraph.scene_eval.render.pixel_aspect_y), bloom_buffers)
        with target_framebuffer.bind():
            if frame_rect != (0, 0, width, height):
                target_framebuffer.clear(color=background)
            image_origin = (target_viewport[0] + frame_rect[0],
                            target_viewport[1] + frame_rect[1])
            gpu.state.viewport_set(*image_origin, frame_width, frame_height)
            if panorama_texture is not None:
                self._draw_viewport_blit(panorama_texture,
                                          (*image_origin, frame_width, frame_height))
            else:
                self._draw_panorama_composite(
                    camera.data, scene_faces, frame_width, frame_height,
                    image_origin, background,
                    (depsgraph.scene_eval.render.pixel_aspect_x,
                     depsgraph.scene_eval.render.pixel_aspect_y))
            gpu.state.viewport_set(*target_viewport)
            if context is not None:
                if (context.mode == 'OBJECT'
                        and context.space_data.as_pointer() in _PANORAMA_OUTLINE_STATES):
                    self._draw_panorama_object_selection(context, camera,
                                                         frame_rect)
                if (context.mode in {'POSE', 'OBJECT'}
                        and context.space_data.as_pointer() in _PANORAMA_BONE_STATES):
                    self._draw_panorama_bones(context, camera, frame_rect)

    @staticmethod
    def _panorama_face_size(camera_data, width, height, quality):
        if camera_data.panorama_type == 'FISHEYE_EQUISOLID':
            base = max(width, height) / 2
        else:
            longitude_span = abs(camera_data.longitude_max - camera_data.longitude_min)
            latitude_span = abs(camera_data.latitude_max - camera_data.latitude_min)
            base = max(width * (math.pi / 2) / max(longitude_span, 0.001),
                       height * (math.pi / 2) / max(latitude_span, 0.001))
        return max(16, math.ceil(base * quality))

    def render(self, depsgraph):
        import gpu

        scene = depsgraph.scene_eval
        transparent_background = (scene.toon_transparent
                                  and scene.render.image_settings.file_format == 'PNG')
        if transparent_background:
            scene.original.render.image_settings.color_mode = 'RGBA'
        camera = scene.camera
        if camera is None:
            self.report({'ERROR'}, "Toon Render needs an active camera")
            return
        scale = scene.render.resolution_percentage / 100.0
        width = max(1, round(scene.render.resolution_x * scale))
        height = max(1, round(scene.render.resolution_y * scale))
        # The render method has its own GPU context. Its batches must not share
        # the viewport cache, whose resources belong to another context.
        gpu_compat.forget_shaders(self._shaders.values())
        self._shaders = {}
        try:
            if camera.data.type == 'PANO':
                if camera.data.panorama_type not in {'EQUIRECTANGULAR', 'FISHEYE_EQUISOLID'}:
                    self.report({'ERROR'}, 'Toon Render supports Equirectangular and Fisheye Equisolid panorama')
                    return
                face_size = self._panorama_face_size(
                    camera.data, width, height, camera.data.toon_panorama_quality)
                world = scene.world
                background = ((0.0, 0.0, 0.0, 0.0) if transparent_background
                              else (*world.toon_background_color, 1.0) if world
                              else (0.05, 0.05, 0.05, 1.0))
                panorama_bloom = (scene.toon_render_effects and any(
                    effect.effect_type == 'BLOOM' for effect in self._active_effects(scene)))
                # Bloom needs a GPU pass after stitching, even when the CPU
                # panorama fallback was selected for ordinary renders.
                if scene.toon_panorama_compositing == 'GPU' or panorama_bloom:
                    pixels = self._render_panorama_pixels(
                        depsgraph, camera, width, height, face_size,
                        transparent_background, scene, background)
                else:
                    projection = panorama.face_projection(camera.data.clip_start,
                                                          camera.data.clip_end)
                    faces = []
                    visible_faces = set(panorama.visible_face_indices(camera.data))
                    for index, rotation in enumerate(panorama.FACE_ROTATIONS):
                        if index not in visible_faces:
                            faces.append(None)
                            continue
                        view = (camera.matrix_world @ rotation).inverted()
                        faces.append(self._render_camera_pixels(
                            depsgraph, view, projection, face_size, face_size,
                            transparent_background, scene))
                        # Vulkan retains sampler references to temporary post
                        # textures; release shaders before the next face.
                        gpu_compat.forget_shaders(self._shaders.values())
                        self._shaders = {}
                    pixels = panorama.stitch_panorama(
                        faces, width, height, camera.data, background,
                        scene.render.pixel_aspect_x, scene.render.pixel_aspect_y)
            else:
                projection = camera.calc_matrix_camera(depsgraph, x=width, y=height)
                view = camera.matrix_world.inverted()
                pixels = self._render_camera_pixels(depsgraph, view, projection,
                                                    width, height, transparent_background, scene)

            result = self.begin_result(0, 0, width, height)
            result.layers[0].passes['Combined'].rect.foreach_set(pixels.ravel())
            self.end_result(result)
        finally:
            # The final-render GPU context can differ from the viewport context.
            gpu_compat.forget_shaders(self._shaders.values())
            self._shaders = {}

    def _render_camera_pixels(self, depsgraph, view, projection, width, height,
                              transparent_background, scene):
        import gpu

        offscreen = gpu.types.GPUOffScreen(width, height, format='RGBA16F')
        try:
            with offscreen.bind():
                gpu.state.viewport_set(0, 0, width, height)
                framebuffer = gpu.state.active_framebuffer_get()
                self._draw_camera_to_offscreen(
                    depsgraph, view, projection, width, height,
                    transparent_background, scene, offscreen)
                with framebuffer.bind():
                    buffer = framebuffer.read_color(0, 0, width, height, 4, 0, 'FLOAT')
                    return self._readback_pixels(buffer, width, height)
        finally:
            offscreen.free()

    def _draw_camera_to_offscreen(self, depsgraph, view, projection, width, height,
                                  transparent_background, scene, offscreen,
                                  effects_override=None, emission_output=None):
        effects = (effects_override if effects_override is not None else
                   self._active_effects(scene) if scene.toon_render_effects else [])
        self._draw_face_with_emission(
            depsgraph, view, projection, {}, {}, width, height, effects,
            offscreen, emission_output, transparent_background=transparent_background)

    def _draw_face_with_emission(self, depsgraph, view, projection, cache,
                                 textures, width, height, effects, offscreen,
                                 emission_output=None, viewport=False,
                                 transparent_background=False):
        if effects:
            self._draw_with_effects(depsgraph, view, projection, cache, textures,
                                    width, height, effects,
                                    output_offscreen=offscreen,
                                    transparent_background=transparent_background,
                                    emission_output=emission_output, viewport=viewport)
        else:
            result = self._draw_scene_shadows(
                depsgraph, view, projection, cache, textures, width, height,
                viewport=viewport, output_offscreen=offscreen,
                transparent_background=transparent_background,
                retain_proximity=emission_output is not None)
            if emission_output is not None:
                queues, proximity_buffers, blur_buffers = result
                try:
                    self._draw_emission_to_offscreen(
                        emission_output, depsgraph, view, projection, queues,
                        textures, proximity_buffers, blur_buffers)
                finally:
                    for offscreen_buffer, _ in proximity_buffers.values():
                        offscreen_buffer.free()
                    for offscreen_buffer in blur_buffers.values():
                        offscreen_buffer.free()

    @staticmethod
    def _readback_pixels(buffer, width, height):
        pixels = np.array(buffer, dtype=np.float32, copy=True)
        # Blender 4.x exposes GPUBuffer with Fortran strides, while to_list()
        # and Blender 5.x use interleaved RGBA pixels.
        if pixels.flags.f_contiguous and not pixels.flags.c_contiguous:
            pixels = pixels.ravel(order='F').reshape(height, width, 4)
        return pixels.reshape(height, width, 4)

    def _render_panorama_pixels(self, depsgraph, camera, width, height, face_size,
                                transparent_background, scene, background):
        import gpu

        projection = panorama.face_projection(camera.data.clip_start,
                                              camera.data.clip_end)
        faces = []
        emission_faces = []
        effects = self._active_effects(scene) if scene.toon_render_effects else []
        bloom_effects = [effect for effect in effects if effect.effect_type == 'BLOOM']
        face_effects = [effect for effect in effects if effect.effect_type != 'BLOOM']
        output = None
        bloom_buffers = None
        try:
            visible_faces = set(panorama.visible_face_indices(camera.data))
            for index, rotation in enumerate(panorama.FACE_ROTATIONS):
                face = gpu.types.GPUOffScreen(face_size, face_size, format='RGBA16F')
                faces.append(face)
                if bloom_effects:
                    emission_faces.append(gpu.types.GPUOffScreen(
                        face_size, face_size, format='RGBA16F'))
                if index not in visible_faces:
                    with face.bind():
                        gpu.state.active_framebuffer_get().clear(color=background)
                    if bloom_effects:
                        with emission_faces[-1].bind():
                            gpu.state.active_framebuffer_get().clear(color=(0.0, 0.0, 0.0, 0.0))
                    continue
                view = (camera.matrix_world @ rotation).inverted()
                with face.bind():
                    gpu.state.viewport_set(0, 0, face_size, face_size)
                    self._draw_camera_to_offscreen(
                        depsgraph, view, projection, face_size, face_size,
                        transparent_background, scene, face,
                        effects_override=face_effects,
                        emission_output=emission_faces[-1] if bloom_effects else None)
                gpu_compat.forget_shaders(self._shaders.values())
                self._shaders = {}
            output = gpu.types.GPUOffScreen(width, height, format='RGBA16F')
            panorama_texture = None
            if bloom_effects:
                bloom_buffers = self._panorama_bloom_buffers(
                    width, height, bloom_effects, viewport=False)
                panorama_texture = self._draw_panorama_bloom_composite(
                    camera.data, faces, emission_faces, width, height,
                    bloom_effects, background,
                    (scene.render.pixel_aspect_x,
                     scene.render.pixel_aspect_y), bloom_buffers)
            with output.bind():
                gpu.state.viewport_set(0, 0, width, height)
                if panorama_texture is not None:
                    self._draw_viewport_blit(panorama_texture,
                                              (0, 0, width, height))
                else:
                    self._draw_panorama_composite(
                        camera.data, faces, width, height, (0, 0), background,
                        (scene.render.pixel_aspect_x, scene.render.pixel_aspect_y))
                buffer = gpu.state.active_framebuffer_get().read_color(
                    0, 0, width, height, 4, 0, 'FLOAT')
                return self._readback_pixels(buffer, width, height)
        finally:
            gpu_compat.forget_shaders(self._shaders.values())
            self._shaders = {}
            if output is not None:
                output.free()
            if bloom_buffers is not None:
                for buffer in bloom_buffers:
                    buffer.free()
            for face in faces:
                face.free()
            for face in emission_faces:
                face.free()


class TOON_PT_render_settings(bpy.types.Panel):
    bl_label = 'Toon Render'
    bl_idname = 'TOON_PT_render_settings'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'render'

    @classmethod
    def poll(cls, context):
        return context.scene is not None and context.scene.render.engine == 'TOON_RENDER'

    def draw(self, context):
        row = self.layout.row()
        row.enabled = context.scene.render.image_settings.file_format == 'PNG'
        row.prop(context.scene, 'toon_transparent', text='Transparent')


class TOON_PT_render_viewport(bpy.types.Panel):
    bl_label = 'Viewport Preview'
    bl_idname = 'TOON_PT_render_viewport'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'render'
    bl_parent_id = 'TOON_PT_render_settings'

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        layout.use_property_split = True
        layout.prop(scene, 'toon_viewport_resolution', text='Resolution')
        layout.prop(scene, 'toon_viewport_shadows', text='Shadows')
        layout.prop(scene, 'toon_viewport_effects', text='Post Processing')
        camera = scene.camera
        if camera and camera.data.type == 'PANO':
            layout.prop(camera.data, 'toon_panorama_viewport_quality',
                        text='Panorama Face Quality')


class TOON_PT_render_final(bpy.types.Panel):
    bl_label = 'Final Render'
    bl_idname = 'TOON_PT_render_final'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'render'
    bl_parent_id = 'TOON_PT_render_settings'

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        layout.use_property_split = True
        layout.prop(scene.render, 'resolution_percentage', text='Resolution')
        layout.prop(scene, 'toon_render_shadows', text='Shadows')
        row = layout.row()
        row.enabled = scene.toon_render_shadows
        row.prop(scene, 'toon_render_shadow_resolution',
                 text='Shadow Map Resolution')
        layout.prop(scene, 'toon_render_effects', text='Post Processing')
        camera = scene.camera
        if camera and camera.data.type == 'PANO':
            layout.prop(camera.data, 'toon_panorama_quality',
                        text='Panorama Face Quality')
            layout.prop(scene, 'toon_panorama_compositing',
                        text='Panorama Compositing')


class TOON_PT_camera_settings(bpy.types.Panel):
    bl_label = 'Lens'
    bl_idname = 'TOON_PT_camera_settings'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'data'

    @classmethod
    def poll(cls, context):
        return context.engine == 'TOON_RENDER' and context.camera is not None

    def draw(self, context):
        camera = context.camera
        layout = self.layout
        layout.use_property_split = True
        layout.prop(camera, 'type')
        if camera.type == 'PERSP':
            layout.prop(camera, 'lens' if camera.lens_unit == 'MILLIMETERS' else 'angle')
            layout.prop(camera, 'lens_unit')
        elif camera.type == 'ORTHO':
            layout.prop(camera, 'ortho_scale')
        elif camera.type == 'PANO':
            layout.prop(camera, 'panorama_type', text='Projection')
            if camera.panorama_type == 'EQUIRECTANGULAR':
                layout.prop(camera, 'longitude_min')
                layout.prop(camera, 'longitude_max')
                layout.prop(camera, 'latitude_min')
                layout.prop(camera, 'latitude_max')
            elif camera.panorama_type == 'FISHEYE_EQUISOLID':
                layout.prop(camera, 'fisheye_lens', text='Fisheye Lens')
                layout.prop(camera, 'fisheye_fov')
                layout.prop(camera, 'sensor_fit')
                layout.prop(camera, 'sensor_width')
                layout.prop(camera, 'sensor_height')
            else:
                layout.label(text='Projection unavailable in Toon Render', icon='INFO')
            if camera.panorama_type in {'EQUIRECTANGULAR', 'FISHEYE_EQUISOLID'}:
                layout.prop(camera, 'toon_panorama_quality', text='Render Face Resolution')
                layout.prop(camera, 'toon_panorama_viewport_quality', text='Viewport Face Resolution')
        layout.separator()
        if camera.type != 'PANO':
            layout.prop(camera, 'shift_x')
            layout.prop(camera, 'shift_y')
        layout.prop(camera, 'clip_start')
        layout.prop(camera, 'clip_end')


def _selection_mouse_button(context):
    keyconfig = context.window_manager.keyconfigs.active
    chosen = context.preferences.keymap.active_keyconfig.lower()
    if '27x' in chosen or '2.7' in chosen:
        return 'RIGHTMOUSE'
    preferences = keyconfig.preferences if keyconfig else None
    select_mouse = getattr(preferences, 'select_mouse', None)
    if select_mouse in {'LEFT', 'RIGHT'}:
        return select_mouse + 'MOUSE'
    names = (getattr(keyconfig, 'name', '') + ' '
             + context.preferences.keymap.active_keyconfig).lower()
    return 'RIGHTMOUSE' if '27x' in names or '2.7' in names else 'LEFTMOUSE'


class TOON_OT_select_panorama_object(bpy.types.Operator):
    bl_idname = 'view3d.toon_select_panorama_object'
    bl_label = 'Select Panoramic Object'
    bl_description = 'Select an object through its panoramic camera position'
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        camera = context.scene.camera if context.scene else None
        return (context.area is not None and context.area.type == 'VIEW_3D'
                and context.mode == 'OBJECT'
                and context.space_data.shading.type in {'RENDERED', 'MATERIAL'}
                and context.scene.render.engine == 'TOON_RENDER'
                and context.region_data is not None
                and context.region_data.view_perspective == 'CAMERA'
                and camera is not None and camera.data.type == 'PANO'
                and camera.data.panorama_type in {
                    'EQUIRECTANGULAR', 'FISHEYE_EQUISOLID'})

    @staticmethod
    def select_at(context, x, y, extend=False):
        camera = context.scene.camera
        frame_rect = _panorama_camera_frame(context, camera)
        if frame_rect is None:
            return False
        if _on_camera_frame_border(x, y, frame_rect):
            obj = camera
        else:
            direction_local = panorama.unproject_direction(
                x, y, camera.data, frame_rect,
                context.scene.render.pixel_aspect_x,
                context.scene.render.pixel_aspect_y)
            if direction_local is None:
                return False
            obj = None
        if (obj is None and _panorama_custom_overlays_enabled(context.space_data)
                and (context.space_data.overlay.show_bones
                     or context.space_data.as_pointer() in _PANORAMA_BONE_STATES)):
            nearest_distance = 12.0 ** 2
            for armature, _bone, segments in _project_pose_bones(
                    context, camera, frame_rect):
                if armature.hide_select:
                    continue
                for first, second in segments:
                    dx, dy = second[0] - first[0], second[1] - first[1]
                    length_squared = dx * dx + dy * dy
                    t = (max(0.0, min(1.0,
                             ((x - first[0]) * dx + (y - first[1]) * dy)
                             / length_squared)) if length_squared > 1e-8 else 0.0)
                    distance_squared = ((x - first[0] - t * dx) ** 2
                                        + (y - first[1] - t * dy) ** 2)
                    if distance_squared < nearest_distance:
                        nearest_distance = distance_squared
                        obj = armature
        if obj is None:
            direction = (camera.matrix_world.to_3x3()
                         @ Vector(direction_local)).normalized()
            start = camera.data.clip_start
            hit, _position, _normal, _face, obj, _matrix = context.scene.ray_cast(
                context.view_layer.depsgraph,
                camera.matrix_world.translation + direction * start,
                direction, distance=max(camera.data.clip_end - start, 0.001))
            obj = obj.original if hit and obj is not None else None
        if obj is not None and (obj.name not in context.view_layer.objects
                                or not obj.visible_get() or obj.hide_select):
            obj = None
        if not extend:
            for selected in context.selected_objects:
                selected.select_set(False)
        if obj is not None:
            obj.select_set(not obj.select_get() if extend else True)
            context.view_layer.objects.active = obj
        context.area.tag_redraw()
        return True

    def invoke(self, context, event):
        if event.type != _selection_mouse_button(context):
            return {'PASS_THROUGH'}
        handled = self.select_at(context, event.mouse_region_x,
                                 event.mouse_region_y, event.shift)
        return {'FINISHED'} if handled else {'PASS_THROUGH'}


class TOON_OT_select_panorama_bone(bpy.types.Operator):
    bl_idname = 'view3d.toon_select_panorama_bone'
    bl_label = 'Select Panoramic Bone'
    bl_description = 'Select a pose bone at its projected position in the panoramic camera'
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        camera = context.scene.camera if context.scene else None
        return (context.area is not None and context.area.type == 'VIEW_3D'
                and context.mode == 'POSE'
                and context.space_data.shading.type in {'RENDERED', 'MATERIAL'}
                and context.scene.render.engine == 'TOON_RENDER'
                and context.region_data is not None
                and context.region_data.view_perspective == 'CAMERA'
                and camera is not None and camera.data.type == 'PANO'
                and camera.data.panorama_type in {
                    'EQUIRECTANGULAR', 'FISHEYE_EQUISOLID'})

    @staticmethod
    def select_at(context, x, y, extend=False):
        camera = context.scene.camera
        frame_rect = _panorama_camera_frame(context, camera)
        if frame_rect is None:
            return False
        left, bottom, width, height = frame_rect
        if not (left <= x <= left + width and bottom <= y <= bottom + height):
            return False

        nearest = None
        best_distance_squared = 12.0 ** 2
        for armature, pose_bone, segments in _project_pose_bones(
                context, camera, frame_rect):
            for first, second in segments:
                dx = second[0] - first[0]
                dy = second[1] - first[1]
                denominator = dx * dx + dy * dy
                t = (max(0.0, min(1.0,
                         ((x - first[0]) * dx + (y - first[1]) * dy) / denominator))
                     if denominator > 1e-8 else 0.0)
                distance_squared = ((x - first[0] - t * dx) ** 2
                                    + (y - first[1] - t * dy) ** 2)
                if distance_squared < best_distance_squared:
                    best_distance_squared = distance_squared
                    nearest = (armature, pose_bone)

        if not extend:
            for obj in context.objects_in_mode:
                if obj.type == 'ARMATURE':
                    for pose_bone in obj.pose.bones:
                        _set_pose_bone_selected(pose_bone, False)
        if nearest is not None:
            armature, pose_bone = nearest
            _set_pose_bone_selected(
                pose_bone, not _pose_bone_selected(pose_bone) if extend else True)
            armature.data.bones.active = pose_bone.bone
            context.view_layer.objects.active = armature
        context.area.tag_redraw()
        return True

    def invoke(self, context, event):
        if event.type != _selection_mouse_button(context):
            return {'PASS_THROUGH'}
        handled = self.select_at(context, event.mouse_region_x,
                                 event.mouse_region_y, event.shift)
        return {'FINISHED'} if handled else {'PASS_THROUGH'}


class TOON_PT_material_slots(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'TOON_PT_material_slots'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'material'
    bl_options = {'HIDE_HEADER'}
    bl_order = 0

    @classmethod
    def poll(cls, context):
        obj = context.object
        return (context.scene is not None
                and context.scene.render.engine == 'TOON_RENDER'
                and ((obj is not None and hasattr(obj.data, 'materials'))
                     or context.material is not None))

    def draw(self, context):
        layout = self.layout
        obj = context.object
        material = context.material
        slot = context.material_slot

        if obj and hasattr(obj.data, 'materials'):
            sortable = len(obj.material_slots) > 1
            row = layout.row()
            row.template_list('MATERIAL_UL_matslots', '', obj, 'material_slots',
                              obj, 'active_material_index', rows=5 if sortable else 3)
            column = row.column(align=True)
            column.operator('object.material_slot_add', icon='ADD', text='')
            column.operator('object.material_slot_remove', icon='REMOVE', text='')
            column.separator()
            column.menu(toon_nodes.TOON_MT_material_context_menu.bl_idname,
                        icon='DOWNARROW_HLT', text='')
            if sortable:
                column.separator()
                column.operator('object.material_slot_move', icon='TRIA_UP', text='').direction = 'UP'
                column.operator('object.material_slot_move', icon='TRIA_DOWN', text='').direction = 'DOWN'

            row = layout.row()
            row.template_ID(obj, 'active_material', new=toon_nodes.TOON_OT_new_material.bl_idname)
            if slot:
                row.prop(slot, 'link', icon_only=True)
            if obj.mode == 'EDIT':
                row = layout.row(align=True)
                row.operator('object.material_slot_assign', text='Assign')
                row.operator('object.material_slot_select', text='Select')
                row.operator('object.material_slot_deselect', text='Deselect')
        elif material:
            layout.template_ID(context.space_data, 'pin_id')


class TOON_PT_material_settings(bpy.types.Panel):
    bl_label = 'Toon Render'
    bl_idname = 'TOON_PT_material_settings'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'material'
    bl_order = 1

    @classmethod
    def poll(cls, context):
        return (context.scene is not None
                and context.scene.render.engine == 'TOON_RENDER'
                and context.material is not None)

    def draw(self, context):
        material = context.material
        self.layout.prop(material, 'toon_double_sided', text='Double Sided')
        self.layout.prop(material, 'toon_unlit', text='Unlit')
        self.layout.prop(material, 'toon_cast_shadow', text='Cast Shadow')
        self.layout.prop(material, 'toon_receive_shadow', text='Receive Shadow')
        self.layout.prop(material, 'toon_transmission_strength',
                         text='Color Transmission Strength')


def register():
    toon_nodes.register()
    material_convert.register()
    post_effects.register()
    shadows.register()
    bpy.types.Scene.toon_transparent = bpy.props.BoolProperty(
        name='Transparent', default=False,
        description='Keep background and material transparency in PNG renders',
        update=_update_transparent_png)
    bpy.types.Scene.toon_viewport_resolution = bpy.props.IntProperty(
        name='Viewport Resolution', default=100, min=25, max=100,
        subtype='PERCENTAGE',
        description='Internal resolution of the rendered viewport preview; panoramic cameras scale their cube faces',
        update=toon_nodes._tag_viewports)
    bpy.types.Scene.toon_viewport_shadows = bpy.props.BoolProperty(
        name='Viewport Shadows', default=True,
        description='Render light shadows in the viewport preview',
        update=toon_nodes._tag_viewports)
    bpy.types.Scene.toon_viewport_effects = bpy.props.BoolProperty(
        name='Viewport Post Processing', default=True,
        description='Render World post processing effects in the viewport preview',
        update=toon_nodes._tag_viewports)
    bpy.types.Scene.toon_render_shadows = bpy.props.BoolProperty(
        name='Final Render Shadows', default=True,
        description='Render light shadows in F12 renders')
    bpy.types.Scene.toon_render_shadow_resolution = bpy.props.IntProperty(
        name='Final Shadow Map Resolution', default=100, min=25, max=100,
        subtype='PERCENTAGE',
        description='Scale all light shadow maps for F12 renders; lower values render faster with softer detail')
    bpy.types.Scene.toon_render_effects = bpy.props.BoolProperty(
        name='Final Render Post Processing', default=True,
        description='Apply World post processing effects in F12 renders')
    bpy.types.Scene.toon_panorama_compositing = bpy.props.EnumProperty(
        name='Panorama Compositing',
        items=(('GPU', 'GPU', 'Compose panoramic faces on the GPU with one pixel readback'),
               ('CPU', 'CPU', 'Compose panoramic faces on the CPU')),
        default='GPU')
    bpy.types.Camera.toon_panorama_quality = bpy.props.FloatProperty(
        name='Face Resolution', default=1.25, min=0.5, max=3.0,
        description='Cube face resolution in final panorama renders; higher values improve sharpness and cost more memory')
    bpy.types.Camera.toon_panorama_viewport_quality = bpy.props.FloatProperty(
        name='Viewport Face Resolution', default=0.6, min=0.25, max=2.0,
        description='Cube face resolution in camera viewport; higher values improve sharpness and reduce frame rate',
        update=toon_nodes._tag_viewports)
    bpy.types.World.toon_background_color = bpy.props.FloatVectorProperty(
        name='Background Color', subtype='COLOR', size=3,
        min=0.0, max=1.0, default=(0.05, 0.05, 0.05),
        description='Background color in Toon renders and the 3D viewport',
        update=toon_nodes._tag_viewports)
    bpy.types.World.toon_ambient_mode = bpy.props.EnumProperty(
        name='Ambient Mode',
        items=(('SOLID', 'Solid Color', 'Use one color for ambient lighting'),
               ('HEMISPHERE', 'Hemisphere Light',
                'Blend sky and ground colors according to surface normals')),
        default='SOLID', update=toon_nodes._tag_viewports)
    bpy.types.World.toon_ambient_color = bpy.props.FloatVectorProperty(
        name='Color', subtype='COLOR', size=3, min=0.0, max=1.0,
        default=(1.0, 1.0, 1.0), update=toon_nodes._tag_viewports)
    bpy.types.World.toon_ambient_sky_color = bpy.props.FloatVectorProperty(
        name='Sky Color', subtype='COLOR', size=3, min=0.0, max=1.0,
        default=(0.749, 0.863, 1.0), update=toon_nodes._tag_viewports)
    bpy.types.World.toon_ambient_ground_color = bpy.props.FloatVectorProperty(
        name='Ground Color', subtype='COLOR', size=3, min=0.0, max=1.0,
        default=(0.357, 0.314, 0.376), update=toon_nodes._tag_viewports)
    bpy.types.World.toon_ambient_tilt_x = bpy.props.FloatProperty(
        name='Tilt X', subtype='ANGLE', min=-math.pi / 2, max=math.pi / 2,
        default=0.0, update=toon_nodes._tag_viewports)
    bpy.types.World.toon_ambient_tilt_z = bpy.props.FloatProperty(
        name='Tilt Z', subtype='ANGLE', min=-math.pi / 2, max=math.pi / 2,
        default=0.0, update=toon_nodes._tag_viewports)
    bpy.types.World.toon_ambient_intensity = bpy.props.FloatProperty(
        name='Ambient Intensity', min=0.0, max=10.0, soft_max=2.0,
        default=0.16, update=toon_nodes._tag_viewports)
    bpy.types.Material.toon_double_sided = bpy.props.BoolProperty(
        name='Double Sided', default=False,
        description='Render both front and back faces of this material',
        update=toon_nodes._tag_viewports)
    bpy.types.Material.toon_unlit = bpy.props.BoolProperty(
        name='Unlit', default=False,
        description='Render the material color and texture without lighting',
        update=toon_nodes._tag_viewports)
    bpy.types.Material.toon_cast_shadow = bpy.props.BoolProperty(
        name='Cast Shadow', default=True,
        description='Allow this material to cast shadows from Toon lights',
        update=toon_nodes._tag_viewports)
    bpy.types.Material.toon_receive_shadow = bpy.props.BoolProperty(
        name='Receive Shadow', default=True,
        description='Allow this material to receive shadows from Toon lights',
        update=toon_nodes._tag_viewports)
    bpy.types.Material.toon_transmission_strength = bpy.props.FloatProperty(
        name='Color Transmission Strength', default=1.0, min=0.0, soft_max=4.0,
        description='Multiplier for color emitted by this material in the Color Transmission effect; zero disables transmission',
        update=toon_nodes._tag_viewports)
    bpy.utils.register_class(ToonRenderEngine)
    bpy.utils.register_class(TOON_PT_world_ambient)
    bpy.utils.register_class(TOON_PT_render_settings)
    bpy.utils.register_class(TOON_PT_render_viewport)
    bpy.utils.register_class(TOON_PT_render_final)
    bpy.utils.register_class(TOON_PT_camera_settings)
    bpy.utils.register_class(TOON_OT_toggle_panorama_overlays)
    bpy.utils.register_class(TOON_OT_select_panorama_object)
    bpy.utils.register_class(TOON_OT_select_panorama_bone)
    bpy.utils.register_class(TOON_PT_material_slots)
    bpy.utils.register_class(TOON_PT_material_settings)
    for panel in _OUTPUT_PANELS:
        panel.COMPAT_ENGINES.add(ToonRenderEngine.bl_idname)
    for panel in _DATA_PANELS:
        panel.COMPAT_ENGINES.add(ToonRenderEngine.bl_idname)
    for panel in _CAMERA_PANELS:
        panel.COMPAT_ENGINES.add(ToonRenderEngine.bl_idname)
    keyconfig = bpy.context.window_manager.keyconfigs.addon
    if keyconfig is not None:
        for keymap_name, operator in (
                ('Pose', TOON_OT_select_panorama_bone),
                ('Object Mode', TOON_OT_select_panorama_object),
                ('3D View', TOON_OT_select_panorama_object)):
            keymap = keyconfig.keymaps.new(name=keymap_name, space_type='EMPTY')
            for button in ('LEFTMOUSE', 'RIGHTMOUSE'):
                for extend in (False, True):
                    item = keymap.keymap_items.new(
                        operator.bl_idname, button, 'PRESS', shift=extend,
                        head=True)
                    _PANORAMA_BONE_KEYMAPS.append((keymap, item))
    _set_world_viewport_draw(_draw_world_viewport_display)
    _install_panorama_header_toggle()
    bpy.app.handlers.load_post.append(_toon_load_post)
    bpy.app.handlers.save_pre.append(_toon_save_pre)
    bpy.app.handlers.save_post.append(_toon_save_post)
    _subscribe_engine_changes()
    bpy.app.timers.register(_deferred_initial_sync, first_interval=0.1)


def unregister():
    _restore_panorama_header_toggle()
    for keymap, item in _PANORAMA_BONE_KEYMAPS:
        keymap.keymap_items.remove(item)
    _PANORAMA_BONE_KEYMAPS.clear()
    if bpy.app.timers.is_registered(_bone_overlay_watchdog):
        bpy.app.timers.unregister(_bone_overlay_watchdog)
    _restore_bone_overlays()
    if bpy.app.timers.is_registered(_deferred_initial_sync):
        bpy.app.timers.unregister(_deferred_initial_sync)
    bpy.msgbus.clear_by_owner(_ENGINE_CHANGE_OWNER)
    bpy.app.handlers.load_post.remove(_toon_load_post)
    bpy.app.handlers.save_pre.remove(_toon_save_pre)
    bpy.app.handlers.save_post.remove(_toon_save_post)
    _SCENE_ENGINES.clear()
    _set_world_viewport_draw(_WORLD_VIEWPORT_DRAW)
    for panel in _DATA_PANELS:
        panel.COMPAT_ENGINES.discard(ToonRenderEngine.bl_idname)
    for panel in _CAMERA_PANELS:
        panel.COMPAT_ENGINES.discard(ToonRenderEngine.bl_idname)
    for panel in _OUTPUT_PANELS:
        panel.COMPAT_ENGINES.discard(ToonRenderEngine.bl_idname)
    bpy.utils.unregister_class(TOON_PT_material_settings)
    bpy.utils.unregister_class(TOON_PT_material_slots)
    bpy.utils.unregister_class(TOON_PT_camera_settings)
    bpy.utils.unregister_class(TOON_OT_select_panorama_bone)
    bpy.utils.unregister_class(TOON_OT_select_panorama_object)
    bpy.utils.unregister_class(TOON_OT_toggle_panorama_overlays)
    bpy.utils.unregister_class(TOON_PT_render_final)
    bpy.utils.unregister_class(TOON_PT_render_viewport)
    bpy.utils.unregister_class(TOON_PT_render_settings)
    bpy.utils.unregister_class(TOON_PT_world_ambient)
    bpy.utils.unregister_class(ToonRenderEngine)
    del bpy.types.World.toon_background_color
    del bpy.types.World.toon_ambient_intensity
    del bpy.types.World.toon_ambient_tilt_z
    del bpy.types.World.toon_ambient_tilt_x
    del bpy.types.World.toon_ambient_ground_color
    del bpy.types.World.toon_ambient_sky_color
    del bpy.types.World.toon_ambient_color
    del bpy.types.World.toon_ambient_mode
    del bpy.types.Scene.toon_transparent
    del bpy.types.Scene.toon_viewport_effects
    del bpy.types.Scene.toon_viewport_shadows
    del bpy.types.Scene.toon_viewport_resolution
    del bpy.types.Scene.toon_render_effects
    del bpy.types.Scene.toon_panorama_compositing
    del bpy.types.Scene.toon_render_shadow_resolution
    del bpy.types.Scene.toon_render_shadows
    del bpy.types.Camera.toon_panorama_quality
    del bpy.types.Camera.toon_panorama_viewport_quality
    del bpy.types.Material.toon_transmission_strength
    del bpy.types.Material.toon_receive_shadow
    del bpy.types.Material.toon_cast_shadow
    del bpy.types.Material.toon_unlit
    del bpy.types.Material.toon_double_sided
    shadows.unregister()
    post_effects.unregister()
    material_convert.unregister()
    toon_nodes.unregister()


if __name__ == "__main__":
    register()
