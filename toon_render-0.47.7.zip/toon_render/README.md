# Toon Render — análise inicial

## Faces visíveis da câmera panorâmica (0.47.7)

A viewport e o F12 agora desenham somente as faces do cubo que podem aparecer
na imagem. No Equirectangular, a seleção considera os limites de longitude e
latitude; no Fisheye Equisolid, considera o campo de visão. Um panorama de 360°
continua usando as seis faces. A composição por GPU e por CPU preserva os seis
slots, mesmo quando algumas faces não precisam ser renderizadas.

## Inverter filtro de materiais do pós-processamento (0.47.6)

Os efeitos com **Limit to Materials** agora mostram **Invert** ao lado. Quando
ativado, o efeito é aplicado aos materiais fora da lista; o fundo sem material
continua fora do filtro. Com a lista vazia, Invert alcança todos os materiais.
Se Limit to Materials estiver desligado, Invert não altera o resultado. A
inversão também ajusta quais materiais são preservados no passe de geometria
para Outline e nos passes de identificação usados pelos demais efeitos.

## Sombras mais leves e Point Light corrigida (0.47.5)

O mapa de sombra agora ignora materiais com Cast Shadow desativado antes de
percorrer as projeções de cada luz e descarta objetos cujos limites ficam fora
da face da Point Light, do cone da Spot ou da cascata da Sun. Materiais opacos
e Cutout usam uma camada de sombra; a segunda camada continua ativa quando
um material Blend ou Additive pode transmitir luz. Isso reduz de 12 para 6
os passes de uma Point Light opaca e de 10 para 5 os de uma Sun com cinco
cascatas, antes de considerar o descarte de objetos. A consulta da face −Y
da Point Light foi alinhada à projeção usada para desenhá-la, corrigindo
sombras espelhadas indevidamente nessa direção.

## Reuso de passes de pós-processamento (0.47.4)

Efeitos Ambient Occlusion com os mesmos parâmetros de máscara reutilizam o
mesmo cálculo de profundidade e normais no mesmo frame, mesmo quando aparecem
separados por outros efeitos na cascata. Cor, opacidade, denoise e filtro de
materiais continuam sendo aplicados individualmente em cada efeito. Efeitos
Bloom com resolução, threshold e raio iguais reutilizam a cadeia de mipmaps;
Strength e Opacity continuam independentes. Buffers auxiliares só são criados
quando necessários. Color Transmission continua recalculado em sua posição na
cascata, pois depende das cores produzidas pelos efeitos anteriores.

## Cache da viewport por material (0.47.3)

A árvore Toon e as fontes de Blur agora são compiladas uma vez por material e
reutilizadas em desenhos seguintes da viewport. O cache inclui os atributos
UV/Vertex Color necessários e é invalidado quando os nodes ou propriedades
do material mudam. Cada objeto recebe uma cópia leve dos dados compilados para
manter sua própria Object Color e seus controladores de transformação. Edições
no shader não limpam mais todos os buffers de vértices; mudanças de geometria
continuam atualizando os objetos afetados.

## Conversão de texturas indiretas e materiais simples (0.47.2)

O conversor procura Image Textures na cadeia que alimenta Base Color, mesmo
quando passam por outros nodes. Escolhe a primeira textura compatível dessa
cadeia para a cor Toon; os nodes intermediários são omitidos e o operador
avisa que o resultado é uma aproximação. Outras Image Textures do material
são criadas como nodes soltos para ajustes manuais. Quando nenhuma textura
existe, o conversor cria o material Toon a partir dos valores fixos do
Principled, inclusive Base Color, Roughness, Metallic e Alpha. Ligações
complexas sem equivalente usam o valor padrão do respectivo campo e geram
um aviso de conversão parcial.

## Conversão com Mapping e nodes extras (0.47.1)

O conversor segue a ligação de **Base Color** até a **Image Texture**, mesmo
quando há nodes **Reroute** no caminho. Ele também reproduz a cadeia **UV Map**
(ou Texture Coordinate UV) → **Mapping** no modo Point → **Image Texture**,
incluindo UV selecionado, posição, rotação e escala do Mapping. Nodes
desconectados não impedem a conversão. Se houver uma textura simples no Base
Color e outros canais usarem nodes sem equivalente, o material é convertido
parcialmente e o operador informa os canais omitidos. Cadeias complexas no
próprio Base Color continuam sendo ignoradas para evitar uma conversão visual
incorreta.

## Conversão simples de materiais (0.47.0)

No header da 3D View, o menu **Toon Render > Convert Materials to Toon Render**
converte materiais usados pelos objetos de malha da cena atual. O original
continua no arquivo; uma cópia Toon é atribuída aos mesmos slots, e materiais
compartilhados geram apenas uma cópia. O operador informa quantos materiais e
slots foram convertidos e por que ignorou os incompatíveis.

O conversor aceita **Principled BSDF** conectado diretamente a **Material
Output**. Copia Base Color, Metallic, Roughness, Alpha e Emission Color quando
Emission Strength é 1. Aceita Image Texture ligada diretamente a essas
entradas, inclusive uma UV Map direta para Vector, além de Image Texture >
Normal Map > Normal. O Normal Map mantém Strength, Space e UV Map. Texturas
precisam usar projeção Flat, interpolação Linear e extensão Repeat ou Clip.
Volume e Displacement conectados impedem a conversão.
Valores de outros parâmetros do Principled não são traduzidos; a aparência
final pode diferir da Eevee/Cycles.

## Render Priority limitado pela distância (0.46.0)

`Render Priority` agora desloca a comparação de profundidade em unidades da
cena, medidas ao longo da visão da câmera. Prioridade 0 mantém a profundidade
normal; um valor positivo aproxima virtualmente a face para a comparação,
sem alterar seu tamanho ou posição na imagem. Assim, uma face com prioridade
1,5 pode vencer outra 1 unidade à sua frente, mas não outra 3 unidades à sua
frente. Valores negativos a empurram virtualmente para trás. A diferença
entre os valores de prioridade dos dois materiais determina o limite quando
ambos têm prioridades diferentes. O buffer de profundidade não é mais
reiniciado entre prioridades. A mesma regra vale para perspectiva e ortográfica
e para os passes de emissão e identificação de materiais.

## Bloom em câmera panorâmica (0.45.3)

Nas câmeras Equirectangular e Fisheye Equisolid, o Bloom é aplicado depois
da montagem da imagem panorâmica. O Toon Render monta também uma imagem de
emissão separada para que o brilho atravesse as bordas das faces do cubo sem
costuras e mantenha o raio em pixels da imagem final. O ajuste funciona na
viewport e no F12. Os demais efeitos continuam nos passes das faces; no
panorama, o Bloom é composto depois deles. Com Bloom ativo, o F12 usa a
composição GPU mesmo se a opção CPU estiver selecionada.

## Bloom com recombinação suave (0.45.2)

O Bloom agora recompõe progressivamente os níveis de resolução, aplicando
um filtro circular na ampliação e no resultado final. Isso suaviza o contorno
quadrado que ainda aparecia nas áreas largas do brilho. O raio máximo continua
em 1024 pixels. A maior parte da filtragem ocorre nos buffers menores; a
composição final lê apenas o resultado combinado. A imagem de prévia em
`toon_render/bloom_preview.png` usa Radius 100 e Strength 3.

## Bloom em múltiplas resoluções (0.45.1)

O Bloom emissivo usa uma cadeia de 10 reduções suaves de resolução e combina
as escalas conforme o Radius. Isso remove os anéis gerados pela amostragem
esparsa anterior. O Radius aceita até 1024 pixels; seu novo padrão é 24.
A resolução inicial da emissão agora é 75% para melhorar a suavidade das
bordas, e pode ser reduzida para priorizar desempenho. O Threshold é aplicado
antes das reduções. O alpha do brilho continua funcionando em PNG transparente.

## Tint Blend e Bloom emissivo (0.45.0)

O efeito **Color Adjust** oferece 11 modos para o **Tint Blend**: Mix,
Multiply, Overlay, Color Burn, Color Dodge, Add, Screen, Soft Light,
Hard Light, Difference e Subtract. Multiply preserva o resultado anterior
como padrão; o slider Tint controla a intensidade da mistura.

O node **Toon Surface** ganhou a entrada **Emissive**, preta por padrão.
A cor emissiva é somada à superfície sem depender da iluminação. É possível
ligar **Image Texture > Color** ou outro node de cor à entrada; o alpha da
cor ligada também mascara a emissão.

Em **World > Toon Render Post Processing > + Add > Bloom**, o brilho é
gerado exclusivamente a partir das superfícies emissivas. O efeito oferece
**Threshold**, **Radius**, **Strength**, **Resolution** e **Opacity**.
O brilho preserva o fundo transparente e acrescenta alpha aos pixels onde
ele se espalha. Reduzir Resolution melhora a velocidade e suaviza o efeito.

## Tint no Color Adjust (0.44.1)

**Color Adjust** agora tem o slider **Tint** e o seletor **Tint Color**.
O slider mistura a imagem ajustada com a mesma imagem multiplicada pela cor
selecionada, preservando a variação de luz. Em zero, a cor não muda. O filtro
**Limit to Materials** fica abaixo de **Opacity**, como nos outros efeitos;
seu seletor de materiais e conta-gotas também funcionam com o Tint.

## Color Adjust no pós-processamento (0.44.0)

Na aba **World > Toon Render Post Processing > + Add**, o efeito **Color
Adjust** oferece **Brightness**, **Contrast**, **Saturation**, **Luminance**,
**Gamma** e a **Opacity** comum aos efeitos. Brightness soma ou subtrai um
valor aos canais de cor; Luminance multiplica a intensidade. Contrast e Gamma
ajustam os meios-tons, e Saturation em zero gera cinza. Os valores iniciais
preservam a imagem. O efeito participa da ordem da lista e pode ser limitado
a materiais selecionados. O canal alpha original é preservado, inclusive em
renderizações PNG com fundo transparente.

## Invert Y no Normal Map (0.43.2)

O node **Normal Map** tem o checkbox **Invert Y**, inicialmente desmarcado.
Ele inverte a componente verde/Y da normal independentemente do menu
OpenGL/DirectX. Em OpenGL, ativá-lo produz a inversão de DirectX; em DirectX,
as duas inversões se cancelam.

## UV selecionado no Normal Map (0.43.1)

O UV escolhido no node **Normal Map** agora é incluído entre os atributos
solicitados ao montar os buffers da malha. Isso corrige o `KeyError` ao
selecionar um UV diferente do ativo e vale para prévia e render final.

## Normal maps no Toon Surface (0.43.0)

O node **Toon Surface** tem uma entrada **Normal**. É possível ligar
**Image Texture → Color** diretamente nela; nesse caminho, a cor é interpretada
como um normal map de espaço tangente, convenção OpenGL e força 1. Para ajustar
a força ou o espaço, use **Image Texture → Normal Map → Toon Surface**. O node
**Normal Map** oferece os espaços Tangent, Object, World, Blender Object e
Blender World, além das convenções OpenGL e DirectX. No espaço tangente,
**UV Map** vazio usa o mapa ativo; ao escolher outro, use também esse UV para
amostrar a imagem. A normal modifica a iluminação ambiente hemisférica, a
iluminação das luzes e o brilho especular.

Selecione **Non-Color** no campo **Color Space** do node Image Texture para
ler os valores RGB do normal map sem transformação de cor. O relevo é apenas
visual: a geometria e sua silhueta não mudam.

## Padrões das sombras para novas luzes (0.42.4)

As luzes novas começam com as sombras **desativadas**. Ao ativá-las, os
valores iniciais são `Resolution: 1024`, `Distance: 120`, `Cascades: Five`,
`Near Range: 5`, `Middle Range: 20`, `Transition: 0.30`, `Bias: 0.0050`,
`Softness: 1` e `Strength: 1`. Valores já gravados em luzes existentes não
são alterados ao atualizar o addon.

## Sombras próximas com cinco cascatas (0.42.3)

O Sun oferece **Cascades: Five**. Com `Distance: 100`, `Near Range: 5` e
`Middle Range: 50`, as cinco faixas de profundidade da câmera terminam
aproximadamente em 1,6, 5, 15,8, 50 e 100 unidades. As três primeiras usam
a resolução integral configurada na luz; as duas últimas usam metade dessa
resolução. Assim, as duas primeiras faixas preservam mais detalhe dentro de
5 unidades e a terceira melhora o trecho logo depois de 5. O modo **Three**
continua disponível e agora usa resolução integral também na cascata
intermediária.

A comparação da profundidade das sombras agora interpola entre os pixels do
mapa antes de aplicar a suavização. Isso reduz os degraus quadrados nas bordas,
mas não cria detalhe geométrico além da resolução do mapa. O modo **Five**
renderiza mais mapas e usa mais memória de GPU que **Three**. Para a configuração
mostrada acima, selecione **Five** no menu da luz após atualizar o addon.

## Alcance independente das cascatas próximas (0.42.2)

O Sun em modo **Three** separa `Distance` dos limites das duas primeiras
cascatas. `Near Range` começa em **5** unidades da cena e `Middle Range` em
**20**; aumentar `Distance` até **100** ou mais amplia principalmente a faixa
distante. A área próxima continua usando o mapa de maior resolução. Se o
objeto principal estiver além de 5 unidades da câmera, aumente `Near Range`
até cobri-lo; `Middle Range` define onde começa a faixa de menor detalhe.
Quando `Distance` é menor que esses limites, as duas divisões se ajustam
automaticamente para caber nele. A faixa distante ainda perde nitidez à
medida que cresce, como esperado em sombras em cascata.

## Precisão das sombras em cascata (0.42.1)

O `Bias` do Sun com **Cascades: Three** agora é medido em unidades da cena,
com valor inicial de **0,02**. O shader acrescenta uma pequena correção pela
inclinação da superfície e pelo tamanho do texel de cada cascata. Assim,
aumentar `Distance` não multiplica o afastamento da sombra. Os mapas RGBA16F
guardam a profundidade em duas componentes para reduzir erros de arredondamento
sem duplicar sua memória. Point, Spot e o Sun em modo Single mantêm o Bias
normalizado anterior. O teste de render a **2048 pixels** produziu sombras
comparáveis em **30** e **100** unidades da cena no Blender 4.5.9 e 5.3.

## Sombras em cascata no Sun (0.42.0)

Em **Light Properties > Toon Render Shadows**, o Sun oferece **Cascades**:
**Three** é o padrão e **Single** mantém o mapa fixo anterior. Three divide o
campo de visão em três faixas de distância e cria mapas com resolução **R**,
**R/2** e **R/4**, em que R é `Resolution` da luz. As três faixas usam um atlas
por camada de transparência, com transição gradual entre elas. `Distance`
define até onde a câmera recebe essas sombras. `Near Range` e `Middle Range`
definem as duas primeiras divisões; `Transition` regula a mistura nas bordas.
O Sun em cascata tem seu próprio `Bias` inicial de 0,02 em unidades da cena. Em Single, `Area Size`
e o Bias anterior continuam disponíveis. Point e Spot não mudaram. A posição
das cascatas é estabilizada na grade de texels para reduzir cintilação ao mover
a câmera. Three desenha a geometria três vezes por camada; a área total dos
mapas é cerca de 31% maior do que a de um mapa único da mesma resolução.

## Padrões do AO (0.41.2)

Ambient Occlusion inicia em **World**, com Radius **0,6**, Strength **0,6**
e Bias **0,25**. Bias aceita valores até **0,6**. Os presets Performance,
Balance e Quality usam respectivamente **24**, **32** e **64** amostras.
O efeito mistura a cor escolhida nas regiões de vale; Ridge continua
iluminando as bordas convexas. Os presets de amostras também se aplicam ao efeito Color
Transmission, que usa o mesmo passe de contato.

## Ambient Occlusion com Cavity (0.41.0)

O efeito **Ambient Occlusion** oferece **Type: World, Screen ou Both**.
World amostra profundidade e normais no raio em unidades da cena para escurecer
vales e destacar cristas. Screen usa a curvatura das normais vizinhas para
realçar detalhes locais com quatro leituras por pixel. Both combina os dois.
Os controles Ridge e Valley são independentes para World e Screen. Color,
Opacity, filtro por material e limiar de transparência continuam disponíveis.
Screen não usa Samples, Radius ou Bias; esses controles aparecem quando World
faz parte do modo escolhido. O efeito é uma adaptação ao buffer de geometria do
Toon Render, pois o shader do Solid depende de buffers internos do Workbench.

## Ambient Occlusion e Color Transmission (0.40.3)

Em **World Properties > Toon Render Post Processing > + Add**, escolha
**Ambient Occlusion**. O efeito usa profundidade e normais da cena para
encontrar contatos próximos e aplica um filtro que respeita descontinuidades.
Ele tem apenas uma **Color** sólida, preta por padrão. A transmissão de cor
agora é um efeito independente chamado **Color Transmission**, disponível no
mesmo menu **+ Add**; não exige que Ambient Occlusion esteja ativo.

Ambos os efeitos usam os controles de qualidade e alcance abaixo. Color
Transmission usa apenas as cores das faces próximas e receptoras, com
**Contact Strength** e **Transmission Strength** para regular a mistura.
Ele não escurece a região de contato nem usa uma cor de sombra. Faces escuras
contribuem menos, e faces pretas não transmitem cor. Os efeitos podem ser
ligados, desligados e reordenados separadamente na
pilha.

Em **Color Transmission > Blend Mode**, escolha **Mix** (interpolação usada
antes), **Additive** (soma de cor, inclusive HDR), **Screen** (clareia sem
somar diretamente) ou **Overlay** (mistura conforme o brilho da face
receptora). Overlay é o padrão. A
transmissão de uma face preta permanece zero em todos os modos.

Em **Material Properties > Toon Render > Color Transmission Strength**, cada material
controla quanto da própria cor transmite para as superfícies próximas. O valor
padrão é 1; 0 desativa a transmissão desse material e valores acima de 1 a
intensificam. Esse controle atua na face emissora e funciona separadamente
para os materiais de uma mesma malha.

Os presets **Performance**, **Balance** e **Quality** usam respectivamente
24 amostras a 50%, 32 a 75% e 64 a 100% da resolução. **Samples** e
**Resolution** podem ser ajustados depois de escolher o preset. **Radius**
controla o alcance em unidades da cena; **Strength**, **Bias**, **Opacity**
e **Edge-Aware Denoise** controlam a aparência e o custo.

Color Transmission simula artisticamente uma transmissão colorida; não é
transporte físico de luz. Ambos os efeitos aceitam filtro por
material e **Occlusion Alpha Threshold**, como os outros efeitos da pilha.
Por ser um efeito de tela, só considera as superfícies visíveis no buffer de
profundidade.

A implementação GLSL é própria, inspirada na amostragem de profundidade e
filtragem descritas em [Scalable Ambient Obscurance](https://research.nvidia.com/sites/default/files/pubs/2012-06_Scalable-Ambient-Obscurance/McGuire12SAO.pdf)
e nas recomendações de qualidade do [Intel XeGTAO](https://github.com/GameTechDev/XeGTAO).
Ela é uma versão simplificada, sem os passes completos dessas bibliotecas.

## Roughness e Metalness no Toon Surface (0.38.3)

O nó **Toon Surface** agora tem entradas **Roughness** (padrão 0,5) e
**Metalness** (padrão 0). Cada uma aceita valores entre 0 e 1 ou conexões de
outros nós. Roughness controla o espalhamento do brilho especular sem alterar
a cor difusa do material;
Metalness reduz a parcela difusa e tinge o brilho com a cor do material. O
brilho responde a Sun, Point e Spot e respeita as sombras. A resposta especular
dos materiais não metálicos foi reforçada para que Roughness seja visível mesmo
com Metalness em 0. Em Roughness 0, o reflexo da luz fica mais concentrado. O
modo **Unlit**
continua exibindo a cor pura. É um modelo simples de brilho, sem reflexos do
ambiente ou traçado de raios. Materiais salvos anteriormente recebem as novas
entradas ao carregar o arquivo.

## Iluminação ambiente no World (0.37.0)

Na aba **World Properties > Ambient Lighting**, escolha **Solid Color** ou
**Hemisphere Light**. Solid Color usa uma cor e intensidade para toda a cena;
o padrão branco com intensidade 0,16 preserva a aparência anterior. Hemisphere
Light mistura **Sky Color** e **Ground Color** conforme a normal de cada face.
**Tilt X** e **Tilt Z** orientam o hemisfério em graus, e **Ambient Intensity**
controla a força dos dois modos. A iluminação ambiente é separada da cor de
fundo. Materiais **Unlit** continuam sem influência de luz e sombra.

## Copiar e colar materiais (0.36.1)

Os menus de slots nas abas **Material Properties** e **Toon Shader Editor**
usam comandos próprios de **Copy Material** e **Paste Material**. O comando
nativo de colagem do Blender falha ao colar a referência ao node tree customizado.
A cópia do Toon Render guarda o material e o grafo; cada colagem cria cópias
independentes dos dois. Também é possível usar **F3 > Copy Toon Material** e
**F3 > Paste Toon Material**. A cópia temporária é limpa ao desativar o addon.

## Extensão da Image Texture (0.36.0)

O nó **Image Texture** tem um seletor **Tile / Clip**. Tile é o padrão e repete
a imagem fora do intervalo UV 0–1. Clip retorna preto transparente (Color 0,
Alpha 0) fora desse intervalo, inclusive em Mapping Triplanar. Para que a
região externa fique invisível no material, ligue também a saída **Alpha** da
Image Texture à entrada **Alpha** do Toon Surface ou Material Output. Isso
segue a extensão [Repeat / Clip do Image Texture do Blender](https://docs.blender.org/manual/en/latest/render/shader_nodes/textures/image.html).

## Centro da textura em Object Transform (0.35.1)

No modo **Object Transform** do Mapping, a origem do objeto ou bone agora
corresponde ao centro UV **(0.5, 0.5)** da textura. O deslocamento de meio UV é
aplicado depois da rotação, escala e Location do nó. Assim, rotação e escala
partem do centro do controlador, e o offset mantém sua posição durante esses
ajustes. Os demais modos do Mapping não mudaram.

## Mapping por objeto ou bone (0.35.0)

O nó **Mapping** tem o modo **Object Transform**. Selecione um objeto controlador
(por exemplo, um Empty) e, para uma armature, um bone opcional. A posição,
rotação e escala avaliadas do controlador definem o espaço da textura; a
animação por keyframes ou pose atualiza o mapeamento no viewport e no F12.
Escolha o plano **XY**, **XZ** ou **YZ** para converter as coordenadas 3D em uma
textura 2D. Se nenhum objeto for escolhido, o nó usa o espaço local da malha.
A entrada **Vector**, quando ligada, substitui a origem das coordenadas.

Esse comportamento segue o uso de [coordenadas de objeto para mover texturas](https://docs.blender.org/manual/en/latest/render/shader_nodes/input/texture_coordinate.html)
do Blender; o seletor de bone e os planos de projeção são controles do Toon Render.

## Seleção de UV maps (0.34.0)

Os nós **UV Map** e **Mapping**, no modo **UV**, mostram um seletor de UV map da
malha ativa. Se o campo ficar vazio, usam o UV map ativo da malha. O seletor do
Mapping fica desabilitado quando a entrada Vector está ligada, pois essa
entrada fornece as coordenadas. Materiais podem ler vários UV maps ao mesmo
tempo; o buffer da malha inclui somente os mapas nomeados usados pelos nós.

## Overlays e seleção da câmera panorâmica (0.33.1)

No Blender 4.5, o botão padrão de overlays na visão panorâmica alterna os
elementos panorâmicos desenhados pelo Toon Render. Os overlays nativos em
perspectiva continuam temporariamente ocultos para evitar o piscar. Ao sair
da câmera panorâmica, o estado escolhido é restaurado no viewport. Na visão
panorâmica, clique na borda da câmera para selecioná-la, inclusive quando a
borda estiver perto de outro objeto.

## Render final mais rápido (0.33.0)

O F12 transfere os pixels da GPU para o resultado do Blender em um bloco, sem
converter cada pixel em uma tupla Python. No Blender 4.5, a leitura do buffer
preserva a ordem dos canais; no 5.3, usa a disposição nativa. Câmeras panorâmicas
compõem as seis vistas na GPU e leem a imagem pronta uma vez. Em **Render
Properties > Toon Render > Final Render**, ajuste a porcentagem da resolução
final, ative ou desative sombras e pós-processamento e reduza a resolução dos
mapas de sombra. Para câmera panorâmica, ajuste a qualidade das faces e escolha
composição GPU (padrão) ou CPU. Esses ajustes afetam o F12; a prévia tem
controles próprios em **Viewport Preview**.

## Bones na câmera panorâmica (0.30.0)

Em **Pose Mode** e na visão da câmera panorâmica, o Toon Render desenha os bones
com a mesma projeção equiretangular ou fisheye equisolid da imagem. Clique em um
bone na posição projetada para selecioná-lo; Shift+clique alterna a seleção.
Os atalhos R/G/S continuam disponíveis para posar. Ao sair da câmera, a
visualização nativa dos bones é restaurada automaticamente.

Esta primeira versão panorâmica representa os bones como linhas e não projeta
os custom shapes nem os gizmos de transformação nativos do Blender.

## Câmera panorâmica (0.29.0)

Na versão 0.29.1, o addon recarrega o módulo `panorama` ao atualizar a
instalação no Blender aberto. Isso evita misturar o motor novo com shaders
panorâmicos antigos mantidos em memória pelo Python.

Na aba **Object Data Properties** da câmera, o painel **Lens** do Toon Render
mostra perspectiva, ortográfica e panorâmica. Em **Panoramic**, selecione
**Equirectangular** e ajuste os limites de longitude e latitude, ou escolha
**Fisheye Equisolid** e ajuste lente, campo de visão e sensor. **Render Face
Resolution** e **Viewport Face Resolution** controlam a nitidez e o custo de
cada modo.

O render final e a prévia em tempo real no modo de câmera funcionam no Blender
4.5.9 e 5.3. O Toon Render rasteriza seis vistas de 90° e compõe a imagem;
o viewport faz a composição diretamente na GPU. A EEVEE só passou a suportar
câmeras panorâmicas no Blender 5.3. Os outros tipos de projeção panorâmica da
câmera ainda não são suportados no Toon Render. Os efeitos de pós processamento
atuais são aplicados por vista e podem apresentar emendas nas bordas.

Objetivo: criar um renderizador rasterizado para Blender 4.5.9 e 5.3, com resposta
interativa no viewport e controle explícito dos passes. A primeira entrega
executável deve mostrar malhas opacas com cor simples; texturas, transparência,
ordem de materiais e line art entram depois, sobre uma base medida e estável.

## Referência examinada

O arquivo `../BlenderMalt-Windows (1).zip` contém o addon BlenderMalt e o
framework Malt. A análise abaixo se baseia no código dentro desse ZIP, sem
copiá-lo para este projeto.

- `BlenderMalt/MaltRenderEngine.py`: implementa `bpy.types.RenderEngine`.
  `view_update` invalida a cena e as malhas alteradas; `view_draw` monta a cena
  avaliada, solicita um quadro e apresenta o resultado; `render` entrega os
  pixels ao resultado final do Blender.
- `BlenderMalt/MaltMeshes.py`: triangula a geometria avaliada, separa índices
  por material, extrai posições, normais e UVs, e usa código C para acelerar
  parte da extração. Mantém cache de malhas no viewport.
- `BlenderMalt/.MaltPath/Bridge/Client_API.py` e `Bridge/Server.py`: enviam a
  cena a um processo separado que cria um contexto OpenGL 4.5 via GLFW.
  O resultado volta por PBO, leitura de pixels e memória compartilhada. No
  `view_draw`, o Blender cria uma textura com esses pixels e desenha um quad.
- `BlenderMalt/.MaltPath/Malt/Pipeline.py`: agrupa objetos por material e malha,
  usa instancing e emite draw calls. O `draw_scene_pass` fixa estado de depth
  test e desliga blending antes de percorrer os materiais.
- `Malt/Pipelines/NPR_Pipeline`: demonstra passes, buffers auxiliares, material
  shaders e line art. Para transparência, `RenderLayers.py` repete o grafo por
  várias camadas de depth peeling, com custo proporcional ao número de camadas.
  `Shaders/Filters/Line.glsl` usa profundidade e normais para detectar linhas.
- `Malt/Pipelines/MiniPipeline/MiniPipeline.py`: exemplo mínimo de um FBO de
  cor e profundidade com um passe de malhas. É a melhor referência para o
  primeiro marco funcional.

O manifesto do addon de referência declara Blender mínimo 4.1, não 4.5.9
especificamente. Este addon próprio foi testado com o Blender 4.5.9 fornecido
pelo usuário.

## Viabilidade e escolha técnica

Sim: a técnica central é a mesma de um renderizador de jogos convencional:
malhas em buffers na GPU, shaders GLSL, teste de profundidade, passes em FBO e
composição de tela. Não há necessidade de WebGL, navegador ou ray tracing.
O custo real depende de resolução, quantidade de pixels por passe, número de
draw calls, geometria, materiais e frequência de atualização; "OpenGL" por si
só não garante rapidez.

Não convém reproduzir toda a arquitetura do Malt. O grafo genérico, o processo
separado, a leitura e o reenvio de cada quadro e os múltiplos passes de depth
peeling atendem a objetivos mais amplos. Para `toon_render`, a proposta inicial
é um pipeline fixo e pequeno:

1. Addon `RenderEngine` próprio, com `view_update`, `view_draw` e `render`.
2. Sincronização incremental de câmera, transformações e malhas avaliadas.
3. Cache de buffers por malha e um passe opaco com depth test em textura/FBO.
4. Apresentação da textura no viewport e leitura de pixels apenas quando
   necessária para o render final.
5. Medição separada de exportação da cena, desenho GPU e apresentação.

Para o primeiro protótipo, vale experimentar a API `gpu` do Blender 4.5 dentro
do próprio processo, que oferece shaders, batches e renderização offscreen.
Ela usa o backend gráfico do Blender; portanto a implementação deve evitar
pressupor que o contexto do viewport será sempre OpenGL puro. Caso a API não
permita o controle de estado ou a passagem de textura que o projeto exigir,
o fallback é um processo OpenGL próprio, como no Malt, medindo o custo da
transferência de quadros antes de adotá-lo.

## Evolução após a primeira imagem

1. Cor e textura de material, UV, alpha cutout.
2. Ordenação explícita por fila de renderização e passes opaco/transparente;
   transparentes convencionais exigem ordenação por distância e blending.
3. Buffer de normais e profundidade; detecção de contornos em tela; composição
   de line art. Controlar largura e sensibilidade sem reprocessar a geometria.
4. Ajustes de desempenho: cache persistente, menos mudanças de shader,
   resolução reduzida no viewport e limites claros de custo por passe.

## Protótipo 0.27.0

Compatibilidade com Blender 4.5.9 e 5.3. O Blender 5.x requer criação dos
shaders via `GPUShaderCreateInfo`; o Blender 4.5 mantém seu caminho GLSL
original. No Blender 5.3, todos os passes usam explicitamente o tamanho do
viewport do destino, inclusive com Vulkan. Materiais, transparência, sombras,
nodes, Outline e Mosaic foram testados no backend Vulkan padrão do 5.3 e no
OpenGL do 4.5.9.

## Protótipo 0.26.0

`Z Depth`, na categoria Shader, gera uma máscara de contato em tons de cinza
comparando a profundidade do material com a geometria visível de outros
objetos na direção da câmera. `Distance` limita a separação em unidades da
cena; `Expand` amplia a máscara em pixels e `Alpha Threshold` ignora fontes
muito transparentes. A saída `Fac` pode alimentar Color, Alpha ou um Color
Ramp. Por usar a profundidade da câmera, o efeito depende do enquadramento.

`Fresnel` retorna uma máscara em tons de cinza conforme o ângulo entre a
normal da face e a câmera. `Power` controla a concentração nas bordas.

Remover um efeito de pós processamento desativa imediatamente seu passe no
viewport e no render final, inclusive Outline / Lineart e Mosaic.

`Flip Book`, na categoria Texture, lê uma sprite sheet e oferece `Horizontal
Frames`, `Vertical Frames`, `Start Frame` e `End Frame`. A ordem é da esquerda
para a direita e de cima para baixo, começando no índice 0. `End Frame = -1`
usa a última célula automaticamente. A entrada numérica `Frame` seleciona
um quadro dentro do intervalo, começando em 0 e repetindo em loop. Ela aceita
diretamente a saída do node `Time` ou de qualquer outro node numérico. As saídas `Color` e `Alpha`
podem alimentar o material, inclusive em PNGs transparentes. A entrada
`Vector` aceita UV ou a saída do node Mapping.

`Time`, na categoria Utilities, retorna segundos como float. `Real Time`
continua aumentando com a timeline parada e atualiza a 3D View enquanto o
Toon Render está ativo. `Scene Time` usa o frame e o FPS da cena, adequado
para renderizar animações de forma reproduzível. Para animar a sprite sheet,
ligue `Time > Seconds` a `Flip Book > Frame`. Para controlar a velocidade,
insira um node `Math > Multiply` entre eles. O modo Real Time segue o relógio
do Blender; na exportação de animação, use Scene Time se cada frame precisar
corresponder exatamente ao FPS configurado.

Em `Light Properties > Toon Render Light`, luzes Sun, Point e Spot mostram
`Color` e `Strength`. Esses campos editam diretamente `Light.color` e
`Light.energy`, que o shader do Toon Render já usa. A força da sombra continua
no painel separado `Toon Render Shadows > Strength`.

O node `Blur`, na categoria Color, recebe e retorna `Color`. `Radius` define o
raio em pixels da imagem, `Strength` mistura a cor original com a borrada e
`Quality` escolhe 3×3, 5×5 ou 7×7 amostras. O renderer desenha a informação
que entra no node em um buffer próprio e então faz o blur, portanto também
funciona com cores geradas por outros nodes, incluindo `Proximity Mask` e
`Shader to RGB`. É possível encadear dois ou mais nodes Blur. A cor borrada
pode ser ligada a `Material Output > Color` ou convertida em máscara para
`Alpha`. Cada Blur ativo adiciona um buffer na resolução do render e mais
amostras de textura por pixel; raios grandes e qualidade 7×7 custam mais.

`Proximity Mask > Filter by Material` restringe a detecção aos materiais da
lista do próprio node. Use `+` para criar entradas e selecione o material em
cada uma; desligado, o node considera todas as outras malhas. O passe de
geometria de Outline e Mosaic agora ignora corretamente os uniforms de
proximidade quando a máscara só influencia a cor do material.

`Image Texture` apresenta a entrada `Vector` para ligar a saída de `Mapping`
ou outro vetor; sem ligação, continua usando a UV ativa. Ao abrir um arquivo
com nós Image Texture antigos, o addon acrescenta essa entrada automaticamente.

`Proximity Mask`, na categoria Shader, agora usa projeção direcional em vez de
amostras ao redor do pixel da câmera. `Direction` é o vetor em coordenadas do
mundo no sentido em que a geometria de origem projeta a máscara no material
receptor. Por exemplo, para projetar algo à frente de uma face em Y negativo
sobre essa face, use uma direção com Y positivo. `Distance` limita o percurso
do raio nessa direção; `Bias` evita influências quando as superfícies estão
quase coincidentes. `Resolution` determina a nitidez da silhueta (256, 512 ou
1024). A projeção ortográfica é ajustada aos limites do objeto receptor, então
a forma não muda com o movimento da câmera. Ligue `Fac` a `Color Ramp`,
`Mix Color` ou `Alpha` para criar efeitos sem lâmpada.
`Alpha Threshold` descarta pixels de origem pouco opacos; os demais contribuem
com seu alpha, inclusive quando ele vem de textura. O próprio objeto receptor
é excluído, mesmo com vários materiais. Cada combinação de objeto receptor,
filtro de materiais e configuração de projeção usa um mapa adicional. O mapa
guarda a primeira superfície vista na direção escolhida; várias superfícies
transparentes sobrepostas ainda não são acumuladas nesse passe.

O Toon Shader Editor agora oferece `Vertex Color`, `Object Color` e `Mapping`
na categoria Texture. `Vertex Color` escolhe um Color Attribute da malha pelo
nome e retorna Color e Alpha; funciona com atributos nos domínios Corner e
Point. `Object Color` retorna Color e Alpha da propriedade `Object > Viewport
Display > Color` de cada objeto. O buffer de vértices continua compartilhado
pelos materiais do objeto e inclui somente os atributos de cor usados pelos
seus shaders.
`Mapping` se liga à nova entrada Vector de `Image Texture`. Seus modos são UV,
Object, World, Triplanar e MatCap, com controles de Location, Rotation e Scale.
Triplanar mistura três projeções da imagem conforme a normal local, com
controle Blend para a nitidez da transição; MatCap usa a reflexão da normal
vista pela câmera. A entrada Vector do Image Texture usa a UV ativa quando
fica sem ligação. O modo Triplanar requer ligação direta de `Mapping > Vector`
para `Image Texture > Vector`.

Em `Render Properties > Toon Render`, `Transparent` preserva o alpha do fundo,
dos materiais Blend e dos materiais Additive no PNG final. Ao ativar essa opção,
o formato de cor do PNG muda para RGBA. Outros formatos, incluindo vídeo, usam
fundo opaco. O Outline e o Mosaic também preservam esse alpha durante os passes
de pós-processamento.
Em `World Properties > Viewport Display`, `Background Color` substitui o campo
`Color` do Blender e define a cor de fundo do viewport e do render quando
`Transparent` está desligado. Sem World, o fundo usa cinza escuro.
Os painéis nativos de `Object Data Properties` voltam a aparecer para malhas,
Curves e Point Clouds, incluindo Vertex Groups, Shape Keys, Color Attributes,
UV Maps, Attributes e dados de geometria compatíveis com cada tipo.

O arquivo `__init__.py` já é um addon instalável. Ele renderiza malhas avaliadas
trianguladas, respeita a câmera e as instâncias, e aplica teste de profundidade.
Ao selecionar `Toon Render` como motor de uma cena, o addon muda automaticamente
`Color Management > View Transform` para `Standard`. O mesmo ajuste é feito ao
abrir um arquivo que já usa Toon Render. Depois da ativação, o usuário ainda
pode alterar o View Transform manualmente.
O editor `Toon Shader Editor` é uma árvore de nós própria. Cada material novo
recebe apenas `Toon Surface` e `Material Output`. Cor e Alpha ficam em entradas
do `Toon Surface`; Alpha sem conexão oferece um slider de 0 a 1. O menu
`Add`/`Shift+A` agrupa os 17 nós em `Shader`, `Texture`, `Color` e `Utilities`.
Para textura, adicione `Image Texture` e conecte `Color` a `Color` e, se quiser usar o canal
alpha da imagem, `Alpha` a `Alpha`. A imagem usa a camada UV ativa da malha.
O grafo agora avalia os nós utilitários por pixel no shader da GPU. `Alpha`
aceita saídas escalares e saídas de cor; uma cor ligada a `Alpha` é convertida
para luminância RGB. `Image Texture > Color` pode alimentar diretamente Alpha,
assim como `RGB`, `Gradient Texture`, `Color Ramp`, `Mix Color` e combinações
desses nós. `Gradient Texture` usa UV e oferece `Scale` e modos Linear,
Diagonal, Radial e Spherical. `Color Ramp` usa a interface de rampa do Blender,
com suas interpolações e cores, e possui saídas `Color` e `Alpha`.
Os demais nós utilitários são `Value`, `UV Map`, `Separate Color`,
`Combine Color`, `Math`, `Map Range` e `Invert Color`. `Mix Color` oferece os
19 modos do Blender 4.5.9: Mix, Darken, Multiply, Color Burn, Lighten, Screen,
Color Dodge, Add, Overlay, Soft Light, Linear Light, Difference, Exclusion,
Subtract, Divide, Hue, Saturation, Color e Value. Seus valores são enviados
como uniforms; alterações numéricas não exigem recompilar o shader. Alterar
ligações, modo de mistura ou tipo de gradiente altera a variante do shader.
`Material Output` agora possui `Surface`, `Color` e `Alpha`. Sem conexão em
`Color`, a entrada `Surface` mantém a iluminação normal do `Toon Surface`.
Ao ligar uma cor em `Color`, ela vira a cor final do pixel, sem uma segunda
aplicação de luz. `Shader to RGB` transforma a saída `Shader` do `Toon Surface`
em cor já iluminada, que pode passar por `Color Ramp`, `Mix Color` e outros nós
antes de entrar em `Material Output > Color`. Assim é possível quantizar a
iluminação para criar faixas toon. `Toon Surface` também oferece saída `Alpha`.
`Shadow Mask`, na categoria `Shader`, oferece uma saída `Fac`: 0 em áreas sem
sombra e até 1 nas áreas cobertas por uma sombra de Sun, Spot ou Point.
Quando há várias luzes com sombras, usa o maior valor de sombra. É possível
ligar `Fac` diretamente a `Material Output > Alpha` para mostrar uma superfície
somente onde há sombra; com `Color Ramp`, é possível ajustar a borda ou
inverter a máscara. A luz precisa ter `Shadows` ativado e o material precisa
ter `Receive Shadow` marcado. No passe que produz os mapas de sombra, o nó usa
um valor constante para evitar dependência circular com sua própria máscara.
O buffer de geometria usado pelo Outline ainda não reproduz a máscara de
sombra no contorno de superfícies com esse Alpha.
No `Material Output`, uma ligação em `Alpha` define a transparência final.
Sem ligação, o slider `Alpha` controla a transparência diretamente: com
`Surface` ativo ele multiplica o Alpha do `Toon Surface`; com `Color` ligado,
vale sozinho. O valor padrão 1 mantém a transparência anterior.
O nó `Additive` possui uma entrada `Color` com seletor de cor, que também aceita
uma conexão RGB ou textura, controle `Intensity` e uma saída `Shader` para
`Material Output > Surface`. O renderizador usa mistura aditiva convencional:
`RGB final = RGB da cena + RGB do Additive × Alpha`. O alpha da cor ou textura
é multiplicado pelo `Alpha` do `Material Output`. `Intensity` começa em 1 e
aceita valores HDR acima de 1. Sua cor não depende das luzes. O passe usa
teste de profundidade e não escreve profundidade, permitindo que geometrias
sobrepostas contribuam juntas. Uma conexão em
`Material Output > Color` prevalece sobre `Surface` e desativa o modo aditivo.
Em `Material Properties > Toon Render`, `Double Sided` e `Unlit` começam
desmarcados. `Double Sided` mostra frente e verso da face; desmarcado, o verso
é descartado no render normal e no mapa usado pelo Outline. `Unlit` usa a cor
e a textura do material sem aplicar iluminação, mantendo Alpha e transparência.
`Cast Shadow` e `Receive Shadow` começam marcados. O primeiro decide se os
triângulos desse material entram nos mapas de sombra das luzes; o segundo
decide se a contribuição de luz desse material é escurecida pelas sombras.
Ambos funcionam por material, inclusive quando um objeto usa vários slots.
O renderizador desenha materiais transparentes depois dos opacos, com blending
alpha e ordenação de objetos pela distância à câmera. `Toon Surface` oferece
`Transparency: Blend/Cutout` abaixo da entrada `Alpha`. Em Cutout, `Threshold`
descarta pixels abaixo do valor e os restantes escrevem profundidade. Em Blend,
`Threshold` descarta pixels quase transparentes antes da mistura e do pré-passe
de profundidade; o valor inicial é 0,001. Aumente-o se bordas transparentes
estiverem encobrindo superfícies atrás delas. `Transparency Overlap` também
fica abaixo de Alpha: ligado, mistura todas as faces; desligado, usa um
pré-passe de profundidade para mostrar somente a superfície mais próxima em
cada pixel.
`Render Priority` é um float logo abaixo dos controles de transparência.
Ele desloca a profundidade virtualmente em unidades da cena. Uma prioridade
maior só coloca a face na frente se a diferença de distância entre as faces
for menor que a diferença de prioridade. Opacos (inclusive Cutout) são
renderizados antes de Blend e Additive; Blend é ordenado pela profundidade
virtual. O buffer de profundidade continua ativo entre materiais.
A iluminação lê até quatro lâmpadas Sun, Point ou Spot da cena, incluindo cor e
intensidade. Point e Spot usam distância;
Spot também usa direção, tamanho e suavidade do cone. Há uma parcela ambiente
fixa. A escala das lâmpadas locais é aproximada, não física.
Em `Light Properties > Toon Render Shadows`, Sun, Point e Spot oferecem
`Shadows` (desligado por padrão), resolução, distância, bias, suavidade e força.
Sun oferece três mapas em cascata, ou um único mapa com `Area Size` se
`Cascades` estiver em `Single`. Point usa seis projeções reunidas num atlas 2D; resoluções altas nesse
tipo de luz consomem mais memória. As sombras são calculadas por luz e não
escurecem materiais `Unlit`. O mapa usa Alpha do `Toon Surface`, inclusive
Alpha conectado a `Image Texture`: Cutout faz sombra recortada e Blend
transmite luz proporcional à opacidade. Duas camadas de profundidade permitem
sombras de até duas superfícies transparentes sobrepostas ao longo do raio;
sobreposições mais profundas ainda não são representadas integralmente.
Também há uma fila opaca explícita, agrupada por
variante de shader e material. Geometria do viewport fica em cache até uma
atualização geométrica.

Na versão 0.10.1, a montagem das malhas usa leitura em blocos e NumPy em vez
de percorrer cada canto da malha em Python. O cache do viewport agora invalida
somente as malhas alteradas; peças com deformação de esqueleto são
reconstruídas a cada quadro e peças estáticas, inclusive as que usam Mirror,
mantêm seus buffers GPU. No arquivo `hero.blend` fornecido para medir, a etapa
de montagem das 19 malhas caiu de aproximadamente 48 ms para 7 ms por quadro
após o primeiro quadro, em render de teste de 256 × 256. Essa medição isola a
montagem de malhas no F12; o FPS do viewport deve ser medido na interface.
Na versão 0.11.1, cada malha avaliada cria um único Vertex Buffer para posições,
normais e UVs. Cada material usado cria apenas seu Index Buffer e um batch que
referencia o Vertex Buffer comum. Isso elimina a duplicação dos atributos por
material, inclusive quando a malha deformada precisa ser enviada novamente em
cada quadro. O número de chamadas de desenho por material permanece igual.

Na aba `World`, o painel `Toon Render Post Processing` contém uma pilha de
efeitos. `+ Add` oferece `Outline / Lineart` e `Mosaic`; cada item pode ser
ativado, desativado, removido e movido para cima ou para baixo. A ordem da
lista é a ordem de aplicação. `Outline / Lineart` tem cor, espessura em pixels,
sensibilidade à profundidade e às normais, e opacidade. O renderizador desenha
a cena em uma textura, gera um mapa de normais e distância da câmera e aplica
os efeitos em passes sucessivos de tela cheia. O mapa ignora detalhes internos
da textura de cor; detecta silhuetas e mudanças de forma. Alpha e Cutout
definem onde há geometria no mapa. `Mosaic` divide a imagem em células
quadradas com `Pixel Size` de 1 a 256 pixels e mistura a cor pixelizada com
`Opacity` de 0 a 1. Com Pixel Size 1 ou Opacity 0, preserva a imagem.
As configurações pertencem ao datablock World, portanto
cenas que compartilham o mesmo World compartilham a pilha.
Ambos os efeitos têm `Limit to Materials`, desligado por padrão para agir sobre
toda a cena. Ao ativar, use `+` para inserir materiais
na lista ou o conta-gotas para clicar em uma face na 3D View e adicionar seu
material. `-` remove o item selecionado. A lista vazia não aplica o efeito.
O filtro usa o material visível por pixel, inclusive em objetos com vários
materiais; no Outline, também desenha a borda entre um material selecionado e
outro não selecionado. No Mosaic, apenas pixels do material escolhido são
pixelizados, respeitando a geometria visível. Quando `Limit to Materials`
está ativo, `Occlusion Alpha Threshold` controla quais superfícies Blend ou
Additive na frente bloqueiam essa seleção: com alpha abaixo do limiar, a
superfície não oculta o material selecionado atrás dela no mapa de IDs. O
limiar não descarta o próprio material selecionado, mesmo que ele seja
Additive e seu alpha esteja abaixo do valor do slider.
O Outline / Lineart oferece o mesmo slider e o aplica tanto ao mapa de IDs
quanto ao mapa de geometria que detecta contornos, inclusive sem filtro de
materiais. Por exemplo, para uma malha com alpha 0,8, use um limiar maior
que 0,8. O render da malha transparente continua normal; o limiar afeta
apenas as máscaras usadas pelo pós-processamento. Efeitos com limiares
diferentes recebem mapas separados.
Cada efeito da pilha pode ter sua própria lista. O mapa de IDs de materiais
exige um passe adicional de geometria quando um filtro tem materiais na lista
ou quando Color Transmission está ativo; nesse caso também guarda a intensidade
emitida por cada material.

Os nós do Shader Editor padrão não integram esta árvore. O grafo próprio é
armazenado no material; o renderizador segue seus links até o `Material Output`.
Se o material não tem grafo Toon, o addon usa `diffuse_color`. A ordenação de
Blend é por objeto; `Transparency Overlap` desligado resolve faces sobrepostas
do próprio batch, mas interseções complexas entre objetos ainda podem depender
da ordem. O Outline atual não gera linhas para detalhes
que existem apenas na textura de cor.

O `Toon Shader Editor` mantém no centro do cabeçalho o popover `Slot` e o
seletor de material com `New`, como no Shader Editor padrão. Com Toon Render
ativo, esse `New` cria um material Toon, gera `Toon Surface` e `Material Output`,
e associa a árvore ao material. O addon não acrescenta um botão ao cabeçalho do
viewport. No topo de `Material Properties`, o painel de slots mostra a lista
de materiais do objeto, os botões para adicionar, remover e reordenar slots,
e o seletor de material. Seu `New` também cria um material Toon. No modo Edit,
`Assign`, `Select` e `Deselect` permitem atribuir o material ativo às faces
selecionadas e inspecionar essa atribuição. O painel `Toon Render` com
`Double Sided`, `Unlit`, `Cast Shadow` e `Receive Shadow` aparece logo abaixo.
Em `Output Properties`, o Toon Render mostra os painéis nativos `Format`,
`Frame Range` e `Output`, incluindo resolução, porcentagem, proporção dos
pixels, taxa de quadros, intervalo e passo da animação, caminho, formato e
opções de arquivo. Os subpainéis de gerenciamento de cor, densidade de pixels
e codificação de vídeo também aparecem quando aplicáveis. Esses valores são
as propriedades padrão do Blender; não há uma cópia separada no addon.
Para abrir o editor dedicado em uma área, use a busca F3 por `Open Toon Shader
Editor`; depois você pode conservar essa área no seu workspace. O cabeçalho
padrão do Blender foi substituído apenas para esta árvore, pois seu `New`
criava um grupo de nós solto que não aparecia no material.
Materiais existentes do Blender conservam seus dados; eles não são alterados
pelo addon. O antigo nó de grupo usado na versão 0.3 foi removido.

Teste realizado: Blender 4.5.9 LTS, em segundo plano. `smoke_editor.py` criou
via `New Material` um grafo com exatamente dois nós e confirmou que a árvore
permanece associada ao material depois de salvar e reabrir o `.blend`.
`smoke_materials.py` renderizou dois cubos com dois nós `Image Texture`
independentes. `smoke_lights.py` comparou o render ambiente aos renders Sun,
Point e Spot, e confirmou que uma Spot apontada para longe não ilumina o cubo.
`smoke_alpha.py` confirmou render opaco, Alpha 0, Alpha 0,5 e Alpha vindo de
imagem RGBA. Também comparou Cutout e Blend acima/abaixo dos thresholds e
Transparency Overlap ligado/desligado. `smoke_priority.py` colocou um cubo
atrás do outro, inverteu suas prioridades e verificou a mudança da cor final
nos passes opaco, Blend e em uma mistura dos dois. Também conferiu que
prioridades iguais conservam o teste de profundidade. `smoke_editor.py`
confirmou a persistência dos controles ao salvar e reabrir. `smoke_post.py`
comparou o render
sem efeito, com Outline, com efeito desligado, com dois efeitos e com ordem
invertida; também salvou e reabriu a pilha no World. O F12 foi verificado;
o viewport com pós-processamento ainda precisa de teste na interface. Estes
testes confirmam o caminho básico, não FPS.
`smoke_material_flags.py` confirmou o verso oculto por padrão, o verso visível
com `Double Sided`, a cor sem iluminação com `Unlit` e a persistência das
opções ao salvar e reabrir.
`smoke_shared_vbo.py` renderizou uma malha com dois materiais, um simples e
outro com textura, usando batches com o mesmo Vertex Buffer.
`smoke_shadows.py` comparou Sun, Spot e Point com sombras ligadas e desligadas.
No Sun, também verificou Alpha 0, Alpha 0,5 e textura RGBA em Cutout e Blend; na Point,
verificou Alpha 0,5. Conferiu ainda `Strength` zero e render com Outline ativo.
`smoke_utility_nodes.py` verificou Value, RGB e cor de textura ligados a Alpha,
Gradient Texture com duas escalas, Color Ramp e seu Alpha, os 19 modos de Mix
Color, Separate/Combine Color, Math, Map Range e Invert Color. Também salvou e
reabriu um `.blend` com esses nós. `smoke_shadows.py` confirmou uma sombra
parcial gerada por Gradient Texture ligado a Alpha.
`smoke_shader_to_rgb.py` confirmou que Shader to RGB reproduz a cor iluminada,
que Color Ramp reage à Sun, que Color direto funciona sem Surface e sem luz,
e que o Alpha do Material Output funciona como slider ou ligado à saída Alpha
do Toon Surface. `smoke_shadows.py` confirmou a sombra do caminho Shader to RGB
com Alpha separado. Os novos nós e links persistiram após salvar e reabrir.
`smoke_material_slots.py` criou dois materiais Toon, acrescentou o segundo
slot e usou `Assign` no modo Edit para aplicar o segundo material a uma face.
`smoke_shadows.py` verificou que desligar `Cast Shadow` no objeto remove sua
sombra e desligar `Receive Shadow` no chão impede a sombra recebida.
`smoke_material_flags.py` confirmou os valores padrão e a persistência dos
dois checkboxes. `smoke_output_properties.py` confirmou a visibilidade dos
painéis nativos e gerou uma imagem de 48 × 32 pixels a partir de uma resolução
de 96 × 64 em 50%.
`smoke_outline_materials.py` comparou dois objetos com materiais diferentes:
com cada filtro ativo, só o objeto selecionado ganhou contorno. Confirmou
também dois filtros em cascata, conta-gotas por ray cast e persistência no
`.blend`. `smoke_outline_material_faces.py` conferiu a borda entre faces de
materiais diferentes no mesmo objeto. `smoke_post.py` confirmou o resultado
do Outline sem filtro.

Para testar na interface:

1. Use o ZIP de instalação `toon_render-0.47.7.zip` na raiz do projeto. Desative
   a versão anterior antes de instalar a nova versão.
2. Em Blender 4.5.9 ou 5.3, abra `Edit > Preferences > Add-ons > Install from Disk` e
   selecione o ZIP. Ative `Toon Render`.
3. Selecione `Toon Render` em `Render Properties > Render Engine`.
4. No viewport, mude o shading para `Rendered` ou `Material Preview`;
   depois pressione F12 para o render final.
5. Para abrir o editor em uma área, use F3 e `Open Toon Shader Editor`. Clique
   em `New` no seletor central de material; o editor deve mostrar `Toon Surface`
   e `Material Output`.
   O grafo inicial deve mostrar somente `Toon Surface` e `Material Output`.
6. Para testar textura, use `Shift+A > Image Texture`, escolha uma imagem e
   conecte sua saída `Color` à entrada `Color` de `Toon Surface`. Para usar a
   transparência da imagem, conecte também `Alpha` a `Alpha`.
7. Abaixo de `Alpha` no `Toon Surface`, escolha `Blend` ou `Cutout`. Cada modo
   mostra seu `Threshold`; `Transparency Overlap` aparece em Blend. Digite um
   valor em `Render Priority` para que esse material vença a profundidade de
   faces próximas. Se a separação for maior que a prioridade, a face
   fisicamente mais próxima continua na frente.
8. Na aba `World`, abra `Toon Render Post Processing` e clique em `+ Add`.
   Ajuste `Outline / Lineart` e confira no viewport em `Rendered` e no F12.
   Para contornar apenas materiais escolhidos, marque `Limit to Materials`;
   use `+` e o seletor de material, ou clique no conta-gotas e depois em uma
   face na 3D View. Pressione Esc para cancelar o conta-gotas.
9. Na aba `Material Properties`, abra `Toon Render` e ajuste `Double Sided`
   `Unlit`, `Cast Shadow` e `Receive Shadow` para o material ativo.
   Acima desse painel, use a lista de slots para adicionar outro material.
   Entre no modo Edit, selecione faces, escolha o slot e clique em `Assign`.
10. Selecione uma luz Sun, Point ou Spot. Em `Light Properties > Toon Render
     Shadows`, marque `Shadows`. No Sun, deixe `Cascades` em `Three` para
     concentrar detalhe perto da câmera; em `Single`, ajuste `Area Size` para
     cobrir os objetos. Aumente `Resolution` para mais detalhe e `Bias` se
     houver artefatos de autossombreamento.
11. Em `Output Properties`, ajuste `Format`, `Frame Range` e `Output` para a
    resolução, os quadros e o formato de arquivo desejados.
12. Em `Render Properties > Toon Render > Viewport Preview`, ajuste `Resolution`
    para reduzir os pixels calculados no viewport. `Shadows` e `Post Processing`
    podem ser desligados somente na prévia. Com uma câmera panorâmica ativa,
    `Panorama Face Quality` também controla a resolução das faces do cubo.
    Esses ajustes não alteram a resolução ou os efeitos do render F12.

O próximo teste visual é confirmar os dois materiais no viewport. FPS e tempo
por estágio devem ser medidos antes de definir metas de desempenho.

### Seleção na câmera panorâmica

Na visão da câmera panorâmica, o clique seleciona a malha na posição exibida
pela projeção e a seleção aparece como um contorno projetado. Os bones de
armatures visíveis também são projetados em Object Mode; clicar sobre um
bone seleciona a armature. Em Pose Mode,
o bone ativo selecionado fica amarelo, os demais selecionados ficam laranja
e os não selecionados ficam azuis. O clique usa o botão esquerdo no keymap
padrão ou o direito quando o keymap Blender 2.7x está ativo. Shift adiciona
ou remove um elemento da seleção. Essa seleção panorâmica funciona no
viewport em Rendered e Material Preview; em Solid, a seleção padrão do
Blender é usada.
Durante a prévia panorâmica, os extras e o cursor 3D nativos são ocultados
temporariamente para não sobrepor seus desenhos em perspectiva à projeção
panorâmica. As opções originais voltam ao sair da visão panorâmica.
No Blender 4.x, o addon oculta temporariamente todos os overlays e gizmos
nativos durante essa prévia, pois essa versão ainda desenha a origem de
objetos selecionados em perspectiva. A seleção e os bones projetados pelo
Toon Render continuam disponíveis.
No Blender 4.x, o estado dos overlays e gizmos é alterado somente quando
necessário; gravar o mesmo valor a cada frame causa redesenho contínuo e
piscar dos elementos do viewport.
