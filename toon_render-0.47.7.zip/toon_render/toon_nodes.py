"""Dedicated material node tree for Toon Render."""

import bpy
from bl_ui import node_add_menu, space_node

_original_header_draw = None
_time_tree_ids = set()
_material_clipboard = None
_tree_revisions = {}


def tree_revision(tree):
    return _tree_revisions.get(tree.as_pointer(), 0) if tree else 0


def invalidate_tree(tree):
    pointer = tree.as_pointer()
    _tree_revisions[pointer] = _tree_revisions.get(pointer, 0) + 1


def refresh_time_nodes():
    groups = getattr(bpy.data, 'node_groups', None)
    if groups is None:
        return
    _time_tree_ids.clear()
    _time_tree_ids.update(
        tree.as_pointer() for tree in groups
        if tree.bl_idname == 'ToonRenderNodeTree'
        and any(node.bl_idname == 'ToonTimeNode' and node.source == 'REALTIME'
                for node in tree.nodes))


def _update_time_source(node, _context):
    tree = node.id_data
    if any(item.bl_idname == 'ToonTimeNode' and item.source == 'REALTIME'
           for item in tree.nodes):
        _time_tree_ids.add(tree.as_pointer())
    else:
        _time_tree_ids.discard(tree.as_pointer())
    _tag_viewports(node)


def _time_redraw_timer():
    if not _time_tree_ids:
        return 0.25
    manager = getattr(bpy.context, 'window_manager', None)
    if manager:
        for window in manager.windows:
            if window.scene and window.scene.render.engine == 'TOON_RENDER':
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D':
                        area.tag_redraw()
    return 1.0 / 30.0


def _tag_viewports(_self=None, _context=None):
    tree = _self if getattr(_self, 'bl_idname', None) == 'ToonRenderNodeTree' else getattr(_self, 'id_data', None)
    if getattr(tree, 'bl_idname', None) == 'ToonRenderNodeTree':
        invalidate_tree(tree)
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def _seed_tree(tree):
    if len(tree.nodes) != 0:
        return
    surface = tree.nodes.new('ToonSurfaceNode')
    surface.location = (-240, 0)
    output = tree.nodes.new('ToonMaterialOutputNode')
    output.location = (80, 0)
    tree.links.new(surface.outputs['Shader'], output.inputs['Surface'])


def _assign_tree(obj, tree):
    material = bpy.data.materials.new('Material')
    material.toon_tree = tree
    _seed_tree(tree)
    if obj.material_slots:
        obj.material_slots[obj.active_material_index].material = material
    else:
        obj.data.materials.append(material)
    return material


class ToonNodeTree(bpy.types.NodeTree):
    bl_idname = 'ToonRenderNodeTree'
    bl_label = 'Toon Shader Editor'
    bl_icon = 'MATERIAL'

    def update(self):
        if any(node.bl_idname == 'ToonTimeNode' and node.source == 'REALTIME'
               for node in self.nodes):
            _time_tree_ids.add(self.as_pointer())
        else:
            _time_tree_ids.discard(self.as_pointer())
        _tag_viewports(self)

    @classmethod
    def poll(cls, context):
        return context.scene is not None and context.scene.render.engine == 'TOON_RENDER'

    @classmethod
    def get_from_context(cls, context):
        obj = context.active_object
        material = obj.active_material if obj else None
        if material and material.toon_tree:
            return material.toon_tree, obj, material
        return None, None, None


class ToonColorSocket(bpy.types.NodeSocket):
    bl_idname = 'ToonColorSocket'
    bl_label = 'Color'

    default_value: bpy.props.FloatVectorProperty(
        name='Color', subtype='COLOR', size=4,
        min=0.0, max=1.0, default=(0.8, 0.8, 0.8, 1.0), update=_tag_viewports)

    def draw(self, context, layout, node, text):
        if self.is_output and node.bl_idname == 'ToonRGBNode':
            layout.prop(self, 'default_value', text=text)
        elif self.is_output or self.is_linked:
            layout.label(text=text)
        else:
            layout.prop(self, 'default_value', text=text)

    @classmethod
    def draw_color_simple(cls):
        return (0.85, 0.52, 0.18, 1.0)


class ToonShaderSocket(bpy.types.NodeSocket):
    bl_idname = 'ToonShaderSocket'
    bl_label = 'Shader'

    def draw(self, context, layout, node, text):
        layout.label(text=text)

    @classmethod
    def draw_color_simple(cls):
        return (0.33, 0.67, 0.39, 1.0)


class ToonAlphaSocket(bpy.types.NodeSocket):
    bl_idname = 'ToonAlphaSocket'
    bl_label = 'Alpha'

    default_value: bpy.props.FloatProperty(
        name='Alpha', subtype='FACTOR', min=0.0, max=1.0, default=1.0,
        update=_tag_viewports)

    def draw(self, context, layout, node, text):
        column = layout.column(align=True)
        if self.is_output or self.is_linked:
            column.label(text=text)
        else:
            column.prop(self, 'default_value', text=text, slider=True)
        if node.bl_idname == 'ToonSurfaceNode' and not self.is_output:
            column.prop(node, 'transparency_method', text='Transparency')
            if node.transparency_method == 'CUTOUT':
                column.prop(node, 'cutout_threshold', text='Threshold', slider=True)
            else:
                column.prop(node, 'blend_threshold', text='Threshold', slider=True)
                column.prop(node, 'transparency_overlap')
            column.prop(node, 'render_priority')

    @classmethod
    def draw_color_simple(cls):
        return (0.62, 0.62, 0.62, 1.0)


class ToonVectorSocket(bpy.types.NodeSocket):
    bl_idname = 'ToonVectorSocket'
    bl_label = 'Vector'

    default_value: bpy.props.FloatVectorProperty(
        name='Vector', size=2, default=(0.0, 0.0), update=_tag_viewports)

    def draw(self, context, layout, node, text):
        if node.bl_idname == 'ToonGradientNode' and not self.is_linked:
            layout.label(text='Vector (UV default)')
        elif self.is_output or self.is_linked:
            layout.label(text=text)
        else:
            layout.prop(self, 'default_value', text=text)

    @classmethod
    def draw_color_simple(cls):
        return (0.38, 0.38, 0.8, 1.0)


class ToonVector3Socket(bpy.types.NodeSocket):
    bl_idname = 'ToonVector3Socket'
    bl_label = 'Vector'

    default_value: bpy.props.FloatVectorProperty(
        name='Vector', size=3, default=(0.0, 0.0, 0.0), update=_tag_viewports)

    def draw(self, context, layout, node, text):
        if (not self.is_output and not self.is_linked
                and node.bl_idname in {'ToonImageTextureNode', 'ToonFlipBookNode'}):
            layout.label(text='Vector (UV default)')
        elif not self.is_output and not self.is_linked and node.bl_idname == 'ToonMappingNode':
            layout.label(text='Vector (automatic)')
        elif self.is_output or self.is_linked:
            layout.label(text=text)
        else:
            layout.prop(self, 'default_value', text=text)

    @classmethod
    def draw_color_simple(cls):
        return (0.38, 0.38, 0.8, 1.0)


class ToonNormalSocket(bpy.types.NodeSocket):
    bl_idname = 'ToonNormalSocket'
    bl_label = 'Normal'

    def draw(self, context, layout, node, text):
        layout.label(text=(text if self.is_output or self.is_linked
                           else 'Normal (Geometry)'))

    @classmethod
    def draw_color_simple(cls):
        return (0.45, 0.52, 0.9, 1.0)


class ToonFloatSocket(bpy.types.NodeSocket):
    bl_idname = 'ToonFloatSocket'
    bl_label = 'Value'

    default_value: bpy.props.FloatProperty(
        name='Value', default=0.0, soft_min=-10.0, soft_max=10.0,
        update=_tag_viewports)

    def draw(self, context, layout, node, text):
        if self.is_output and node.bl_idname == 'ToonValueNode':
            layout.prop(self, 'default_value', text=text)
        elif self.is_output or self.is_linked:
            layout.label(text=text)
        else:
            layout.prop(self, 'default_value', text=text)

    @classmethod
    def draw_color_simple(cls):
        return (0.62, 0.62, 0.62, 1.0)


class ToonFactorSocket(bpy.types.NodeSocket):
    bl_idname = 'ToonFactorSocket'
    bl_label = 'Factor'

    default_value: bpy.props.FloatProperty(
        name='Factor', subtype='FACTOR', min=0.0, max=1.0,
        default=0.0, update=_tag_viewports)

    def draw(self, context, layout, node, text):
        if self.is_output or self.is_linked:
            layout.label(text=text)
        else:
            layout.prop(self, 'default_value', text=text, slider=True)

    @classmethod
    def draw_color_simple(cls):
        return (0.62, 0.62, 0.62, 1.0)


class _ToonNode:
    @classmethod
    def poll(cls, node_tree):
        return node_tree.bl_idname == ToonNodeTree.bl_idname


class ToonSurfaceNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonSurfaceNode'
    bl_label = 'Toon Surface'
    bl_icon = 'MATERIAL'

    transparency_method: bpy.props.EnumProperty(
        name='Transparency',
        items=(('BLEND', 'Blend', 'Blend partially transparent pixels'),
               ('CUTOUT', 'Cutout', 'Discard pixels below the alpha threshold')),
        default='BLEND', update=_tag_viewports)
    cutout_threshold: bpy.props.FloatProperty(
        name='Threshold', subtype='FACTOR', min=0.0, max=1.0,
        default=0.5, update=_tag_viewports)
    blend_threshold: bpy.props.FloatProperty(
        name='Threshold', subtype='FACTOR', min=0.0, max=1.0,
        default=0.001,
        description='Discard nearly transparent pixels before blending or writing depth',
        update=_tag_viewports)
    transparency_overlap: bpy.props.BoolProperty(
        name='Transparency Overlap',
        description='Blend all transparent surface layers; disable to keep only the frontmost layer',
        default=True, update=_tag_viewports)
    render_priority: bpy.props.FloatProperty(
        name='Render Priority',
        description='Depth offset in Blender units; a higher value can place this material ahead of another face only when their camera-depth separation is smaller than the priority difference',
        default=0.0, soft_min=-100.0, soft_max=100.0,
        update=_tag_viewports)

    def init(self, context):
        self.inputs.new(ToonColorSocket.bl_idname, 'Color')
        self.inputs.new(ToonColorSocket.bl_idname, 'Emissive').default_value = (0.0, 0.0, 0.0, 1.0)
        self.inputs.new(ToonFactorSocket.bl_idname, 'Roughness').default_value = 0.5
        self.inputs.new(ToonFactorSocket.bl_idname, 'Metalness').default_value = 0.0
        self.inputs.new(ToonNormalSocket.bl_idname, 'Normal')
        self.inputs.new(ToonAlphaSocket.bl_idname, 'Alpha')
        self.outputs.new(ToonShaderSocket.bl_idname, 'Shader')
        self.outputs.new(ToonAlphaSocket.bl_idname, 'Alpha')


class ToonNormalMapNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonNormalMapNode'
    bl_label = 'Normal Map'
    bl_icon = 'NORMALS_FACE'

    space: bpy.props.EnumProperty(
        name='Space', items=(
            ('TANGENT', 'Tangent Space', 'Use the mesh UV tangent basis'),
            ('OBJECT', 'Object Space', 'Normal directions follow object rotation'),
            ('WORLD', 'World Space', 'Normal directions stay fixed in world space'),
            ('BLENDER_OBJECT', 'Blender Object Space', 'Decode legacy Blender object-space maps'),
            ('BLENDER_WORLD', 'Blender World Space', 'Decode legacy Blender world-space maps')),
        default='TANGENT', update=_tag_viewports)
    convention: bpy.props.EnumProperty(
        name='Convention', items=(
            ('OPENGL', 'OpenGL', 'Green channel points up'),
            ('DIRECTX', 'DirectX', 'Invert the green channel')),
        default='OPENGL', update=_tag_viewports)
    invert_y: bpy.props.BoolProperty(
        name='Invert Y', default=False,
        description='Flip the green/Y component of the normal map independently of the convention',
        update=_tag_viewports)
    uv_map: bpy.props.StringProperty(
        name='UV Map', description='Tangent-space UV map; empty uses the active UV map',
        update=_tag_viewports)

    def init(self, context):
        self.inputs.new(ToonFloatSocket.bl_idname, 'Strength').default_value = 1.0
        self.inputs.new(ToonColorSocket.bl_idname, 'Color').default_value = (0.5, 0.5, 1.0, 1.0)
        self.outputs.new(ToonNormalSocket.bl_idname, 'Normal')

    def draw_buttons(self, context, layout):
        layout.prop(self, 'space', text='')
        layout.prop(self, 'convention', text='')
        layout.prop(self, 'invert_y')
        if self.space == 'TANGENT':
            obj = context.active_object
            if obj and obj.type == 'MESH':
                layout.prop_search(self, 'uv_map', obj.data, 'uv_layers', text='')
            else:
                layout.prop(self, 'uv_map', text='UV Map')


class ToonAdditiveNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonAdditiveNode'
    bl_label = 'Additive'
    bl_icon = 'MATERIAL'

    intensity: bpy.props.FloatProperty(
        name='Intensity', description='HDR brightness added to the scene',
        default=1.0, min=0.0, soft_max=10.0, update=_tag_viewports)

    def init(self, context):
        self.inputs.new(ToonColorSocket.bl_idname, 'Color').default_value = (1.0, 1.0, 1.0, 1.0)
        self.outputs.new(ToonShaderSocket.bl_idname, 'Shader')

    def draw_buttons(self, context, layout):
        layout.prop(self, 'intensity')


class ToonShaderToRGBNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonShaderToRGBNode'
    bl_label = 'Shader to RGB'
    bl_icon = 'MATERIAL'

    def init(self, context):
        self.inputs.new(ToonShaderSocket.bl_idname, 'Shader')
        self.outputs.new(ToonColorSocket.bl_idname, 'Color')


class ToonShadowMaskNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonShadowMaskNode'
    bl_label = 'Shadow Mask'
    bl_icon = 'LIGHT'

    def init(self, context):
        self.outputs.new(ToonFloatSocket.bl_idname, 'Fac')


class ToonProximityMaterial(bpy.types.PropertyGroup):
    material: bpy.props.PointerProperty(
        name='Material', type=bpy.types.Material, update=_tag_viewports)


class TOON_UL_proximity_materials(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname, index):
        layout.prop(item, 'material', text='', icon='MATERIAL')


def _proximity_node(tree_name, node_name):
    tree = bpy.data.node_groups.get(tree_name)
    node = tree.nodes.get(node_name) if tree else None
    return node if node and node.bl_idname == 'ToonProximityMaskNode' else None


class TOON_OT_add_proximity_material(bpy.types.Operator):
    bl_idname = 'toon_render.add_proximity_material'
    bl_label = 'Add Proximity Material'
    bl_options = {'REGISTER', 'UNDO'}

    tree_name: bpy.props.StringProperty()
    node_name: bpy.props.StringProperty()

    def execute(self, context):
        node = _proximity_node(self.tree_name, self.node_name)
        if node is None:
            return {'CANCELLED'}
        node.materials.add()
        node.material_index = len(node.materials) - 1
        _tag_viewports()
        return {'FINISHED'}


class TOON_OT_remove_proximity_material(bpy.types.Operator):
    bl_idname = 'toon_render.remove_proximity_material'
    bl_label = 'Remove Proximity Material'
    bl_options = {'REGISTER', 'UNDO'}

    tree_name: bpy.props.StringProperty()
    node_name: bpy.props.StringProperty()

    def execute(self, context):
        node = _proximity_node(self.tree_name, self.node_name)
        if node is None or not node.materials:
            return {'CANCELLED'}
        node.materials.remove(min(node.material_index, len(node.materials) - 1))
        node.material_index = max(0, min(node.material_index, len(node.materials) - 1))
        _tag_viewports()
        return {'FINISHED'}


class ToonProximityMaskNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonProximityMaskNode'
    bl_label = 'Proximity Mask'
    bl_icon = 'MOD_VERTEX_WEIGHT'

    distance: bpy.props.FloatProperty(
        name='Distance', min=0.001, soft_max=10.0, default=0.5,
        description='Maximum projection distance from source material to this surface',
        update=_tag_viewports)
    projection_direction: bpy.props.FloatVectorProperty(
        name='Direction', size=3, default=(0.0, 0.0, -1.0),
        description='World-space direction in which selected geometry projects its mask',
        update=_tag_viewports)
    projection_resolution: bpy.props.EnumProperty(
        name='Resolution', items=(('256', '256', ''), ('512', '512', ''),
                                  ('1024', '1024', '')),
        default='512', update=_tag_viewports)
    projection_bias: bpy.props.FloatProperty(
        name='Bias', min=0.0, max=0.1, default=0.001, precision=4,
        description='Minimum separation along the projection direction',
        update=_tag_viewports)
    alpha_threshold: bpy.props.FloatProperty(
        name='Alpha Threshold', subtype='FACTOR', min=0.0, max=1.0,
        default=0.01, description='Ignore nearby pixels below this opacity',
        update=_tag_viewports)
    filter_materials: bpy.props.BoolProperty(
        name='Filter by Material', default=False, update=_tag_viewports,
        description='Detect only faces assigned to the listed materials')
    materials: bpy.props.CollectionProperty(type=ToonProximityMaterial)
    material_index: bpy.props.IntProperty(default=0)

    def init(self, context):
        self.outputs.new(ToonFloatSocket.bl_idname, 'Fac')

    def draw_buttons(self, context, layout):
        layout.prop(self, 'projection_direction')
        layout.prop(self, 'distance')
        layout.prop(self, 'projection_resolution')
        layout.prop(self, 'projection_bias')
        layout.prop(self, 'alpha_threshold', slider=True)
        layout.prop(self, 'filter_materials')
        if self.filter_materials:
            row = layout.row()
            row.template_list('TOON_UL_proximity_materials', '', self,
                              'materials', self, 'material_index', rows=2)
            buttons = row.column(align=True)
            add = buttons.operator('toon_render.add_proximity_material', text='', icon='ADD')
            add.tree_name = self.id_data.name
            add.node_name = self.name
            remove = buttons.operator('toon_render.remove_proximity_material',
                                      text='', icon='REMOVE')
            remove.tree_name = self.id_data.name
            remove.node_name = self.name


class ToonZDepthNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonZDepthNode'
    bl_label = 'Z Depth'
    bl_icon = 'MOD_VERTEX_WEIGHT'

    distance: bpy.props.FloatProperty(
        name='Distance', min=0.001, soft_max=10.0, default=0.5,
        description='Maximum camera-depth separation between nearby surfaces',
        update=_tag_viewports)
    expand: bpy.props.IntProperty(
        name='Expand', min=0, max=8, default=2,
        description='Expand the contact mask in screen pixels',
        update=_tag_viewports)
    alpha_threshold: bpy.props.FloatProperty(
        name='Alpha Threshold', subtype='FACTOR', min=0.0, max=1.0,
        default=0.01, description='Ignore nearby pixels below this opacity',
        update=_tag_viewports)

    def init(self, context):
        self.outputs.new(ToonFloatSocket.bl_idname, 'Fac')

    def draw_buttons(self, context, layout):
        layout.prop(self, 'distance')
        layout.prop(self, 'expand')
        layout.prop(self, 'alpha_threshold', slider=True)


class ToonFresnelNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonFresnelNode'
    bl_label = 'Fresnel'
    bl_icon = 'SHADING_RENDERED'

    def init(self, context):
        self.inputs.new(ToonFloatSocket.bl_idname, 'Power').default_value = 2.0
        self.outputs.new(ToonFloatSocket.bl_idname, 'Fac')


class ToonImageTextureNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonImageTextureNode'
    bl_label = 'Image Texture'
    bl_icon = 'IMAGE_DATA'

    image: bpy.props.PointerProperty(name='Image', type=bpy.types.Image,
                                     update=_tag_viewports)
    extension: bpy.props.EnumProperty(
        name='Extension',
        items=(('TILE', 'Tile', 'Repeat the image outside the UV range'),
               ('CLIP', 'Clip', 'Return transparent black outside the UV range')),
        default='TILE', update=_tag_viewports)

    def init(self, context):
        self.inputs.new(ToonVector3Socket.bl_idname, 'Vector')
        self.outputs.new(ToonColorSocket.bl_idname, 'Color')
        self.outputs.new(ToonAlphaSocket.bl_idname, 'Alpha')

    def draw_buttons(self, context, layout):
        layout.template_ID(self, 'image', open='image.open')
        if self.image:
            layout.prop(self.image.colorspace_settings, 'name', text='Color Space')
        layout.prop(self, 'extension', text='')


class ToonFlipBookNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonFlipBookNode'
    bl_label = 'Flip Book'
    bl_icon = 'IMAGE_DATA'

    image: bpy.props.PointerProperty(name='Sprite Sheet', type=bpy.types.Image,
                                     update=_tag_viewports)
    columns: bpy.props.IntProperty(name='Horizontal Frames', min=1, max=256,
                                   default=4, update=_tag_viewports)
    rows: bpy.props.IntProperty(name='Vertical Frames', min=1, max=256,
                                default=4, update=_tag_viewports)
    start_frame: bpy.props.IntProperty(name='Start Frame', min=0, default=0,
                                       update=_tag_viewports)
    end_frame: bpy.props.IntProperty(
        name='End Frame', min=-1, default=-1,
        description='Inclusive last frame; -1 uses the last cell of the sheet',
        update=_tag_viewports)
    def init(self, context):
        self.inputs.new(ToonVector3Socket.bl_idname, 'Vector')
        self.inputs.new(ToonFloatSocket.bl_idname, 'Frame')
        self.outputs.new(ToonColorSocket.bl_idname, 'Color')
        self.outputs.new(ToonAlphaSocket.bl_idname, 'Alpha')

    def draw_buttons(self, context, layout):
        layout.template_ID(self, 'image', open='image.open')
        row = layout.row(align=True)
        row.prop(self, 'columns')
        row.prop(self, 'rows')
        row = layout.row(align=True)
        row.prop(self, 'start_frame')
        row.prop(self, 'end_frame')


class ToonTimeNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonTimeNode'
    bl_label = 'Time'
    bl_icon = 'TIME'

    source: bpy.props.EnumProperty(
        name='Source', items=(
            ('REALTIME', 'Real Time', 'Seconds elapsed while Blender is running'),
            ('SCENE', 'Scene Time', 'Seconds from the scene frame and frame rate')),
        default='REALTIME', update=_update_time_source)

    def init(self, context):
        self.outputs.new(ToonFloatSocket.bl_idname, 'Seconds')
        _time_tree_ids.add(self.id_data.as_pointer())

    def draw_buttons(self, context, layout):
        layout.prop(self, 'source', text='')


def ensure_image_vector_inputs():
    groups = getattr(bpy.data, 'node_groups', None)
    if groups is None:
        return
    for tree in groups:
        if tree.bl_idname != ToonNodeTree.bl_idname:
            continue
        for node in tree.nodes:
            if node.bl_idname == ToonImageTextureNode.bl_idname and 'Vector' not in node.inputs:
                node.inputs.new(ToonVector3Socket.bl_idname, 'Vector')


def ensure_surface_pbr_inputs():
    groups = getattr(bpy.data, 'node_groups', None)
    if groups is None:
        return
    for tree in groups:
        if tree.bl_idname != ToonNodeTree.bl_idname:
            continue
        for node in tree.nodes:
            if node.bl_idname != ToonSurfaceNode.bl_idname:
                continue
            if 'Roughness' not in node.inputs:
                node.inputs.new(ToonFactorSocket.bl_idname, 'Roughness').default_value = 0.5
            if 'Metalness' not in node.inputs:
                node.inputs.new(ToonFactorSocket.bl_idname, 'Metalness').default_value = 0.0
            if 'Normal' not in node.inputs:
                node.inputs.new(ToonNormalSocket.bl_idname, 'Normal')


class ToonValueNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonValueNode'
    bl_label = 'Value'

    def init(self, context):
        self.outputs.new(ToonFloatSocket.bl_idname, 'Value')


class ToonRGBNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonRGBNode'
    bl_label = 'RGB'

    def init(self, context):
        self.outputs.new(ToonColorSocket.bl_idname, 'Color')


class ToonUVNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonUVNode'
    bl_label = 'UV Map'

    uv_map: bpy.props.StringProperty(
        name='UV Map', description='UV map to use; empty uses the active UV map',
        update=_tag_viewports)

    def init(self, context):
        self.outputs.new(ToonVectorSocket.bl_idname, 'UV')

    def draw_buttons(self, context, layout):
        obj = context.active_object
        if obj and obj.type == 'MESH':
            layout.prop_search(self, 'uv_map', obj.data, 'uv_layers', text='')
        else:
            layout.prop(self, 'uv_map', text='UV Map')


class ToonVertexColorNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonVertexColorNode'
    bl_label = 'Vertex Color'
    bl_icon = 'GROUP_VCOL'

    attribute_name: bpy.props.StringProperty(name='Color Attribute', update=_tag_viewports)

    def init(self, context):
        self.outputs.new(ToonColorSocket.bl_idname, 'Color')
        self.outputs.new(ToonAlphaSocket.bl_idname, 'Alpha')

    def draw_buttons(self, context, layout):
        obj = context.active_object
        if obj and obj.type == 'MESH':
            layout.prop_search(self, 'attribute_name', obj.data, 'color_attributes', text='')
        else:
            layout.prop(self, 'attribute_name', text='Color Attribute')


class ToonObjectColorNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonObjectColorNode'
    bl_label = 'Object Color'
    bl_icon = 'OBJECT_DATA'

    def init(self, context):
        self.outputs.new(ToonColorSocket.bl_idname, 'Color')
        self.outputs.new(ToonAlphaSocket.bl_idname, 'Alpha')


class ToonMappingNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonMappingNode'
    bl_label = 'Mapping'
    bl_icon = 'NODE_TEXTURE'

    mapping_type: bpy.props.EnumProperty(
        name='Type', items=(
            ('UV', 'UV', 'Use the chosen UV map, or the active one if empty'),
            ('OBJECT', 'Object', 'Use object space coordinates'),
            ('OBJECT_TRANSFORM', 'Object Transform',
             'Use the transform of an object or armature bone as texture coordinates'),
            ('WORLD', 'World', 'Use world space coordinates'),
            ('TRIPLANAR', 'Triplanar', 'Blend textures projected from three object axes'),
            ('MATCAP', 'MatCap', 'Map view space normals to texture coordinates')),
        default='UV', update=_tag_viewports)
    uv_map: bpy.props.StringProperty(
        name='UV Map', description='UV map to use in UV mode; empty uses the active UV map',
        update=_tag_viewports)
    mapping_object: bpy.props.PointerProperty(
        name='Object', type=bpy.types.Object,
        description='Object controlling the texture projection; empty uses the shaded object',
        update=_tag_viewports)
    mapping_bone: bpy.props.StringProperty(
        name='Bone', description='Bone controlling the texture projection',
        update=_tag_viewports)
    projection_axis: bpy.props.EnumProperty(
        name='Projection Plane',
        items=(('XY', 'XY', 'Project onto local XY'),
               ('XZ', 'XZ', 'Project onto local XZ'),
               ('YZ', 'YZ', 'Project onto local YZ')),
        default='XY', update=_tag_viewports)
    mapping_location: bpy.props.FloatVectorProperty(
        name='Location', size=3, default=(0.0, 0.0, 0.0), update=_tag_viewports)
    mapping_rotation: bpy.props.FloatVectorProperty(
        name='Rotation', size=3, subtype='EULER', default=(0.0, 0.0, 0.0),
        update=_tag_viewports)
    mapping_scale: bpy.props.FloatVectorProperty(
        name='Scale', size=3, default=(1.0, 1.0, 1.0), update=_tag_viewports)
    blend: bpy.props.FloatProperty(
        name='Blend', min=0.1, max=16.0, default=4.0,
        description='Higher values make triplanar transitions sharper', update=_tag_viewports)

    def init(self, context):
        self.inputs.new(ToonVector3Socket.bl_idname, 'Vector')
        self.outputs.new(ToonVector3Socket.bl_idname, 'Vector')

    def draw_buttons(self, context, layout):
        layout.prop(self, 'mapping_type', text='')
        if self.mapping_type == 'UV':
            obj = context.active_object
            row = layout.row()
            row.enabled = not self.inputs['Vector'].is_linked
            if obj and obj.type == 'MESH':
                row.prop_search(self, 'uv_map', obj.data, 'uv_layers', text='')
            else:
                row.prop(self, 'uv_map', text='UV Map')
        elif self.mapping_type == 'OBJECT_TRANSFORM':
            controls = layout.column()
            controls.enabled = not self.inputs['Vector'].is_linked
            controls.prop(self, 'mapping_object', text='Object')
            if self.mapping_object and self.mapping_object.type == 'ARMATURE':
                controls.prop_search(self, 'mapping_bone', self.mapping_object.data,
                                     'bones', text='Bone')
            controls.prop(self, 'projection_axis', text='Plane')
        layout.prop(self, 'mapping_location')
        layout.prop(self, 'mapping_rotation')
        layout.prop(self, 'mapping_scale')
        if self.mapping_type == 'TRIPLANAR':
            layout.prop(self, 'blend')


class ToonGradientNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonGradientNode'
    bl_label = 'Gradient Texture'

    gradient_type: bpy.props.EnumProperty(
        name='Type', items=(('LINEAR', 'Linear', ''),
                            ('DIAGONAL', 'Diagonal', ''),
                            ('RADIAL', 'Radial', ''),
                            ('SPHERICAL', 'Spherical', '')),
        default='LINEAR', update=_tag_viewports)

    def init(self, context):
        self.inputs.new(ToonVectorSocket.bl_idname, 'Vector')
        self.inputs.new(ToonFloatSocket.bl_idname, 'Scale').default_value = 1.0
        self.outputs.new(ToonFloatSocket.bl_idname, 'Fac')

    def draw_buttons(self, context, layout):
        layout.prop(self, 'gradient_type', text='')


class ToonSeparateColorNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonSeparateColorNode'
    bl_label = 'Separate Color'

    def init(self, context):
        self.inputs.new(ToonColorSocket.bl_idname, 'Color')
        for name in ('R', 'G', 'B', 'Alpha', 'Luminance'):
            self.outputs.new(ToonFloatSocket.bl_idname, name)


class ToonCombineColorNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonCombineColorNode'
    bl_label = 'Combine Color'

    def init(self, context):
        for name in ('R', 'G', 'B', 'Alpha'):
            self.inputs.new(ToonFloatSocket.bl_idname, name)
        self.outputs.new(ToonColorSocket.bl_idname, 'Color')


_BLEND_MODES = (
    ('MIX', 'Mix', ''), ('DARKEN', 'Darken', ''),
    ('MULTIPLY', 'Multiply', ''), ('BURN', 'Color Burn', ''),
    ('LIGHTEN', 'Lighten', ''), ('SCREEN', 'Screen', ''),
    ('DODGE', 'Color Dodge', ''), ('ADD', 'Add', ''),
    ('OVERLAY', 'Overlay', ''), ('SOFT_LIGHT', 'Soft Light', ''),
    ('LINEAR_LIGHT', 'Linear Light', ''), ('DIFFERENCE', 'Difference', ''),
    ('EXCLUSION', 'Exclusion', ''), ('SUBTRACT', 'Subtract', ''),
    ('DIVIDE', 'Divide', ''), ('HUE', 'Hue', ''),
    ('SATURATION', 'Saturation', ''), ('COLOR', 'Color', ''),
    ('VALUE', 'Value', ''),
)


class ToonMixColorNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonMixColorNode'
    bl_label = 'Mix Color'

    blend_type: bpy.props.EnumProperty(
        name='Blend Mode', items=_BLEND_MODES, default='MIX', update=_tag_viewports)
    clamp_result: bpy.props.BoolProperty(
        name='Clamp Result', default=False, update=_tag_viewports)

    def init(self, context):
        self.inputs.new(ToonAlphaSocket.bl_idname, 'Factor').default_value = 0.5
        self.inputs.new(ToonColorSocket.bl_idname, 'A').default_value = (0.5, 0.5, 0.5, 1.0)
        self.inputs.new(ToonColorSocket.bl_idname, 'B').default_value = (0.5, 0.5, 0.5, 1.0)
        self.outputs.new(ToonColorSocket.bl_idname, 'Result')

    def draw_buttons(self, context, layout):
        layout.prop(self, 'blend_type', text='')
        layout.prop(self, 'clamp_result')


class ToonColorRampNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonColorRampNode'
    bl_label = 'Color Ramp'

    ramp_texture: bpy.props.PointerProperty(
        name='Ramp', type=bpy.types.Texture, update=_tag_viewports)

    def init(self, context):
        self.inputs.new(ToonAlphaSocket.bl_idname, 'Fac').default_value = 0.5
        self.outputs.new(ToonColorSocket.bl_idname, 'Color')
        self.outputs.new(ToonFloatSocket.bl_idname, 'Alpha')
        texture = bpy.data.textures.new('Toon Color Ramp', type='BLEND')
        texture.use_color_ramp = True
        texture.use_fake_user = True
        self.ramp_texture = texture

    def draw_buttons(self, context, layout):
        if self.ramp_texture:
            layout.template_color_ramp(self.ramp_texture, 'color_ramp', expand=True)

    def copy(self, node):
        if node.ramp_texture:
            self.ramp_texture = node.ramp_texture.copy()
            self.ramp_texture.use_fake_user = True


class ToonBlurNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonBlurNode'
    bl_label = 'Blur'
    bl_icon = 'MOD_SMOOTH'

    radius: bpy.props.FloatProperty(
        name='Radius', min=0.0, max=128.0, default=4.0,
        description='Blur radius in screen pixels', update=_tag_viewports)
    strength: bpy.props.FloatProperty(
        name='Strength', subtype='FACTOR', min=0.0, max=1.0, default=1.0,
        description='Mix between the original color and blurred color',
        update=_tag_viewports)
    samples: bpy.props.EnumProperty(
        name='Quality', items=(('3', '3 × 3', ''), ('5', '5 × 5', ''),
                               ('7', '7 × 7', '')),
        default='5', update=_tag_viewports)

    def init(self, context):
        self.inputs.new(ToonColorSocket.bl_idname, 'Color')
        self.outputs.new(ToonColorSocket.bl_idname, 'Color')

    def draw_buttons(self, context, layout):
        layout.prop(self, 'radius')
        layout.prop(self, 'strength', slider=True)
        layout.prop(self, 'samples')


class ToonMathNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonMathNode'
    bl_label = 'Math'

    operation: bpy.props.EnumProperty(
        name='Operation', items=tuple((key, label, '') for key, label in (
            ('ADD', 'Add'), ('SUBTRACT', 'Subtract'), ('MULTIPLY', 'Multiply'),
            ('DIVIDE', 'Divide'), ('POWER', 'Power'), ('MINIMUM', 'Minimum'),
            ('MAXIMUM', 'Maximum'), ('ABSOLUTE', 'Absolute'),
            ('LESS_THAN', 'Less Than'), ('GREATER_THAN', 'Greater Than'),
            ('SINE', 'Sine'), ('COSINE', 'Cosine'), ('FLOOR', 'Floor'),
            ('CEIL', 'Ceil'), ('FRACT', 'Fraction'))),
        default='MULTIPLY', update=_tag_viewports)
    clamp_result: bpy.props.BoolProperty(
        name='Clamp', default=False, update=_tag_viewports)

    def init(self, context):
        self.inputs.new(ToonFloatSocket.bl_idname, 'Value')
        self.inputs.new(ToonFloatSocket.bl_idname, 'Value 2').default_value = 1.0
        self.outputs.new(ToonFloatSocket.bl_idname, 'Result')

    def draw_buttons(self, context, layout):
        layout.prop(self, 'operation', text='')
        layout.prop(self, 'clamp_result')


class ToonMapRangeNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonMapRangeNode'
    bl_label = 'Map Range'

    clamp_result: bpy.props.BoolProperty(
        name='Clamp', default=True, update=_tag_viewports)

    def init(self, context):
        self.inputs.new(ToonFloatSocket.bl_idname, 'Value')
        self.inputs.new(ToonFloatSocket.bl_idname, 'From Min')
        self.inputs.new(ToonFloatSocket.bl_idname, 'From Max').default_value = 1.0
        self.inputs.new(ToonFloatSocket.bl_idname, 'To Min')
        self.inputs.new(ToonFloatSocket.bl_idname, 'To Max').default_value = 1.0
        self.outputs.new(ToonFloatSocket.bl_idname, 'Result')

    def draw_buttons(self, context, layout):
        layout.prop(self, 'clamp_result')


class ToonInvertNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonInvertNode'
    bl_label = 'Invert Color'

    def init(self, context):
        self.inputs.new(ToonAlphaSocket.bl_idname, 'Factor').default_value = 1.0
        self.inputs.new(ToonColorSocket.bl_idname, 'Color')
        self.outputs.new(ToonColorSocket.bl_idname, 'Color')


class ToonMaterialOutputNode(_ToonNode, bpy.types.Node):
    bl_idname = 'ToonMaterialOutputNode'
    bl_label = 'Material Output'
    bl_icon = 'OUTPUT'

    def init(self, context):
        self.inputs.new(ToonShaderSocket.bl_idname, 'Surface')
        self.inputs.new(ToonColorSocket.bl_idname, 'Color')
        self.inputs.new(ToonAlphaSocket.bl_idname, 'Alpha')


def create_material(obj):
    tree = bpy.data.node_groups.new('Toon Material', ToonNodeTree.bl_idname)
    return _assign_tree(obj, tree)


class TOON_OT_new_material(bpy.types.Operator):
    bl_idname = 'toon_render.new_material'
    bl_label = 'New Material'
    bl_description = 'Create a material in the Toon Render node editor'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.scene is not None
                and context.scene.render.engine == 'TOON_RENDER'
                and context.active_object is not None
                and hasattr(context.active_object.data, 'materials'))

    def execute(self, context):
        material = create_material(context.active_object)
        if context.area and context.area.type == 'NODE_EDITOR':
            context.space_data.tree_type = ToonNodeTree.bl_idname
            context.space_data.node_tree = material.toon_tree
        return {'FINISHED'}


def _clear_material_clipboard():
    global _material_clipboard
    if _material_clipboard is None:
        return
    material, tree, _name = _material_clipboard
    _material_clipboard = None
    try:
        bpy.data.materials.remove(material)
    except (ReferenceError, RuntimeError, ValueError):
        pass
    if tree is not None:
        try:
            if tree.users == 0:
                bpy.data.node_groups.remove(tree)
        except (ReferenceError, RuntimeError, ValueError):
            pass


def _clipboard_material():
    if _material_clipboard is None:
        return None
    material = _material_clipboard[0]
    try:
        return material if material.as_pointer() else None
    except ReferenceError:
        return None


class TOON_OT_copy_material(bpy.types.Operator):
    bl_idname = 'toon_render.copy_material'
    bl_label = 'Copy Toon Material'
    bl_description = 'Copy the material and its Toon node tree'
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return (context.scene is not None
                and context.scene.render.engine == 'TOON_RENDER'
                and context.active_object is not None
                and context.active_object.active_material is not None)

    def execute(self, context):
        global _material_clipboard
        source = context.active_object.active_material
        snapshot = source.copy()
        tree = source.toon_tree.copy() if source.toon_tree else None
        if tree is not None:
            snapshot.toon_tree = tree
        snapshot.name = '.Toon Clipboard Material'
        _clear_material_clipboard()
        _material_clipboard = (snapshot, tree, source.name)
        return {'FINISHED'}


class TOON_OT_paste_material(bpy.types.Operator):
    bl_idname = 'toon_render.paste_material'
    bl_label = 'Paste Toon Material'
    bl_description = 'Paste a separate copy of the Toon material and node tree'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (context.scene is not None
                and context.scene.render.engine == 'TOON_RENDER'
                and obj is not None and hasattr(obj.data, 'materials')
                and _clipboard_material() is not None)

    def execute(self, context):
        snapshot, tree, original_name = _material_clipboard
        material = snapshot.copy()
        if tree is not None:
            material.toon_tree = tree.copy()
        material.name = original_name
        obj = context.active_object
        if obj.material_slots:
            obj.material_slots[obj.active_material_index].material = material
        else:
            obj.data.materials.append(material)
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if (area.type == 'NODE_EDITOR'
                        and area.spaces.active.tree_type == ToonNodeTree.bl_idname
                        and not area.spaces.active.pin):
                    area.spaces.active.node_tree = material.toon_tree
        _tag_viewports()
        return {'FINISHED'}


class TOON_MT_material_context_menu(bpy.types.Menu):
    bl_idname = 'TOON_MT_material_context_menu'
    bl_label = 'Material Specials'

    def draw(self, context):
        layout = self.layout
        layout.operator(TOON_OT_copy_material.bl_idname,
                        text='Copy Material', icon='COPYDOWN')
        layout.operator('object.material_slot_copy', text='Copy Material to Selected')
        layout.operator(TOON_OT_paste_material.bl_idname,
                        text='Paste Material', icon='PASTEDOWN')
        layout.operator('object.material_slot_remove_unused', text='Remove Unused Slots')
        layout.operator('object.material_slot_remove_all', text='Remove All Materials')


class TOON_PT_node_material_slots(bpy.types.Panel):
    bl_idname = 'TOON_PT_node_material_slots'
    bl_label = 'Slot'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'HEADER'
    bl_ui_units_x = 12

    def draw(self, context):
        obj = context.object
        row = self.layout.row()
        slots = row.column()
        slots.template_list('MATERIAL_UL_matslots', '', obj, 'material_slots',
                            obj, 'active_material_index')
        controls = row.column(align=True)
        controls.operator('object.material_slot_add', icon='ADD', text='')
        controls.operator('object.material_slot_remove', icon='REMOVE', text='')
        controls.separator()
        controls.menu(TOON_MT_material_context_menu.bl_idname,
                      icon='DOWNARROW_HLT', text='')
        if len(obj.material_slots) > 1:
            controls.separator()
            controls.operator('object.material_slot_move', icon='TRIA_UP',
                              text='').direction = 'UP'
            controls.operator('object.material_slot_move', icon='TRIA_DOWN',
                              text='').direction = 'DOWN'
        if obj.mode == 'EDIT':
            row = self.layout.row(align=True)
            row.operator('object.material_slot_assign', text='Assign')
            if obj.type != 'FONT':
                row.operator('object.material_slot_select', text='Select')
                row.operator('object.material_slot_deselect', text='Deselect')


class TOON_OT_open_editor(bpy.types.Operator):
    bl_idname = 'toon_render.open_editor'
    bl_label = 'Open Toon Shader Editor'
    bl_description = 'Open the node editor dedicated to Toon Render materials'

    @classmethod
    def poll(cls, context):
        return (context.scene is not None
                and context.scene.render.engine == 'TOON_RENDER'
                and context.area is not None)

    def execute(self, context):
        area = context.area
        area.ui_type = ToonNodeTree.bl_idname
        obj = context.active_object
        material = obj.active_material if obj else None
        if material and material.toon_tree:
            area.spaces.active.node_tree = material.toon_tree
        return {'FINISHED'}


def _add_toon_node_type(layout, node_type):
    if hasattr(node_add_menu, 'AddNodeMenu'):
        node_add_menu.AddNodeMenu.node_operator(layout, node_type)
    else:
        node_add_menu.add_node_type(layout, node_type)


class TOON_MT_add_shader(bpy.types.Menu):
    bl_label = 'Shader'

    def draw(self, context):
        for node in (ToonSurfaceNode, ToonNormalMapNode, ToonAdditiveNode, ToonShaderToRGBNode,
                     ToonShadowMaskNode, ToonProximityMaskNode, ToonZDepthNode,
                     ToonFresnelNode, ToonMaterialOutputNode):
            _add_toon_node_type(self.layout, node.bl_idname)


class TOON_MT_add_texture(bpy.types.Menu):
    bl_label = 'Texture'

    def draw(self, context):
        for node in (ToonImageTextureNode, ToonFlipBookNode, ToonGradientNode, ToonUVNode,
                     ToonMappingNode, ToonVertexColorNode, ToonObjectColorNode):
            _add_toon_node_type(self.layout, node.bl_idname)


class TOON_MT_add_color(bpy.types.Menu):
    bl_label = 'Color'

    def draw(self, context):
        for node in (ToonRGBNode, ToonMixColorNode, ToonColorRampNode, ToonBlurNode,
                     ToonSeparateColorNode, ToonCombineColorNode, ToonInvertNode):
            _add_toon_node_type(self.layout, node.bl_idname)


class TOON_MT_add_utilities(bpy.types.Menu):
    bl_label = 'Utilities'

    def draw(self, context):
        for node in (ToonValueNode, ToonTimeNode, ToonMathNode, ToonMapRangeNode):
            _add_toon_node_type(self.layout, node.bl_idname)


def _draw_add_menu(self, context):
    if context.space_data.tree_type != ToonNodeTree.bl_idname:
        return
    for menu in (TOON_MT_add_shader, TOON_MT_add_texture,
                 TOON_MT_add_color, TOON_MT_add_utilities):
        self.layout.menu(menu.__name__)


def _draw_toon_header(self, context):
    if context.space_data.tree_type != ToonNodeTree.bl_idname:
        return _original_header_draw(self, context)

    layout = self.layout
    layout.template_header()
    bpy.types.NODE_MT_editor_menus.draw_collapsible(context, layout)
    layout.separator_spacer()
    obj = context.active_object
    if obj and hasattr(obj.data, 'materials'):
        slot_row = layout.row()
        slot_row.ui_units_x = 4
        slot_row.popover(panel=TOON_PT_node_material_slots.bl_idname)
        material_row = layout.row()
        material_row.template_ID(obj, 'active_material', new=TOON_OT_new_material.bl_idname)
        layout.separator_spacer()
    else:
        layout.label(text='Select an object with materials')
    layout.prop(context.space_data, 'pin', text='', emboss=False)


CLASSES = (ToonNodeTree, ToonColorSocket, ToonShaderSocket, ToonAlphaSocket,
           ToonVectorSocket, ToonVector3Socket, ToonNormalSocket,
           ToonFloatSocket, ToonFactorSocket,
           ToonSurfaceNode, ToonNormalMapNode, ToonAdditiveNode,
           ToonShaderToRGBNode, ToonShadowMaskNode, ToonProximityMaterial,
           TOON_UL_proximity_materials, TOON_OT_add_proximity_material,
           TOON_OT_remove_proximity_material, ToonProximityMaskNode,
           ToonZDepthNode, ToonFresnelNode,
           ToonImageTextureNode, ToonFlipBookNode,
           ToonValueNode, ToonTimeNode, ToonRGBNode, ToonUVNode, ToonMappingNode,
           ToonVertexColorNode, ToonObjectColorNode, ToonGradientNode,
           ToonSeparateColorNode, ToonCombineColorNode, ToonMixColorNode,
           ToonColorRampNode, ToonBlurNode, ToonMathNode, ToonMapRangeNode, ToonInvertNode,
           ToonMaterialOutputNode,
           TOON_OT_new_material, TOON_OT_copy_material,
           TOON_OT_paste_material, TOON_MT_material_context_menu,
           TOON_PT_node_material_slots, TOON_OT_open_editor,
           TOON_MT_add_shader, TOON_MT_add_texture,
           TOON_MT_add_color, TOON_MT_add_utilities)


def _set_node_header_draw(draw):
    # Blender registers the draw callback when the Header class is registered.
    # Re-registering is required; replacing the Python method alone does not
    # update the callback used by the visible editor.
    bpy.utils.unregister_class(space_node.NODE_HT_header)
    space_node.NODE_HT_header.draw = draw
    bpy.utils.register_class(space_node.NODE_HT_header)


def register():
    global _original_header_draw
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Material.toon_tree = bpy.props.PointerProperty(type=ToonNodeTree)
    bpy.types.NODE_MT_add.append(_draw_add_menu)
    _original_header_draw = space_node.NODE_HT_header.draw
    _set_node_header_draw(_draw_toon_header)
    bpy.app.timers.register(_time_redraw_timer, first_interval=0.1, persistent=True)
    refresh_time_nodes()


def unregister():
    global _original_header_draw
    _clear_material_clipboard()
    if bpy.app.timers.is_registered(_time_redraw_timer):
        bpy.app.timers.unregister(_time_redraw_timer)
    _time_tree_ids.clear()
    _tree_revisions.clear()
    _set_node_header_draw(_original_header_draw)
    _original_header_draw = None
    bpy.types.NODE_MT_add.remove(_draw_add_menu)
    del bpy.types.Material.toon_tree
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
