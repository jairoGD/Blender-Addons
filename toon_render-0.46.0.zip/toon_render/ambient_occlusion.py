"""Screen-space ambient occlusion for the Toon Render post stack.

The depth/normal sampling and edge-aware upsample are original GLSL adapted to
the engine's existing geometry buffer. They follow the general SSAO approach
described by McGuire et al. (SAO) and Intel XeGTAO, without copying shaders.
"""


MASK_FRAGMENT_SHADER = """
uniform sampler2D geometry_texture;
#ifdef TRANSMISSION
uniform sampler2D source_color;
uniform sampler2D material_strength_texture;
uniform float transmission_strength;
#endif
uniform mat4 inverse_projection;
uniform mat4 view_matrix;
uniform float projection_y_scale;
uniform float radius;
uniform float strength;
uniform float bias;
uniform int sample_count;
uniform int orthographic_camera;
#ifndef TRANSMISSION
uniform int cavity_type;
#endif
uniform vec2 ao_resolution;
out vec4 frag_color;

vec3 view_position(vec2 uv, float depth) {
    vec2 clip_xy = uv * 2.0 - 1.0;
    vec4 near_clip = inverse_projection * vec4(clip_xy, -1.0, 1.0);
    vec4 far_clip = inverse_projection * vec4(clip_xy, 1.0, 1.0);
    vec3 near_point = near_clip.xyz / near_clip.w;
    vec3 far_point = far_clip.xyz / far_clip.w;
    float fraction = (-depth - near_point.z) / (far_point.z - near_point.z);
    return mix(near_point, far_point, fraction);
}

void main() {
    ivec2 geometry_size = textureSize(geometry_texture, 0);
    vec2 uv = gl_FragCoord.xy / ao_resolution;
    ivec2 pixel = clamp(ivec2(uv * vec2(geometry_size)),
                        ivec2(0), geometry_size - ivec2(1));
    vec4 center = texelFetch(geometry_texture, pixel, 0);
    if (center.a <= 0.0) {
        frag_color = vec4(0.0);
        return;
    }
    vec3 center_position = view_position(uv, center.a);
    vec3 center_normal = normalize(mat3(view_matrix) * (center.rgb * 2.0 - 1.0));
    float pixel_radius = radius * projection_y_scale * float(geometry_size.y) * 0.5;
    if (orthographic_camera == 0) pixel_radius /= max(center.a, 0.01);
    pixel_radius = clamp(pixel_radius, 1.5, 128.0);
    float rotation = fract(sin(dot(vec2(pixel), vec2(12.9898, 78.233)))
                           * 43758.5453) * 6.2831853;
    float obscurance = 0.0;
#ifdef TRANSMISSION
    float tint_weight = 0.0;
    vec3 occluder_tint = vec3(0.0);
#else
    float ridge_sum = 0.0;
    if (cavity_type != 1) {
#endif
    for (int i = 0; i < 64; i++) {
        if (i >= sample_count) break;
        float radial = sqrt((float(i) + 0.5) / float(sample_count));
        float angle = rotation + float(i) * 2.3999632;
        vec2 offset = vec2(cos(angle), sin(angle)) * pixel_radius * radial;
        ivec2 sample_pixel = clamp(pixel + ivec2(round(offset)),
                                   ivec2(0), geometry_size - ivec2(1));
        if (all(equal(sample_pixel, pixel))) continue;
        vec4 sample_geometry = texelFetch(geometry_texture, sample_pixel, 0);
        if (sample_geometry.a <= 0.0) continue;
        vec2 sample_uv = (vec2(sample_pixel) + 0.5) / vec2(geometry_size);
        vec3 difference = view_position(sample_uv, sample_geometry.a) - center_position;
        float distance_squared = dot(difference, difference);
        if (distance_squared < 0.000001 || distance_squared >= radius * radius) continue;
        float alignment = dot(center_normal,
                              difference * inversesqrt(distance_squared));
        float normal_weight = max(alignment - bias, 0.0);
        float range_weight = 1.0 - distance_squared / (radius * radius);
        float contribution = normal_weight * range_weight * range_weight;
        obscurance += contribution;
#ifdef TRANSMISSION
        if (contribution > 0.0) {
            vec3 sample_color = max(texelFetch(source_color, sample_pixel, 0).rgb,
                                    vec3(0.0));
            float brightness = clamp(max(sample_color.r,
                                         max(sample_color.g, sample_color.b)), 0.0, 1.0);
            float emission = smoothstep(0.05, 0.6, brightness);
            float material_strength = max(
                texelFetch(material_strength_texture, sample_pixel, 0).b, 0.0);
            float transfer = emission * contribution * material_strength;
            occluder_tint += sample_color * transfer;
            tint_weight += transfer;
        }
#else
        ridge_sum += max(-alignment - bias, 0.0)
                     * range_weight * range_weight;
#endif
    }
#ifdef TRANSMISSION
    vec3 tint = tint_weight > 0.0 ? occluder_tint / tint_weight : vec3(0.0);
    float transfer = clamp(tint_weight * strength * 4.0 / float(sample_count)
                           * transmission_strength, 0.0, 1.0);
    frag_color = vec4(tint, transfer);
#else
    }
    float curvature = 0.0;
    if (cavity_type != 0) {
        ivec2 left_pixel = max(pixel - ivec2(1, 0), ivec2(0));
        ivec2 right_pixel = min(pixel + ivec2(1, 0), geometry_size - ivec2(1));
        ivec2 down_pixel = max(pixel - ivec2(0, 1), ivec2(0));
        ivec2 up_pixel = min(pixel + ivec2(0, 1), geometry_size - ivec2(1));
        vec4 left = texelFetch(geometry_texture, left_pixel, 0);
        vec4 right = texelFetch(geometry_texture, right_pixel, 0);
        vec4 down = texelFetch(geometry_texture, down_pixel, 0);
        vec4 up = texelFetch(geometry_texture, up_pixel, 0);
        float depth_limit = max(0.02, center.a * 0.03);
        if (left.a > 0.0 && right.a > 0.0 && down.a > 0.0 && up.a > 0.0
            && abs(left.a - center.a) < depth_limit
            && abs(right.a - center.a) < depth_limit
            && abs(down.a - center.a) < depth_limit
            && abs(up.a - center.a) < depth_limit) {
            vec3 nl = mat3(view_matrix) * (left.rgb * 2.0 - 1.0);
            vec3 nr = mat3(view_matrix) * (right.rgb * 2.0 - 1.0);
            vec3 nd = mat3(view_matrix) * (down.rgb * 2.0 - 1.0);
            vec3 nu = mat3(view_matrix) * (up.rgb * 2.0 - 1.0);
            curvature = clamp(((nr.x - nl.x) + (nu.y - nd.y))
                              * 2.0 * strength,
                              -1.0, 1.0);
        }
    }
    float ao = clamp(obscurance * strength * 4.0 / float(sample_count), 0.0, 1.0);
    float ridge = clamp(ridge_sum * strength * 4.0 / float(sample_count),
                        0.0, 1.0);
    frag_color = vec4(curvature, ridge, 0.0, ao);
#endif
}
"""


COMPOSITE_COMMON = """
uniform sampler2D source_color;
uniform sampler2D geometry_texture;
uniform sampler2D ao_texture;
uniform sampler2D material_id_texture;
uniform float opacity;
uniform float radius;
uniform int denoise;
uniform ivec2 target_origin;
out vec4 frag_color;

/* MATERIAL_SELECTION */

void main() {
    ivec2 size = textureSize(source_color, 0);
    ivec2 pixel = clamp(ivec2(gl_FragCoord.xy) - target_origin,
                        ivec2(0), size - ivec2(1));
    vec4 source = texelFetch(source_color, pixel, 0);
    vec4 center_geometry = texelFetch(geometry_texture, pixel, 0);
    if (center_geometry.a <= 0.0 || !selected_material(pixel)) {
        frag_color = source;
        return;
    }
    vec2 uv = (vec2(pixel) + 0.5) / vec2(size);
    ivec2 ao_size = textureSize(ao_texture, 0);
    ivec2 center_ao = clamp(ivec2(uv * vec2(ao_size)),
                            ivec2(0), ao_size - ivec2(1));
    vec4 ao = texelFetch(ao_texture, center_ao, 0);
    if (denoise != 0) {
        vec3 center_normal = normalize(center_geometry.rgb * 2.0 - 1.0);
        vec4 total = vec4(0.0);
        float total_weight = 0.0;
        for (int y = -1; y <= 1; y++) {
            for (int x = -1; x <= 1; x++) {
                ivec2 ao_pixel = clamp(center_ao + ivec2(x, y),
                                       ivec2(0), ao_size - ivec2(1));
                vec2 sample_uv = (vec2(ao_pixel) + 0.5) / vec2(ao_size);
                ivec2 geometry_pixel = clamp(ivec2(sample_uv * vec2(size)),
                                             ivec2(0), size - ivec2(1));
                vec4 sample_geometry = texelFetch(geometry_texture, geometry_pixel, 0);
                if (sample_geometry.a <= 0.0) continue;
                float depth_difference = abs(center_geometry.a - sample_geometry.a);
                float depth_weight = exp(-depth_difference * 8.0 / max(radius, 0.01));
                float normal_weight = pow(max(dot(center_normal,
                    normalize(sample_geometry.rgb * 2.0 - 1.0)), 0.0), 8.0);
                float spatial_weight = 1.0 / (1.0 + float(x * x + y * y));
                float weight = depth_weight * normal_weight * spatial_weight;
                total += texelFetch(ao_texture, ao_pixel, 0) * weight;
                total_weight += weight;
            }
        }
        if (total_weight > 0.00001) ao = total / total_weight;
    }
    float amount = clamp(ao.a * opacity, 0.0, 1.0);
"""


COMPOSITE_FRAGMENT_SHADER = '''uniform vec3 effect_color;
uniform int cavity_type;
uniform float world_ridge;
uniform float world_valley;
uniform float screen_ridge;
uniform float screen_valley;
''' + COMPOSITE_COMMON + """
    float valley = amount * world_valley;
    float ridge = ao.g * opacity * world_ridge;
    if (cavity_type != 0) {
        valley += max(-ao.r, 0.0) * opacity * screen_valley;
        ridge += max(ao.r, 0.0) * opacity * screen_ridge;
    }
    vec3 shaded = mix(source.rgb, effect_color, clamp(valley, 0.0, 1.0));
    frag_color = vec4(shaded * (1.0 + clamp(ridge, 0.0, 1.5)), source.a);
}
"""
