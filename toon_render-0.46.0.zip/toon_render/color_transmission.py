"""Color transmission post effect, sharing the contact sampling with AO."""

from .ambient_occlusion import COMPOSITE_COMMON


COMPOSITE_FRAGMENT_SHADER = 'uniform int blend_mode;\n' + COMPOSITE_COMMON + """
    // The mask alpha is zero for a black source face. Only face colors mix;
    // this pass does not add ambient occlusion or a separate shadow color.
    vec3 base = source.rgb;
    vec3 tint = max(ao.rgb, vec3(0.0));
    vec3 result;
    if (blend_mode == 1) {
        // Additive remains HDR; the output view transform handles display.
        result = base + tint * amount;
    } else if (blend_mode == 2) {
        result = base + (vec3(1.0) - clamp(base, 0.0, 1.0))
                      * clamp(tint, 0.0, 1.0) * amount;
    } else if (blend_mode == 3) {
        vec3 x = clamp(base, 0.0, 1.0);
        vec3 y = clamp(tint, 0.0, 1.0);
        vec3 overlay = mix(2.0 * x * y,
                           vec3(1.0) - 2.0 * (vec3(1.0) - x) * (vec3(1.0) - y),
                           step(vec3(0.5), x));
        result = mix(base, overlay, amount);
    } else {
        result = mix(base, tint, amount);
    }
    frag_color = vec4(result, source.a);
}
"""
