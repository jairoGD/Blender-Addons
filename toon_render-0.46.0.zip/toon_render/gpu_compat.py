"""Compile Toon GLSL with the Blender 4.5 and 5.x GPU APIs."""

import re
import bpy


_DECLARATION = re.compile(
    r'^\s*(uniform|in|out)\s+(float|int|bool|vec[234]|ivec[234]|mat[34]|sampler2D)\s+'
    r'([A-Za-z_]\w*)\s*;\s*$', re.MULTILINE)
_TYPE = {
    'float': 'FLOAT', 'int': 'INT', 'bool': 'BOOL',
    'vec2': 'VEC2', 'vec3': 'VEC3', 'vec4': 'VEC4',
    'ivec2': 'IVEC2', 'ivec3': 'IVEC3', 'ivec4': 'IVEC4',
    'mat3': 'MAT3', 'mat4': 'MAT4',
}
_SHADER_SAMPLERS = {}
_INITIALIZED = set()
_FALLBACK_TEXTURE = None


def raw_shader(shader):
    return shader


def draw_batch(batch, shader):
    batch.draw(shader)


def forget_shaders(shaders):
    for shader in shaders:
        key = id(shader)
        _SHADER_SAMPLERS.pop(key, None)
        _INITIALIZED.discard(key)


def bind_shader(shader):
    """Bind unused samplers too; Vulkan requires valid texture descriptors."""
    global _FALLBACK_TEXTURE
    shader.bind()
    samplers = _SHADER_SAMPLERS.get(id(shader), ())
    if not samplers or id(shader) in _INITIALIZED:
        return
    if _FALLBACK_TEXTURE is None:
        import gpu
        _FALLBACK_TEXTURE = gpu.types.GPUTexture((1, 1), format='RGBA8')
    for name in samplers:
        shader.uniform_sampler(name, _FALLBACK_TEXTURE)
    _INITIALIZED.add(id(shader))


def _preprocess(source):
    definitions = set()
    active = [True]
    result = []
    for line in source.splitlines():
        stripped = line.strip()
        if stripped.startswith('#define '):
            if active[-1]:
                definitions.add(stripped.split()[1])
        elif stripped.startswith('#ifdef '):
            active.append(active[-1] and stripped.split()[1] in definitions)
        elif stripped.startswith('#ifndef '):
            active.append(active[-1] and stripped.split()[1] not in definitions)
        elif stripped == '#else':
            active[-1] = active[-2] and not active[-1]
        elif stripped == '#endif':
            active.pop()
        elif active[-1]:
            result.append(line)
    return '\n'.join(result)


def create_shader(vertex_source, fragment_source):
    import gpu

    if bpy.app.version < (5, 0, 0):
        return gpu.types.GPUShader(vertex_source, fragment_source)

    info = gpu.types.GPUShaderCreateInfo()
    vertex_inputs = []
    vertex_outputs = []
    fragment_inputs = []
    fragment_outputs = []
    uniforms = {}

    def strip(source, stage):
        def declaration(match):
            qualifier, type_name, name = match.groups()
            if qualifier == 'uniform':
                uniforms[name] = type_name
            elif stage == 'VERTEX':
                (vertex_inputs if qualifier == 'in' else vertex_outputs).append(
                    (type_name, name))
            else:
                (fragment_inputs if qualifier == 'in' else fragment_outputs).append(
                    (type_name, name))
            return ''
        return _DECLARATION.sub(declaration, source)

    vertex_source = strip(_preprocess(vertex_source), 'VERTEX')
    fragment_source = strip(_preprocess(fragment_source), 'FRAGMENT')
    for entry in fragment_inputs:
        if entry not in vertex_outputs:
            raise ValueError(f'Fragment input {entry[1]} has no vertex output')
    for slot, (type_name, name) in enumerate(vertex_inputs):
        info.vertex_in(slot, _TYPE[type_name], name)
    if vertex_outputs:
        interface = gpu.types.GPUStageInterfaceInfo('toon_varyings')
        for type_name, name in vertex_outputs:
            interface.smooth(_TYPE[type_name], name)
        info.vertex_out(interface)
    for slot, (type_name, name) in enumerate(fragment_outputs):
        info.fragment_out(slot, _TYPE[type_name], name)
    samplers = []
    for name, type_name in uniforms.items():
        if not re.search(r'\b' + re.escape(name) + r'\b',
                         vertex_source + fragment_source):
            continue
        if type_name == 'sampler2D':
            info.sampler(len(samplers), 'FLOAT_2D', name)
            samplers.append(name)
        else:
            info.push_constant(_TYPE[type_name], name)
    info.vertex_source(vertex_source)
    info.fragment_source(fragment_source)
    shader = gpu.shader.create_from_info(info)
    _SHADER_SAMPLERS[id(shader)] = tuple(samplers)
    _INITIALIZED.discard(id(shader))
    return shader
