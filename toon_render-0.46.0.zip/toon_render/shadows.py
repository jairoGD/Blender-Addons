"""Opacity-aware shadow maps and per-light controls for Toon Render."""

import math
import bpy
from mathutils import Matrix, Vector
from . import toon_graph, gpu_compat


SHADOW_VERTEX = """
uniform mat4 model_view_projection;
uniform mat4 model_matrix;
in vec3 pos;
in vec3 normal;
in vec2 uv;
out vec2 tex_coord;
out vec3 world_position;
out vec3 world_normal;
out vec3 local_position;
out vec3 local_normal;
void main() {
    gl_Position = model_view_projection * vec4(pos, 1.0);
    tex_coord = uv;
    world_position = (model_matrix * vec4(pos, 1.0)).xyz;
    world_normal = mat3(transpose(inverse(model_matrix))) * normal;
    local_position = pos;
    local_normal = normal;
}
"""

SHADOW_FRAGMENT = """
uniform mat4 model_matrix;
uniform mat4 view_matrix;
uniform float material_alpha;
uniform int alpha_mode;
uniform float alpha_threshold;
uniform int radial_mode;
uniform vec3 shadow_light_position;
uniform float shadow_far;
#ifdef USE_ALPHA_TEXTURE
uniform sampler2D alpha_texture;
#endif
#ifdef PEEL_LAYER
uniform sampler2D previous_layer;
#endif
in vec2 tex_coord;
in vec3 world_position;
in vec3 world_normal;
in vec3 local_position;
in vec3 local_normal;
out vec4 frag_color;
void main() {
    float alpha = material_alpha;
#ifdef USE_ALPHA_TEXTURE
    alpha *= texture(alpha_texture, tex_coord).a;
#endif
    if (alpha_mode == 1 && alpha < alpha_threshold) discard;
    if (alpha_mode == 0 && alpha <= alpha_threshold) discard;
    if (alpha_mode == 1) alpha = 1.0;
    float shadow_depth = radial_mode != 0
        ? length(world_position - shadow_light_position) / shadow_far
        : gl_FragCoord.z;
#ifdef PEEL_LAYER
    vec4 previous = texelFetch(previous_layer, ivec2(gl_FragCoord.xy), 0);
    float previous_depth = previous.r + previous.b / 1024.0;
    if (previous.a == 0.0 || shadow_depth <= previous_depth + 0.00001) discard;
#endif
    float coarse_depth = floor(shadow_depth * 1024.0) / 1024.0;
    float fine_depth = (shadow_depth - coarse_depth) * 1024.0;
    frag_color = vec4(coarse_depth, alpha, fine_depth, 1.0);
}
"""


def _redraw(_self=None, _context=None):
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


class TOON_PT_light_settings(bpy.types.Panel):
    bl_label = 'Toon Render Light'
    bl_idname = 'TOON_PT_light_settings'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'data'
    bl_order = 0

    @classmethod
    def poll(cls, context):
        light = getattr(context, 'light', None)
        return (context.scene is not None
                and context.scene.render.engine == 'TOON_RENDER'
                and light is not None
                and light.type in {'SUN', 'POINT', 'SPOT'})

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(context.light, 'color', text='Color')
        layout.prop(context.light, 'energy', text='Strength')


class TOON_PT_light_shadows(bpy.types.Panel):
    bl_label = 'Toon Render Shadows'
    bl_idname = 'TOON_PT_light_shadows'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'data'

    @classmethod
    def poll(cls, context):
        return (context.scene is not None
                and context.scene.render.engine == 'TOON_RENDER'
                and context.light is not None
                and context.light.type in {'SUN', 'POINT', 'SPOT'})

    def draw(self, context):
        light = context.light
        layout = self.layout
        layout.prop(light, 'toon_shadow_enabled', text='Shadows')
        column = layout.column()
        column.enabled = light.toon_shadow_enabled
        column.prop(light, 'toon_shadow_resolution', text='Resolution')
        column.prop(light, 'toon_shadow_distance', text='Distance')
        if light.type == 'SUN':
            column.prop(light, 'toon_shadow_cascades', text='Cascades')
            if light.toon_shadow_cascades == '1':
                column.prop(light, 'toon_shadow_size', text='Area Size')
            else:
                column.prop(light, 'toon_shadow_cascade_near_range',
                            text='Near Range')
                column.prop(light, 'toon_shadow_cascade_middle_range',
                            text='Middle Range')
                column.prop(light, 'toon_shadow_cascade_blend',
                            text='Transition')
        column.prop(light,
                    'toon_shadow_cascade_bias'
                    if light.type == 'SUN' and light.toon_shadow_cascades != '1'
                    else 'toon_shadow_bias', text='Bias')
        column.prop(light, 'toon_shadow_softness', text='Softness')
        column.prop(light, 'toon_shadow_strength', text='Strength', slider=True)


def _orthographic(size, near, far):
    return Matrix((
        (2.0 / size, 0.0, 0.0, 0.0),
        (0.0, 2.0 / size, 0.0, 0.0),
        (0.0, 0.0, -2.0 / (far - near), -(far + near) / (far - near)),
        (0.0, 0.0, 0.0, 1.0),
    ))


def _perspective(angle, near, far):
    scale = 1.0 / math.tan(max(0.02, min(angle, math.pi - 0.02)) * 0.5)
    return Matrix((
        (scale, 0.0, 0.0, 0.0),
        (0.0, scale, 0.0, 0.0),
        (0.0, 0.0, -(far + near) / (far - near), -2.0 * far * near / (far - near)),
        (0.0, 0.0, -1.0, 0.0),
    ))


def _light_matrix(light_object, object_matrix, camera_view):
    light = light_object.data
    distance = light.toon_shadow_distance
    matrix = object_matrix
    rotation = matrix.to_quaternion()
    if light.type == 'SUN':
        camera_world = camera_view.inverted()
        forward = camera_world.to_quaternion() @ Vector((0.0, 0.0, -1.0))
        center = camera_world.translation + forward * min(10.0, distance * 0.33)
        direction = rotation @ Vector((0.0, 0.0, -1.0))
        position = center - direction * distance
        light_world = Matrix.Translation(position) @ rotation.to_matrix().to_4x4()
        return _orthographic(light.toon_shadow_size, 0.1, distance * 2.0) @ light_world.inverted()
    light_world = Matrix.Translation(matrix.translation) @ rotation.to_matrix().to_4x4()
    return _perspective(light.spot_size, 0.1, distance) @ light_world.inverted()


def _point_face_matrix(position, face, far):
    directions = (
        ((1, 0, 0), (0, -1, 0)), ((-1, 0, 0), (0, -1, 0)),
        ((0, 1, 0), (0, 0, 1)), ((0, -1, 0), (0, 0, -1)),
        ((0, 0, 1), (0, -1, 0)), ((0, 0, -1), (0, -1, 0)),
    )
    direction = Vector(directions[face][0])
    up = Vector(directions[face][1])
    right = direction.cross(up).normalized()
    corrected_up = right.cross(direction)
    view = Matrix((
        (right.x, right.y, right.z, -right.dot(position)),
        (corrected_up.x, corrected_up.y, corrected_up.z, -corrected_up.dot(position)),
        (-direction.x, -direction.y, -direction.z, direction.dot(position)),
        (0.0, 0.0, 0.0, 1.0),
    ))
    return _perspective(math.pi * 0.5, 0.1, far) @ view


def _cascade_setup(light, object_matrix, camera_view, camera_projection,
                   resolution):
    """Fit three or five stabilized Sun projections to camera-depth intervals."""
    inverse_projection = camera_projection.inverted()
    inverse_view = camera_view.inverted()

    def view_point(x, y, clip_z):
        point = inverse_projection @ Vector((x, y, clip_z, 1.0))
        return Vector(point.xyz) / point.w

    near = max(0.01, -view_point(0.0, 0.0, -1.0).z)
    far = min(-view_point(0.0, 0.0, 1.0).z,
              light.toon_shadow_distance)
    far = max(far, near + 0.1)
    span = far - near
    near_end = min(max(light.toon_shadow_cascade_near_range,
                       near + 0.05), near + span * 0.7)
    middle_end = min(max(light.toon_shadow_cascade_middle_range,
                         near_end + 0.05), near + span * 0.9)
    count = int(light.toon_shadow_cascades)
    if count == 5:
        close_end = near + (near_end - near) * 0.3
        splits = [near, close_end, near_end,
                  math.sqrt(near_end * middle_end), middle_end, far]
    else:
        splits = [near, near_end, middle_end, far]

    rotation = object_matrix.to_quaternion()
    inverse_rotation = rotation.inverted()
    direction = rotation @ Vector((0.0, 0.0, -1.0))
    atlas_offset = 0
    cascades = []
    for index in range(count):
        corners = []
        for depth in (splits[index], splits[index + 1]):
            for y in (-1.0, 1.0):
                for x in (-1.0, 1.0):
                    start = view_point(x, y, -1.0)
                    end = view_point(x, y, 1.0)
                    fraction = (-depth - start.z) / (end.z - start.z)
                    corners.append(inverse_view @ (start + (end - start) * fraction))
        center = sum(corners, Vector()) / len(corners)
        radius = max((corner - center).length for corner in corners) * 1.05
        radius = max(radius, 0.1)
        full_size_count = 3 if count == 5 else 2
        tile_resolution = (resolution if index < full_size_count
                           else max(64, resolution >> 1))
        tile_size = radius * 2.0
        texel = tile_size / tile_resolution
        center_light = inverse_rotation @ center
        center_light.x = round(center_light.x / texel) * texel
        center_light.y = round(center_light.y / texel) * texel
        stable_center = rotation @ center_light
        caster_margin = light.toon_shadow_distance * 0.5
        position = stable_center - direction * (radius + caster_margin)
        light_world = (Matrix.Translation(position)
                       @ rotation.to_matrix().to_4x4())
        matrix = (_orthographic(tile_size, 0.1,
                                2.0 * (radius + caster_margin))
                  @ light_world.inverted())
        cascades.append((matrix, tile_resolution, atlas_offset))
        atlas_offset += tile_resolution

    far_inverse = cascades[-1][0].inverted()
    transforms = []
    for matrix, _, _ in cascades[:-1]:
        relative = matrix @ far_inverse
        transforms.append(((relative[0][0], relative[1][1],
                            relative[2][2], relative[0][3]),
                           (relative[1][3], relative[2][3])))
    split_bounds = [splits[index + 1] for index in range(count - 1)]
    split_bounds.extend([far] * (4 - len(split_bounds)))
    meta = (far, light.toon_shadow_cascade_blend, float(count), 0.0)
    return cascades, tuple(split_bounds), meta, transforms, atlas_offset


def _get_shadow_shader(engine, graph, peeled):
    import gpu
    from . import _graph_vertex

    key = ('SHADOW', graph.code, peeled)
    if key not in engine._shaders:
        source = SHADOW_FRAGMENT.replace('void main() {', graph.code + '\nvoid main() {', 1)
        source = source.replace('''    float alpha = material_alpha;
#ifdef USE_ALPHA_TEXTURE
    alpha *= texture(alpha_texture, tex_coord).a;
#endif''', '    float alpha = toon_graph_alpha(vec3(1.0));')
        if graph.uses_shadow_mask:
            source = source.replace('    float alpha = toon_graph_alpha(vec3(1.0));',
                                    '    toon_shadow_mask_value = 1.0;\n'
                                    '    float alpha = toon_graph_alpha(vec3(1.0));')
        engine._shaders[key] = gpu_compat.create_shader(
            _graph_vertex(SHADOW_VERTEX, graph),
            ('#define PEEL_LAYER\n' if peeled else '') + source)
    return engine._shaders[key]


def render_shadow_maps(engine, depsgraph, camera_view, camera_projection,
                       priority_queues,
                       textures, viewport=False):
    """Return light-indexed maps and transient offscreens to release after shading."""
    import gpu

    sources = []
    light_index = 0
    for instance in depsgraph.object_instances:
        obj = instance.object
        if obj.type != 'LIGHT' or obj.hide_render or obj.data.type not in {'SUN', 'POINT', 'SPOT'}:
            continue
        if obj.data.toon_shadow_enabled:
            sources.append((light_index, obj, instance.matrix_world.copy()))
        light_index += 1
        if light_index == 4:
            break
    if viewport:
        active_keys = {(obj.original.as_pointer(),
                        int(obj.data.toon_shadow_resolution), obj.data.type,
                        obj.data.toon_shadow_cascades if obj.data.type == 'SUN' else '1')
                       for _, obj, _ in sources}
        for key in list(engine._viewport_shadow_buffers):
            if key not in active_keys:
                old = engine._viewport_shadow_buffers.pop(key)
                if isinstance(old, tuple):
                    for offscreen in old:
                        offscreen.free()
    if not sources:
        return {}, []
    if not any(item[-2] for queues in priority_queues.values()
               for queue in queues for item in queue):
        return {}, []

    def get_texture(kind, source):
        return toon_graph.gpu_texture(kind, source, textures)

    maps = {}
    transient = []

    def draw_layer(target, light_matrix, layer_index, previous_texture,
                   position, distance, point, resolution, origin=(0, 0),
                   clear_color=True):
        with target.bind():
            gpu.state.viewport_set(origin[0], origin[1], resolution, resolution)
            gpu.state.depth_test_set('LESS_EQUAL')
            gpu.state.depth_mask_set(True)
            gpu.state.blend_set('NONE')
            gpu.state.color_mask_set(True, True, True, True)
            framebuffer = gpu.state.active_framebuffer_get()
            if clear_color:
                framebuffer.clear(color=(1.0, 0.0, 0.0, 0.0), depth=1.0)
            else:
                framebuffer.clear(depth=1.0)
            for opaque_queue, transparent_queue in priority_queues.values():
                for item in opaque_queue + transparent_queue:
                    _, _, _, model, batch, graph, method, threshold, _, _, double_sided, _, cast_shadow, _ = item
                    if not cast_shadow:
                        continue
                    shader = _get_shadow_shader(engine, graph, layer_index > 0)
                    gpu.state.face_culling_set('NONE' if double_sided else 'BACK')
                    gpu_compat.bind_shader(shader)
                    shader.uniform_float('model_view_projection', light_matrix @ model)
                    shader.uniform_float('model_matrix', model)
                    try:
                        shader.uniform_float('view_matrix', camera_view)
                    except ValueError:
                        pass
                    graph.bind(shader, get_texture, depsgraph)
                    shader.uniform_int('alpha_mode', 1 if method == 'CUTOUT' else 0)
                    shader.uniform_float('alpha_threshold', threshold)
                    shader.uniform_int('radial_mode', 1 if point else 0)
                    shader.uniform_float('shadow_light_position', position)
                    shader.uniform_float('shadow_far', distance)
                    if layer_index:
                        shader.uniform_sampler('previous_layer', previous_texture)
                    gpu_compat.draw_batch(batch, shader)

    try:
        for light_index, light_object, object_matrix in sources:
            light = light_object.data
            resolution = int(light.toon_shadow_resolution)
            if not viewport:
                scale = depsgraph.scene_eval.toon_render_shadow_resolution / 100.0
                resolution = max(64, round(resolution * scale))
            cascaded = light.type == 'SUN' and light.toon_shadow_cascades != '1'
            cache_key = (light_object.original.as_pointer(), resolution, light.type,
                         light.toon_shadow_cascades if light.type == 'SUN' else '1')
            point = light.type == 'POINT'
            buffers = engine._viewport_shadow_buffers.get(cache_key) if viewport else None
            if buffers is None:
                if point:
                    colors = tuple(gpu.types.GPUTexture(
                        (resolution * 3, resolution * 2), format='RGBA16F')
                        for _ in range(2))
                    depth = gpu.types.GPUTexture(
                        (resolution * 3, resolution * 2), format='DEPTH_COMPONENT24')
                    frames = tuple(gpu.types.GPUFrameBuffer(
                        depth_slot=depth, color_slots=[color]) for color in colors)
                    buffers = {'colors': colors, 'depth': depth, 'frames': frames}
                else:
                    if cascaded:
                        count = int(light.toon_shadow_cascades)
                        atlas_width = (resolution * (3 if count == 5 else 2)
                                       + max(64, resolution >> 1)
                                       * (2 if count == 5 else 1))
                    else:
                        atlas_width = resolution
                    buffers = tuple(gpu.types.GPUOffScreen(
                        atlas_width, resolution, format='RGBA16F') for _ in range(2))
                    if not viewport:
                        transient.extend(buffers)
                if viewport:
                    engine._viewport_shadow_buffers[cache_key] = buffers
            position = object_matrix.translation
            if point:
                for layer_index, target in enumerate(buffers['frames']):
                    previous = buffers['colors'][0] if layer_index else None
                    for face in range(6):
                        matrix = _point_face_matrix(position, face, light.toon_shadow_distance)
                        origin = (face % 3 * resolution, face // 3 * resolution)
                        draw_layer(target, matrix, layer_index, previous, position,
                                   light.toon_shadow_distance, True, resolution,
                                   origin, face == 0)
                maps[light_index] = ('POINT', None, buffers['colors'], light,
                                     position, None)
            elif cascaded:
                cascades, splits, meta, transforms, _ = _cascade_setup(
                    light, object_matrix, camera_view, camera_projection,
                    resolution)
                for layer_index, target in enumerate(buffers):
                    previous = buffers[0].texture_color if layer_index else None
                    for cascade_index, (matrix, tile_resolution, offset) in enumerate(cascades):
                        draw_layer(target, matrix, layer_index, previous, position,
                                   light.toon_shadow_distance, False,
                                   tile_resolution, (offset, 0),
                                   cascade_index == 0)
                maps[light_index] = ('CASCADE', cascades[-1][0], buffers,
                                     light, position, (splits, meta, transforms,
                                                       resolution))
            else:
                matrix = _light_matrix(light_object, object_matrix, camera_view)
                for layer_index, target in enumerate(buffers):
                    previous = buffers[0].texture_color if layer_index else None
                    draw_layer(target, matrix, layer_index, previous, position,
                               light.toon_shadow_distance, False, resolution)
                maps[light_index] = ('MAP2D', matrix, buffers, light, position,
                                     None)
    except Exception:
        for offscreen in transient:
            offscreen.free()
        raise
    finally:
        gpu.state.face_culling_set('NONE')
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
    return maps, transient


def register():
    bpy.types.Light.toon_shadow_enabled = bpy.props.BoolProperty(
        name='Shadows', default=False, update=_redraw)
    bpy.types.Light.toon_shadow_resolution = bpy.props.EnumProperty(
        name='Resolution', items=tuple((str(size), str(size), '')
                                       for size in (256, 512, 1024, 2048)),
        default='1024', update=_redraw)
    bpy.types.Light.toon_shadow_distance = bpy.props.FloatProperty(
        name='Distance', default=120.0, min=1.0, max=1000.0, update=_redraw)
    bpy.types.Light.toon_shadow_size = bpy.props.FloatProperty(
        name='Area Size', default=20.0, min=1.0, max=1000.0, update=_redraw)
    bpy.types.Light.toon_shadow_cascades = bpy.props.EnumProperty(
        name='Cascades', items=(('1', 'Single', 'Use one fixed Sun shadow map'),
                                ('3', 'Three', 'Use three Sun shadow maps'),
                                ('5', 'Five', 'Use five Sun shadow maps for finer mid- and far-range detail')),
        default='5', update=_redraw)
    bpy.types.Light.toon_shadow_cascade_near_range = bpy.props.FloatProperty(
        name='Near Range', default=5.0, min=0.1, max=1000.0,
        soft_max=30.0, update=_redraw,
        description='Camera distance covered by the highest-detail Sun shadow map')
    bpy.types.Light.toon_shadow_cascade_middle_range = bpy.props.FloatProperty(
        name='Middle Range', default=20.0, min=0.2, max=1000.0,
        soft_max=100.0, update=_redraw,
        description='Camera distance covered by the middle Sun shadow map')
    bpy.types.Light.toon_shadow_cascade_blend = bpy.props.FloatProperty(
        name='Transition', subtype='FACTOR', default=0.3,
        min=0.0, max=0.3, update=_redraw,
        description='Blend between cascades near each distance boundary')
    bpy.types.Light.toon_shadow_bias = bpy.props.FloatProperty(
        name='Bias', default=0.004, min=0.0, max=0.05, precision=4, update=_redraw)
    bpy.types.Light.toon_shadow_cascade_bias = bpy.props.FloatProperty(
        name='Cascade Bias', default=0.005, min=0.0, max=1.0,
        precision=4, update=_redraw,
        description='Depth bias for cascaded Sun shadows in Blender world units')
    bpy.types.Light.toon_shadow_softness = bpy.props.FloatProperty(
        name='Softness', default=1.0, min=0.0, max=4.0, update=_redraw)
    bpy.types.Light.toon_shadow_strength = bpy.props.FloatProperty(
        name='Strength', subtype='FACTOR', default=1.0, min=0.0, max=1.0,
        update=_redraw)
    bpy.utils.register_class(TOON_PT_light_settings)
    bpy.utils.register_class(TOON_PT_light_shadows)


def unregister():
    bpy.utils.unregister_class(TOON_PT_light_shadows)
    bpy.utils.unregister_class(TOON_PT_light_settings)
    for name in ('toon_shadow_strength', 'toon_shadow_softness', 'toon_shadow_bias',
                 'toon_shadow_cascade_bias',
                 'toon_shadow_cascade_blend', 'toon_shadow_cascade_near_range',
                 'toon_shadow_cascade_middle_range',
                 'toon_shadow_cascades',
                 'toon_shadow_size', 'toon_shadow_distance', 'toon_shadow_resolution',
                 'toon_shadow_enabled'):
        delattr(bpy.types.Light, name)
