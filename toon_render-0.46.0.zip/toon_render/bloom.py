"""Multi-resolution emissive bloom for Blender's GPU API."""

LEVEL_COUNT = 10

DOWNSAMPLE_FRAGMENT_SHADER = """
uniform sampler2D source_texture;
uniform float threshold;
uniform int prefilter;
out vec4 frag_color;

void main() {
    ivec2 source_size = textureSize(source_texture, 0);
    ivec2 target_size = ivec2(TOON_TARGET_WIDTH, TOON_TARGET_HEIGHT);
    ivec2 target_pixel = ivec2(gl_FragCoord.xy);
    ivec2 source_center = ivec2((vec2(target_pixel) + 0.5)
                                * vec2(source_size) / vec2(target_size));
    vec3 sum_color = vec3(0.0);
    float sum_weight = 0.0;
    for (int y = -2; y <= 2; ++y) {
        for (int x = -2; x <= 2; ++x) {
            ivec2 sample_pixel = clamp(source_center + ivec2(x, y),
                                       ivec2(0), source_size - ivec2(1));
            vec3 sample_color = max(texelFetch(source_texture, sample_pixel, 0).rgb,
                                    vec3(0.0));
            if (prefilter != 0) {
                float peak = max(max(sample_color.r, sample_color.g), sample_color.b);
                float cutoff = smoothstep(threshold, threshold + 0.1, peak);
                sample_color *= cutoff;
            }
            float weight = exp(-0.32 * float(x * x + y * y));
            sum_color += sample_color * weight;
            sum_weight += weight;
        }
    }
    frag_color = vec4(sum_color / sum_weight, 1.0);
}
"""

BILINEAR_FUNCTION = """
vec3 sample_bilinear(sampler2D image, vec2 uv) {
    ivec2 size = textureSize(image, 0);
    vec2 coordinate = uv * vec2(size) - vec2(0.5);
    ivec2 lower = ivec2(floor(coordinate));
    vec2 fraction = fract(coordinate);
    ivec2 upper = lower + ivec2(1);
    lower = clamp(lower, ivec2(0), size - ivec2(1));
    upper = clamp(upper, ivec2(0), size - ivec2(1));
    vec3 a = mix(texelFetch(image, ivec2(lower.x, lower.y), 0).rgb,
                 texelFetch(image, ivec2(upper.x, lower.y), 0).rgb, fraction.x);
    vec3 b = mix(texelFetch(image, ivec2(lower.x, upper.y), 0).rgb,
                 texelFetch(image, ivec2(upper.x, upper.y), 0).rgb, fraction.x);
    return mix(a, b, fraction.y);
}
"""

UPSAMPLE_FRAGMENT_SHADER = """
uniform sampler2D source_small;
uniform sampler2D source_detail;
uniform float detail_weight;
uniform int include_small;
out vec4 frag_color;
/* BILINEAR_FUNCTION */

void main() {
    ivec2 size = textureSize(source_detail, 0);
    vec2 uv = (gl_FragCoord.xy + vec2(0.0)) / vec2(size);
    vec3 color = sample_bilinear(source_detail, uv) * detail_weight;
    if (include_small != 0) {
        vec2 step_uv = 1.0 / vec2(textureSize(source_small, 0));
        vec3 broad = sample_bilinear(source_small, uv) * 4.0;
        broad += sample_bilinear(source_small, uv + vec2(step_uv.x, 0.0));
        broad += sample_bilinear(source_small, uv - vec2(step_uv.x, 0.0));
        broad += sample_bilinear(source_small, uv + vec2(0.0, step_uv.y));
        broad += sample_bilinear(source_small, uv - vec2(0.0, step_uv.y));
        vec2 diagonal = step_uv * 0.70710678;
        broad += sample_bilinear(source_small, uv + diagonal);
        broad += sample_bilinear(source_small, uv - diagonal);
        broad += sample_bilinear(source_small, uv + vec2(diagonal.x, -diagonal.y));
        broad += sample_bilinear(source_small, uv + vec2(-diagonal.x, diagonal.y));
        color += broad / 12.0;
    }
    frag_color = vec4(color, 1.0);
}
"""

COMPOSITE_FRAGMENT_SHADER = """
uniform sampler2D source_color;
uniform sampler2D bloom_texture;
uniform ivec2 target_origin;
uniform float normalization;
uniform float strength;
uniform float opacity;
out vec4 frag_color;
/* BILINEAR_FUNCTION */

vec3 sample_round(sampler2D image, vec2 uv) {
    vec2 step_uv = 0.8 / vec2(textureSize(image, 0));
    vec2 diagonal = step_uv * 0.70710678;
    vec3 value = sample_bilinear(image, uv) * 4.0;
    value += sample_bilinear(image, uv + vec2(step_uv.x, 0.0));
    value += sample_bilinear(image, uv - vec2(step_uv.x, 0.0));
    value += sample_bilinear(image, uv + vec2(0.0, step_uv.y));
    value += sample_bilinear(image, uv - vec2(0.0, step_uv.y));
    value += sample_bilinear(image, uv + diagonal);
    value += sample_bilinear(image, uv - diagonal);
    value += sample_bilinear(image, uv + vec2(diagonal.x, -diagonal.y));
    value += sample_bilinear(image, uv + vec2(-diagonal.x, diagonal.y));
    return value / 12.0;
}

void main() {
    ivec2 size = textureSize(source_color, 0);
    ivec2 pixel = clamp(ivec2(gl_FragCoord.xy) - target_origin,
                        ivec2(0), size - ivec2(1));
    vec4 base = texelFetch(source_color, pixel, 0);
    vec2 uv = (vec2(pixel) + vec2(0.5)) / vec2(size);
    vec3 glow = sample_round(bloom_texture, uv) * normalization;
    vec3 contribution = glow * strength * opacity;
    float glow_alpha = clamp(max(max(contribution.r, contribution.g), contribution.b),
                             0.0, 1.0);
    frag_color = vec4(base.rgb + contribution, max(base.a, glow_alpha));
}
"""


def downsample_source(width, height):
    return DOWNSAMPLE_FRAGMENT_SHADER.replace('TOON_TARGET_WIDTH', str(width)).replace(
        'TOON_TARGET_HEIGHT', str(height))


def composite_source():
    return COMPOSITE_FRAGMENT_SHADER.replace('/* BILINEAR_FUNCTION */', BILINEAR_FUNCTION)


def upsample_source():
    return UPSAMPLE_FRAGMENT_SHADER.replace('/* BILINEAR_FUNCTION */', BILINEAR_FUNCTION)
