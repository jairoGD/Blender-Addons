"""One-pass scene-linear color adjustments for the post-processing stack."""


FRAGMENT_SHADER = """
uniform sampler2D source_color;
uniform sampler2D material_id_texture;
uniform ivec2 target_origin;
uniform float brightness;
uniform float contrast;
uniform float saturation;
uniform float luminance;
uniform float gamma_value;
uniform float tint;
uniform vec3 tint_color;
uniform int tint_mode;
uniform float opacity;
out vec4 frag_color;

/* MATERIAL_SELECTION */

vec3 blend_tint(vec3 base, vec3 tint_color_value) {
    vec3 a = clamp(base, vec3(0.0), vec3(1.0));
    vec3 b = clamp(tint_color_value, vec3(0.0), vec3(1.0));
    if (tint_mode == 0) return b;
    if (tint_mode == 1) return base * b;
    if (tint_mode == 2) return mix(2.0 * a * b,
        vec3(1.0) - 2.0 * (vec3(1.0) - a) * (vec3(1.0) - b),
        step(vec3(0.5), a));
    if (tint_mode == 3) return vec3(1.0) - min((vec3(1.0) - a) / max(b, vec3(0.0001)), vec3(1.0));
    if (tint_mode == 4) return min(a / max(vec3(1.0) - b, vec3(0.0001)), vec3(1.0));
    if (tint_mode == 5) return base + b;
    if (tint_mode == 6) return vec3(1.0) - (vec3(1.0) - a) * (vec3(1.0) - b);
    if (tint_mode == 7) return mix(
        a - (vec3(1.0) - 2.0 * b) * a * (vec3(1.0) - a),
        a + (2.0 * b - vec3(1.0)) * (sqrt(a) - a),
        step(vec3(0.5), b));
    if (tint_mode == 8) return mix(2.0 * a * b,
        vec3(1.0) - 2.0 * (vec3(1.0) - a) * (vec3(1.0) - b),
        step(vec3(0.5), b));
    if (tint_mode == 9) return abs(base - b);
    return max(base - b, vec3(0.0));
}

void main() {
    ivec2 size = textureSize(source_color, 0);
    ivec2 pixel = clamp(ivec2(gl_FragCoord.xy) - target_origin,
                        ivec2(0), size - ivec2(1));
    vec4 base = texelFetch(source_color, pixel, 0);
    if (!selected_material(pixel)) {
        frag_color = base;
        return;
    }
    vec3 adjusted = max(base.rgb * luminance + vec3(brightness), vec3(0.0));
    adjusted = max((adjusted - vec3(0.5)) * contrast + vec3(0.5), vec3(0.0));
    adjusted = pow(adjusted, vec3(1.0 / max(gamma_value, 0.1)));
    float gray = dot(adjusted, vec3(0.2126, 0.7152, 0.0722));
    adjusted = mix(vec3(gray), adjusted, saturation);
    adjusted = mix(adjusted, blend_tint(adjusted, tint_color), clamp(tint, 0.0, 1.0));
    frag_color = vec4(mix(base.rgb, adjusted, clamp(opacity, 0.0, 1.0)), base.a);
}
"""
