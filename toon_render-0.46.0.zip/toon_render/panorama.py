"""Monoscopic panoramic camera rendering through six raster views."""

import math

import numpy as np
from mathutils import Matrix


FACE_ROTATIONS = (
    Matrix.Identity(4),
    Matrix.Rotation(math.pi, 4, 'Y'),
    Matrix.Rotation(-math.pi / 2, 4, 'Y'),
    Matrix.Rotation(math.pi / 2, 4, 'Y'),
    Matrix.Rotation(math.pi / 2, 4, 'X'),
    Matrix.Rotation(-math.pi / 2, 4, 'X'),
)


def face_projection(near, far):
    """A 90 degree square perspective projection with Blender's -Z forward."""
    return Matrix((
        (1.0, 0.0, 0.0, 0.0),
        (0.0, 1.0, 0.0, 0.0),
        (0.0, 0.0, -(far + near) / (far - near), -2.0 * far * near / (far - near)),
        (0.0, 0.0, -1.0, 0.0),
    ))


def fisheye_sensor(camera, width, height, pixel_aspect_x=1.0, pixel_aspect_y=1.0):
    """Sensor dimensions in millimeters after Blender's sensor-fit selection."""
    aspect = width * pixel_aspect_x / max(height * pixel_aspect_y, 1e-6)
    fit = camera.sensor_fit
    if fit == 'AUTO':
        fit = 'HORIZONTAL' if aspect >= 1.0 else 'VERTICAL'
    if fit == 'VERTICAL':
        return camera.sensor_height * aspect, camera.sensor_height
    return camera.sensor_width, camera.sensor_width / aspect


def project_point(local, camera, frame_rect, pixel_aspect_x=1.0,
                  pixel_aspect_y=1.0):
    """Project a camera-local point into the panoramic camera frame."""
    x, y, z = local
    distance = math.sqrt(x * x + y * y + z * z)
    if distance < 1e-6:
        return None
    x /= distance
    y /= distance
    z /= distance
    frame_x, frame_y, width, height = frame_rect
    if camera.panorama_type == 'EQUIRECTANGULAR':
        longitude = math.atan2(x, -z)
        latitude = math.asin(max(-1.0, min(1.0, y)))
        longitude_span = camera.longitude_max - camera.longitude_min
        latitude_span = camera.latitude_max - camera.latitude_min
        if abs(longitude_span) < 1e-6 or abs(latitude_span) < 1e-6:
            return None
        u = (longitude - camera.longitude_min) / longitude_span
        v = (latitude - camera.latitude_min) / latitude_span
    elif camera.panorama_type == 'FISHEYE_EQUISOLID':
        theta = math.acos(max(-1.0, min(1.0, -z)))
        if theta > camera.fisheye_fov * 0.5:
            return None
        radius = 2.0 * camera.fisheye_lens * math.sin(theta * 0.5)
        xy = math.hypot(x, y)
        sensor_x, sensor_y = fisheye_sensor(
            camera, width, height, pixel_aspect_x, pixel_aspect_y)
        u = 0.5 + (radius * x / xy if xy > 1e-8 else 0.0) / sensor_x
        v = 0.5 + (radius * y / xy if xy > 1e-8 else 0.0) / sensor_y
    else:
        return None
    if not (0.0 <= u <= 1.0 and 0.0 <= v <= 1.0):
        return None
    return frame_x + u * width, frame_y + v * height


def unproject_direction(x, y, camera, frame_rect, pixel_aspect_x=1.0,
                        pixel_aspect_y=1.0):
    """Camera-local ray through a pixel of the panoramic camera frame."""
    frame_x, frame_y, width, height = frame_rect
    if width <= 0 or height <= 0:
        return None
    u = (x - frame_x) / width
    v = (y - frame_y) / height
    if not (0.0 <= u <= 1.0 and 0.0 <= v <= 1.0):
        return None
    if camera.panorama_type == 'EQUIRECTANGULAR':
        longitude = camera.longitude_min + u * (
            camera.longitude_max - camera.longitude_min)
        latitude = camera.latitude_min + v * (
            camera.latitude_max - camera.latitude_min)
        cosine = math.cos(latitude)
        return (cosine * math.sin(longitude), math.sin(latitude),
                -cosine * math.cos(longitude))
    if camera.panorama_type == 'FISHEYE_EQUISOLID':
        sensor_x, sensor_y = fisheye_sensor(
            camera, width, height, pixel_aspect_x, pixel_aspect_y)
        sx, sy = (u - 0.5) * sensor_x, (v - 0.5) * sensor_y
        radius = math.hypot(sx, sy)
        lens = max(camera.fisheye_lens, 1e-6)
        if radius > min(2.0 * lens * math.sin(camera.fisheye_fov * 0.25),
                        2.0 * lens):
            return None
        theta = 2.0 * math.asin(min(radius / (2.0 * lens), 1.0))
        scale = math.sin(theta) / radius if radius > 1e-8 else 0.0
        return sx * scale, sy * scale, -math.cos(theta)
    return None


def stitch_panorama(faces, width, height, camera, background,
                    pixel_aspect_x=1.0, pixel_aspect_y=1.0):
    """Return bottom-up RGBA pixels, matching Blender's GPU readback layout."""
    size = faces[0].shape[0]
    result = np.empty((height, width, 4), dtype=np.float32)
    # A strip bounds temporary arrays for large final renders.
    fisheye = camera.panorama_type == 'FISHEYE_EQUISOLID'
    if fisheye:
        sensor_width, sensor_height = fisheye_sensor(
            camera, width, height, pixel_aspect_x, pixel_aspect_y)
        sx = ((np.arange(width, dtype=np.float64) + 0.5) / width - 0.5) * sensor_width
        sy = ((np.arange(height, dtype=np.float64) + 0.5) / height - 0.5) * sensor_height
        lens = max(camera.fisheye_lens, 1e-6)
        radius_max = 2.0 * lens * math.sin(camera.fisheye_fov * 0.25)
    else:
        longitude = camera.longitude_min + (np.arange(width, dtype=np.float64) + 0.5) * (
            camera.longitude_max - camera.longitude_min) / width
        sin_lon, cos_lon = np.sin(longitude), np.cos(longitude)
    rotation_axes = [np.asarray(rotation.to_3x3(), dtype=np.float64)
                     for rotation in FACE_ROTATIONS]

    for row_start in range(0, height, 128):
        row_end = min(row_start + 128, height)
        if fisheye:
            y = sy[row_start:row_end, None]
            radius = np.hypot(sx[None, :], y)
            valid = radius <= min(radius_max, 2.0 * lens)
            theta = 2.0 * np.arcsin(np.clip(radius / (2.0 * lens), 0.0, 1.0))
            sine_over_radius = np.sin(theta) / np.maximum(radius, 1e-12)
            direction = np.stack(np.broadcast_arrays(
                sx[None, :] * sine_over_radius,
                y * sine_over_radius,
                -np.cos(theta)), axis=-1)
        else:
            latitude = camera.latitude_min + (np.arange(row_start, row_end, dtype=np.float64) + 0.5) * (
                camera.latitude_max - camera.latitude_min) / height
            cos_lat = np.cos(latitude)[:, None]
            sin_lat = np.sin(latitude)[:, None]
            direction = np.stack(np.broadcast_arrays(
                cos_lat * sin_lon[None, :],
                sin_lat * np.ones((1, width)),
                -cos_lat * cos_lon[None, :]), axis=-1)
            valid = None
        # The face whose forward vector is most parallel to the ray owns it.
        scores = np.stack([-direction @ axes[:, 2] for axes in rotation_axes], axis=-1)
        owner = np.argmax(scores, axis=-1)
        strip = result[row_start:row_end]
        for index, axes in enumerate(rotation_axes):
            rows, columns = np.nonzero(owner == index)
            if not len(rows):
                continue
            local = direction[rows, columns] @ axes
            u = (local[:, 0] / -local[:, 2] + 1.0) * 0.5 * size - 0.5
            v = (local[:, 1] / -local[:, 2] + 1.0) * 0.5 * size - 0.5
            u = np.clip(u, 0.0, size - 1.0)
            v = np.clip(v, 0.0, size - 1.0)
            x0 = np.floor(u).astype(np.intp)
            y0 = np.floor(v).astype(np.intp)
            x1 = np.minimum(x0 + 1, size - 1)
            y1 = np.minimum(y0 + 1, size - 1)
            tx = (u - x0)[:, None]
            ty = (v - y0)[:, None]
            face = faces[index]
            strip[rows, columns] = (
                face[y0, x0] * (1 - tx) * (1 - ty)
                + face[y0, x1] * tx * (1 - ty)
                + face[y1, x0] * (1 - tx) * ty
                + face[y1, x1] * tx * ty)
        if fisheye:
            strip[~valid] = background
    return result


COMPOSITE_FRAGMENT_SHADER = """
uniform sampler2D face_0;
uniform sampler2D face_1;
uniform sampler2D face_2;
uniform sampler2D face_3;
uniform sampler2D face_4;
uniform sampler2D face_5;
uniform int projection_type;
uniform vec4 angular_limits;
uniform vec2 fisheye_sensor_size;
uniform float fisheye_lens;
uniform float fisheye_fov;
uniform vec4 outside_color;
uniform vec2 image_size;
uniform vec2 image_origin;
out vec4 frag_color;

void main() {
    vec2 uv = (gl_FragCoord.xy - image_origin) / image_size;
    vec3 ray;
    if (projection_type == 1) {
        vec2 sensor = (uv - 0.5) * fisheye_sensor_size;
        float r = length(sensor);
        float rmax = 2.0 * fisheye_lens * sin(fisheye_fov * 0.25);
        if (r > rmax || r > 2.0 * fisheye_lens) {
            frag_color = outside_color;
            return;
        }
        float theta = 2.0 * asin(clamp(r / (2.0 * fisheye_lens), 0.0, 1.0));
        ray = vec3(sensor * (sin(theta) / max(r, 1e-8)), -cos(theta));
    } else {
        float lon = mix(angular_limits.x, angular_limits.y, uv.x);
        float lat = mix(angular_limits.z, angular_limits.w, uv.y);
        ray = vec3(cos(lat) * sin(lon), sin(lat), -cos(lat) * cos(lon));
    }
    vec3 absolute_ray = abs(ray);
    vec2 face_uv;
    if (absolute_ray.z >= absolute_ray.x && absolute_ray.z >= absolute_ray.y) {
        if (ray.z < 0.0) {
            face_uv = vec2(ray.x / -ray.z, ray.y / -ray.z) * 0.5 + 0.5;
            frag_color = texture(face_0, face_uv);
        } else {
            face_uv = vec2(-ray.x / ray.z, ray.y / ray.z) * 0.5 + 0.5;
            frag_color = texture(face_1, face_uv);
        }
    } else if (absolute_ray.x >= absolute_ray.y) {
        face_uv = vec2(ray.z / ray.x, ray.y / absolute_ray.x) * 0.5 + 0.5;
        frag_color = ray.x > 0.0 ? texture(face_2, face_uv) : texture(face_3, face_uv);
    } else {
        if (ray.y > 0.0) {
            face_uv = vec2(ray.x / ray.y, ray.z / ray.y) * 0.5 + 0.5;
            frag_color = texture(face_4, face_uv);
        } else {
            face_uv = vec2(-ray.x / ray.y, ray.z / ray.y) * 0.5 + 0.5;
            frag_color = texture(face_5, face_uv);
        }
    }
}
"""
