"""Compile Toon material utility nodes into fragment shader expressions."""

from dataclasses import dataclass
from hashlib import sha1
import time
import bpy


_TIME_START = time.monotonic()


def vertex_color_attribute_id(name):
    return 'toon_attr_' + sha1(name.encode('utf-8')).hexdigest()[:12]


MIX_MODES = (
    'MIX', 'DARKEN', 'MULTIPLY', 'BURN', 'LIGHTEN', 'SCREEN',
    'DODGE', 'ADD', 'OVERLAY', 'SOFT_LIGHT', 'LINEAR_LIGHT',
    'DIFFERENCE', 'EXCLUSION', 'SUBTRACT', 'DIVIDE', 'HUE',
    'SATURATION', 'COLOR', 'VALUE',
)

HELPERS = """
float toon_luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec3 toon_rgb_to_hsv(vec3 c) {
    vec4 k = vec4(0.0, -0.33333333, 0.66666667, -1.0);
    vec4 p = mix(vec4(c.bg, k.wz), vec4(c.gb, k.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + 1e-10)),
                d / (q.x + 1e-10), q.x);
}
vec3 toon_hsv_to_rgb(vec3 c) {
    vec3 p = abs(fract(c.xxx + vec3(0.0, 0.66666667, 0.33333333)) * 6.0 - 3.0);
    return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}
vec4 toon_mix_color(vec4 a, vec4 b, float factor, int mode, bool clamp_result) {
    vec3 x = a.rgb;
    vec3 y = b.rgb;
    vec3 result = y;
    if (mode == 1) result = min(x, y);
    else if (mode == 2) result = x * y;
    else if (mode == 3) result = clamp(1.0 - (1.0 - x) / max(y, vec3(1e-6)), 0.0, 1.0);
    else if (mode == 4) result = max(x, y);
    else if (mode == 5) result = 1.0 - (1.0 - x) * (1.0 - y);
    else if (mode == 6) result = clamp(x / max(1.0 - y, vec3(1e-6)), 0.0, 1.0);
    else if (mode == 7) result = x + y;
    else if (mode == 8) result = mix(2.0 * x * y,
                                      1.0 - 2.0 * (1.0 - x) * (1.0 - y),
                                      step(vec3(0.5), x));
    else if (mode == 9) result = (1.0 - x) * y * x + x * (1.0 - (1.0 - y) * (1.0 - x));
    else if (mode == 10) result = x + 2.0 * y - 1.0;
    else if (mode == 11) result = abs(x - y);
    else if (mode == 12) result = max(x + y - 2.0 * x * y, 0.0);
    else if (mode == 13) result = x - y;
    else if (mode == 14) result = mix(x, x / max(abs(y), vec3(1e-6)), step(vec3(1e-8), abs(y)));
    else if (mode >= 15) {
        vec3 ah = toon_rgb_to_hsv(x);
        vec3 bh = toon_rgb_to_hsv(y);
        float original_sat = ah.y;
        if (mode == 15 || mode == 17) ah.x = bh.x;
        if (mode == 16 || mode == 17) ah.y = bh.y;
        if (mode == 18) ah.z = bh.z;
        result = toon_hsv_to_rgb(ah);
        if ((mode == 15 || mode == 17) && bh.y == 0.0) result = x;
        if (mode == 16 && original_sat == 0.0) result = x;
    }
    float fac = clamp(factor, 0.0, 1.0);
    vec4 mixed = vec4(mix(x, result, fac), a.a);
    if (mode == 3)
        mixed.rgb = clamp(1.0 - (1.0 - x) / max(vec3(1.0 - fac) + fac * y,
                                                vec3(1e-6)), 0.0, 1.0);
    if (mode == 6)
        mixed.rgb = clamp(x / max(1.0 - fac * y, vec3(1e-6)), 0.0, 1.0);
    if (mode == 16 || mode == 18) {
        vec3 ah = toon_rgb_to_hsv(x);
        vec3 bh = toon_rgb_to_hsv(y);
        if (mode == 16 && ah.y > 0.0) {
            ah.y = mix(ah.y, bh.y, fac);
            mixed.rgb = toon_hsv_to_rgb(ah);
        }
        if (mode == 18) {
            ah.z = mix(ah.z, bh.z, fac);
            mixed.rgb = toon_hsv_to_rgb(ah);
        }
    }
    return clamp_result ? clamp(mixed, 0.0, 1.0) : mixed;
}
vec3 toon_map_transform(vec3 p, vec3 location, vec3 rotation, vec3 scale) {
    p *= scale;
    vec3 c = cos(rotation), s = sin(rotation);
    p = vec3(p.x, c.x * p.y - s.x * p.z, s.x * p.y + c.x * p.z);
    p = vec3(c.y * p.x + s.y * p.z, p.y, -s.y * p.x + c.y * p.z);
    p = vec3(c.z * p.x - s.z * p.y, s.z * p.x + c.z * p.y, p.z);
    return p + location;
}
vec2 toon_matcap_uv(vec3 position, vec3 normal, mat4 view) {
    vec3 n = normalize(mat3(view) * normal);
    vec3 eye = normalize(-(view * vec4(position, 1.0)).xyz);
    vec3 reflected = reflect(-eye, n);
    float divisor = 2.0 * max(length(vec3(reflected.xy, reflected.z + 1.0)), 1e-6);
    return reflected.xy / divisor + vec2(0.5);
}
vec4 toon_triplanar(sampler2D tex_sampler, vec3 p, vec3 normal, float sharpness) {
    vec3 weight = pow(abs(normalize(normal)), vec3(sharpness));
    weight /= max(weight.x + weight.y + weight.z, 1e-6);
    return texture(tex_sampler, p.yz) * weight.x
         + texture(tex_sampler, p.xz) * weight.y
         + texture(tex_sampler, p.xy) * weight.z;
}
"""

PROXIMITY_HELPER = """
float toon_proximity_mask(sampler2D proximity_texture, mat4 projection_matrix,
                          vec3 direction, vec3 position, float distance,
                          float bias, float threshold) {
    if (toon_proximity_active == 0) return 1.0;
    vec4 clip = projection_matrix * vec4(position, 1.0);
    vec3 projected = clip.xyz / clip.w * 0.5 + 0.5;
    if (any(lessThan(projected.xy, vec2(0.0))) ||
        any(greaterThan(projected.xy, vec2(1.0)))) return 0.0;
    ivec2 size = textureSize(proximity_texture, 0);
    ivec2 pixel = clamp(ivec2(projected.xy * vec2(size)), ivec2(0), size - ivec2(1));
    vec4 other = texelFetch(proximity_texture, pixel, 0);
    if (other.a <= threshold) return 0.0;
    float separation = dot(position - other.rgb, normalize(direction));
    return separation >= bias && separation <= distance ? other.a : 0.0;
}
"""

Z_DEPTH_HELPER = """
float toon_z_depth_mask(sampler2D other_positions, mat4 camera_matrix,
                        vec3 position, mat4 view, float distance,
                        float expand, float source_alpha_threshold) {
    if (toon_proximity_active == 0) return 0.0;
    vec4 clip = camera_matrix * vec4(position, 1.0);
    if (clip.w <= 0.0) return 0.0;
    vec2 uv = clip.xy / clip.w * 0.5 + 0.5;
    if (any(lessThan(uv, vec2(0.0))) ||
        any(greaterThanEqual(uv, vec2(1.0)))) return 0.0;
    ivec2 size = textureSize(other_positions, 0);
    ivec2 center = clamp(ivec2(uv * vec2(size)), ivec2(0), size - ivec2(1));
    int radius = clamp(int(round(expand)), 0, 8);
    float mask = 0.0;
    for (int y = -8; y <= 8; ++y) {
        if (abs(y) > radius) continue;
        for (int x = -8; x <= 8; ++x) {
            if (abs(x) > radius || x*x + y*y > radius*radius) continue;
            ivec2 pixel = center + ivec2(x, y);
            if (any(lessThan(pixel, ivec2(0))) ||
                any(greaterThanEqual(pixel, size))) continue;
            vec4 other = texelFetch(other_positions, pixel, 0);
            if (other.a <= source_alpha_threshold) continue;
            float separation = abs((view * vec4(position - other.rgb, 0.0)).z);
            mask = max(mask, (1.0 - smoothstep(0.0, distance, separation)) * other.a);
        }
    }
    return mask;
}
"""

BLUR_HELPER = """
vec4 toon_blur_sample(sampler2D source_image, ivec2 origin,
                      float radius, float strength, float sample_count) {
    ivec2 size = textureSize(source_image, 0);
    ivec2 center = clamp(ivec2(gl_FragCoord.xy) - origin,
                         ivec2(0), size - ivec2(1));
    vec4 original = texelFetch(source_image, center, 0);
    if (radius <= 0.0 || strength <= 0.0) return original;
    int half_count = int(sample_count) / 2;
    vec3 total = vec3(0.0);
    float weight_total = 0.0;
    for (int y = -3; y <= 3; ++y) {
        for (int x = -3; x <= 3; ++x) {
            if (abs(x) > half_count || abs(y) > half_count) continue;
            ivec2 pixel = clamp(center + ivec2(round(vec2(x, y) * radius /
                                float(max(half_count, 1)))), ivec2(0), size - ivec2(1));
            vec4 sample_color = texelFetch(source_image, pixel, 0);
            float weight = exp(-2.0 * float(x * x + y * y) /
                               max(sample_count * sample_count, 1.0)) * sample_color.a;
            total += sample_color.rgb * weight;
            weight_total += weight;
        }
    }
    vec3 blurred = weight_total > 1e-6 ? total / weight_total : original.rgb;
    return vec4(mix(original.rgb, blurred, strength), original.a);
}
"""

FLIPBOOK_HELPER = """
vec4 toon_flipbook_sample(sampler2D sheet, vec2 uv, float columns_value,
                          float rows_value, float start_value, float end_value,
                          float frame_value) {
    int columns = max(1, int(columns_value));
    int rows = max(1, int(rows_value));
    int total = columns * rows;
    int first = clamp(int(start_value), 0, total - 1);
    int last = end_value < 0.0 ? total - 1 : clamp(int(end_value), first, total - 1);
    int count = max(1, last - first + 1);
    int frame_index = first + int(mod(floor(frame_value), float(count)));
    int column = frame_index % columns;
    int row = frame_index / columns;
    vec2 image_size = vec2(textureSize(sheet, 0));
    vec2 cell_size = image_size / vec2(columns, rows);
    vec2 cell_origin = vec2(float(column), float(rows - row - 1)) * cell_size;
    vec2 pixel = cell_origin + vec2(0.5) + clamp(uv, vec2(0.0), vec2(1.0))
                 * max(cell_size - vec2(1.0), vec2(0.0));
    return texture(sheet, pixel / image_size);
}
"""


@dataclass
class Graph:
    code: str
    uniforms: dict
    textures: dict
    dynamic_alpha: bool
    needs_lighting: bool
    additive: bool
    uses_shadow_mask: bool
    vertex_attributes: tuple
    uses_proximity: bool
    proximity_filters: dict
    blur_sources: dict
    time_sources: dict
    uses_flipbook: bool
    object_pointer: int = 0
    material_pointer: int = 0

    def bind(self, shader, texture_getter):
        if self.uses_proximity:
            try:
                shader.uniform_int('toon_proximity_active', 0)
            except ValueError:
                pass
        for name, value in self.uniforms.items():
            try:
                if name in self.time_sources:
                    if self.time_sources[name] == 'REALTIME':
                        value = time.monotonic() - _TIME_START
                    else:
                        scene = getattr(bpy.context, 'scene', None)
                        value = ((scene.frame_current + scene.frame_subframe
                                  - scene.frame_start)
                                 * scene.render.fps_base / scene.render.fps) if scene else 0.0
                shader.uniform_float(name, value)
            except ValueError:
                pass  # The alpha-only passes discard color-only uniforms.
        for name, (kind, source) in self.textures.items():
            try:
                shader.uniform_sampler(name, texture_getter(kind, source))
            except ValueError:
                pass


class _Compiler:
    def __init__(self, tree):
        self.indices = {node.as_pointer(): index for index, node in enumerate(tree.nodes)}
        self.uniforms = {}
        self.textures = {}
        self.declarations = {}
        self.uses_shadow_mask = False
        self.uses_proximity = False
        self.proximity_filters = {}
        self.blur_sources = {}
        self.time_sources = {}
        self.uses_flipbook = False
        self.uses_z_depth = False
        self.vertex_attributes = set()

    def _name(self, node, socket):
        return f'graph_{self.indices[node.as_pointer()]}_{list(node.inputs).index(socket)}'

    def _output_name(self, node):
        return f'graph_tex_{self.indices[node.as_pointer()]}'

    def _constant(self, node, socket):
        name = self._name(node, socket)
        value = socket.default_value
        if socket.bl_idname == 'ToonColorSocket':
            self.declarations[name] = f'uniform vec4 {name};'
            self.uniforms[name] = tuple(value)
            return 'color', name
        if socket.bl_idname in {'ToonVectorSocket', 'ToonVector3Socket'}:
            dimension = 3 if socket.bl_idname == 'ToonVector3Socket' else 2
            source_kind = 'vector3' if dimension == 3 else 'vector'
            self.declarations[name] = f'uniform vec{dimension} {name};'
            self.uniforms[name] = tuple(value)
            return source_kind, name
        self.declarations[name] = f'uniform float {name};'
        self.uniforms[name] = float(value)
        return 'float', name

    def input(self, node, name, kind, stack):
        socket = node.inputs[name]
        value = self.output(socket.links[0].from_node,
                            socket.links[0].from_socket, stack) if socket.is_linked else self._constant(node, socket)
        return self.convert(*value, kind)

    @staticmethod
    def convert(source_kind, expression, target):
        if source_kind == 'shader':
            expression = f'vec4(({expression}).rgb * lighting, ({expression}).a)'
            source_kind = 'color'
        if source_kind == target:
            return expression
        if target == 'float':
            if source_kind == 'color':
                return f'toon_luma(({expression}).rgb)'
            return f'(({expression}).x)'
        if target == 'color':
            if source_kind == 'float':
                return f'vec4(vec3({expression}), 1.0)'
            if source_kind == 'vector3':
                return f'vec4({expression}, 1.0)'
            return f'vec4({expression}, 0.0, 1.0)'
        if target == 'vector3':
            if source_kind == 'color':
                return f'({expression}).rgb'
            if source_kind == 'vector':
                return f'vec3({expression}, 0.0)'
            return f'vec3({expression})'
        if source_kind == 'color':
            return f'(({expression}).rg)'
        if source_kind == 'vector3':
            return f'(({expression}).xy)'
        return f'vec2({expression})'

    def output(self, node, socket, stack):
        pointer = node.as_pointer()
        if pointer in stack:
            return ('float', '0.0')
        stack = stack | {pointer}
        kind = node.bl_idname
        output = socket.name
        if kind == 'ToonSurfaceNode':
            if output == 'Alpha':
                return 'float', self.input(node, 'Alpha', 'float', stack)
            return 'shader', self.input(node, 'Color', 'color', stack)
        if kind == 'ToonAdditiveNode':
            return 'shader', self.input(node, 'Color', 'color', stack)
        if kind == 'ToonShaderToRGBNode':
            shader_input = node.inputs['Shader']
            if not shader_input.is_linked:
                return 'color', 'vec4(0.0, 0.0, 0.0, 1.0)'
            source = shader_input.links[0]
            value_kind, expression = self.output(source.from_node, source.from_socket, stack)
            return 'color', self.convert(value_kind, expression, 'color')
        if kind == 'ToonShadowMaskNode':
            self.uses_shadow_mask = True
            self.declarations['toon_shadow_mask_value'] = 'float toon_shadow_mask_value = 0.0;'
            return 'float', 'toon_shadow_mask_value'
        if kind == 'ToonProximityMaskNode':
            self.uses_proximity = True
            index = self.indices[node.as_pointer()]
            sampler_name = f'toon_proximity_texture_{index}'
            self.declarations[sampler_name] = f'uniform sampler2D {sampler_name};'
            selected = (tuple(sorted({item.material.original.as_pointer()
                                      for item in node.materials if item.material}))
                        if node.filter_materials else None)
            direction = tuple(node.projection_direction)
            if sum(component * component for component in direction) < 1e-10:
                direction = (0.0, 0.0, -1.0)
            self.proximity_filters[sampler_name] = (
                selected, direction, int(node.projection_resolution),
                float(node.alpha_threshold), float(node.distance))
            matrix_name = f'toon_proximity_matrix_{index}'
            direction_name = f'toon_proximity_direction_{index}'
            self.declarations[matrix_name] = f'uniform mat4 {matrix_name};'
            self.declarations[direction_name] = f'uniform vec3 {direction_name};'
            self.uniforms[direction_name] = direction
            self.declarations['toon_proximity_active'] = 'uniform int toon_proximity_active;'
            distance_name = f'graph_proximity_distance_{index}'
            threshold_name = f'graph_proximity_threshold_{index}'
            bias_name = f'graph_proximity_bias_{index}'
            self.declarations[distance_name] = f'uniform float {distance_name};'
            self.declarations[threshold_name] = f'uniform float {threshold_name};'
            self.declarations[bias_name] = f'uniform float {bias_name};'
            self.uniforms[distance_name] = node.distance
            self.uniforms[threshold_name] = node.alpha_threshold
            self.uniforms[bias_name] = node.projection_bias
            return 'float', (f'toon_proximity_mask({sampler_name}, {matrix_name}, '
                             f'{direction_name}, world_position, {distance_name}, '
                             f'{bias_name}, {threshold_name})')
        if kind == 'ToonZDepthNode':
            self.uses_proximity = True
            self.uses_z_depth = True
            index = self.indices[node.as_pointer()]
            sampler = f'toon_proximity_texture_{index}'
            matrix = f'toon_proximity_matrix_{index}'
            self.declarations[sampler] = f'uniform sampler2D {sampler};'
            self.declarations[matrix] = f'uniform mat4 {matrix};'
            self.declarations['toon_proximity_active'] = 'uniform int toon_proximity_active;'
            self.proximity_filters[sampler] = (
                None, 'CAMERA', 0, float(node.alpha_threshold), float(node.distance))
            distance = f'graph_z_depth_distance_{index}'
            expand = f'graph_z_depth_expand_{index}'
            threshold = f'graph_z_depth_threshold_{index}'
            for name, value in ((distance, node.distance), (expand, node.expand),
                                (threshold, node.alpha_threshold)):
                self.declarations[name] = f'uniform float {name};'
                self.uniforms[name] = float(value)
            return 'float', (f'toon_z_depth_mask({sampler}, {matrix}, '
                             f'world_position, view_matrix, {distance}, '
                             f'{expand}, {threshold})')
        if kind == 'ToonFresnelNode':
            power = self.input(node, 'Power', 'float', stack)
            facing = ('abs(dot(normalize(world_normal), '
                      'normalize((inverse(view_matrix) * vec4(0.0, 0.0, 0.0, 1.0)).xyz '
                      '- world_position)))')
            return 'float', f'pow(1.0 - clamp({facing}, 0.0, 1.0), max({power}, 0.0))'
        if kind == 'ToonBlurNode':
            index = self.indices[node.as_pointer()]
            sampler = f'toon_blur_texture_{index}'
            radius = f'toon_blur_radius_{index}'
            strength = f'toon_blur_strength_{index}'
            samples = f'toon_blur_samples_{index}'
            self.declarations[sampler] = f'uniform sampler2D {sampler};'
            for name in (radius, strength, samples):
                self.declarations[name] = f'uniform float {name};'
            self.declarations['toon_blur_origin'] = 'uniform ivec2 toon_blur_origin;'
            self.uniforms[radius] = node.radius
            self.uniforms[strength] = node.strength
            self.uniforms[samples] = float(node.samples)
            self.blur_sources[sampler] = node.name
            return 'color', (f'toon_blur_sample({sampler}, toon_blur_origin, '
                             f'{radius}, {strength}, {samples})')
        if kind == 'ToonTimeNode':
            name = f'graph_time_{self.indices[node.as_pointer()]}'
            self.declarations[name] = f'uniform float {name};'
            self.time_sources[name] = node.source
            self.uniforms[name] = 0.0
            return 'float', name
        if kind == 'ToonFlipBookNode':
            if not node.image:
                return ('float', '1.0') if output == 'Alpha' else ('color', 'vec4(1.0)')
            self.uses_flipbook = True
            index = self.indices[node.as_pointer()]
            sampler = f'graph_flipbook_texture_{index}'
            self.declarations[sampler] = f'uniform sampler2D {sampler};'
            self.textures[sampler] = ('IMAGE', node.image)
            parameters = []
            for property_name in ('columns', 'rows', 'start_frame', 'end_frame'):
                name = f'graph_flipbook_{property_name}_{index}'
                self.declarations[name] = f'uniform float {name};'
                self.uniforms[name] = float(getattr(node, property_name))
                parameters.append(name)
            vector = (self.input(node, 'Vector', 'vector3', stack)
                      if node.inputs['Vector'].is_linked else 'vec3(tex_coord, 0.0)')
            frame = self.input(node, 'Frame', 'float', stack)
            columns, rows, start, end = parameters
            sample = (f'toon_flipbook_sample({sampler}, ({vector}).xy, '
                      f'{columns}, {rows}, {start}, {end}, {frame})')
            return ('float', sample + '.a') if output == 'Alpha' else ('color', sample)
        if kind == 'ToonImageTextureNode':
            if not node.image:
                return ('float', '1.0') if output == 'Alpha' else ('color', 'vec4(1.0)')
            name = self._output_name(node)
            self.declarations[name] = f'uniform sampler2D {name};'
            self.textures[name] = ('IMAGE', node.image)
            vector_input = node.inputs.get('Vector')
            if vector_input and vector_input.is_linked:
                source_node = vector_input.links[0].from_node
                vector = self.input(node, 'Vector', 'vector3', stack)
                if (source_node.bl_idname == 'ToonMappingNode'
                        and source_node.mapping_type == 'TRIPLANAR'):
                    sharpness = f'graph_map_blend_{self.indices[source_node.as_pointer()]}'
                    self.declarations[sharpness] = f'uniform float {sharpness};'
                    self.uniforms[sharpness] = source_node.blend
                    sample = f'toon_triplanar({name}, {vector}, local_normal, {sharpness})'
                else:
                    sample = f'texture({name}, ({vector}).xy)'
            else:
                sample = f'texture({name}, tex_coord)'
            return ('float', sample + '.a') if output == 'Alpha' else ('color', sample)
        if kind == 'ToonVertexColorNode':
            if not node.attribute_name:
                return ('float', '1.0') if output == 'Alpha' else ('color', 'vec4(1.0)')
            attribute = vertex_color_attribute_id(node.attribute_name)
            varying = 'toon_vcol_' + attribute
            self.vertex_attributes.add(attribute)
            self.declarations[varying] = f'in vec4 {varying};'
            return ('float', f'{varying}.a') if output == 'Alpha' else ('color', varying)
        if kind == 'ToonObjectColorNode':
            self.declarations['toon_object_color'] = 'uniform vec4 toon_object_color;'
            self.uniforms['toon_object_color'] = (1.0, 1.0, 1.0, 1.0)
            return ('float', 'toon_object_color.a') if output == 'Alpha' else ('color', 'toon_object_color')
        if kind in {'ToonValueNode', 'ToonRGBNode'}:
            return self._constant_output(node, socket)
        if kind == 'ToonUVNode':
            return 'vector', 'tex_coord'
        if kind == 'ToonMappingNode':
            index = self.indices[node.as_pointer()]
            parts = []
            for property_name in ('location', 'rotation', 'scale'):
                name = f'graph_map_{property_name}_{index}'
                self.declarations[name] = f'uniform vec3 {name};'
                self.uniforms[name] = tuple(getattr(node, 'mapping_' + property_name))
                parts.append(name)
            base = {
                'UV': 'vec3(tex_coord, 0.0)',
                'OBJECT': 'local_position',
                'WORLD': 'world_position',
                'TRIPLANAR': 'local_position',
                'MATCAP': 'vec3(toon_matcap_uv(world_position, world_normal, view_matrix), 0.0)',
            }[node.mapping_type]
            if node.inputs['Vector'].is_linked:
                base = self.input(node, 'Vector', 'vector3', stack)
            return 'vector3', f'toon_map_transform({base}, {", ".join(parts)})'
        if kind == 'ToonGradientNode':
            vector = self.input(node, 'Vector', 'vector', stack) if node.inputs['Vector'].is_linked else 'tex_coord'
            scale = self.input(node, 'Scale', 'float', stack)
            uv = f'(({vector}) * ({scale}))'
            shape = {
                'LINEAR': f'({uv}).x',
                'DIAGONAL': f'(({uv}).x + ({uv}).y) * 0.5',
                'RADIAL': f'atan(({uv}).y - 0.5, ({uv}).x - 0.5) / 6.2831853 + 0.5',
                'SPHERICAL': f'length(({uv}) - vec2(0.5)) * 1.41421356',
            }[node.gradient_type]
            return 'float', f'clamp({shape}, 0.0, 1.0)'
        if kind == 'ToonSeparateColorNode':
            color = self.input(node, 'Color', 'color', stack)
            component = {'R': 'r', 'G': 'g', 'B': 'b', 'Alpha': 'a'}.get(output)
            return ('float', f'({color}).{component}') if component else ('float', f'toon_luma(({color}).rgb)')
        if kind == 'ToonCombineColorNode':
            components = [self.input(node, name, 'float', stack) for name in ('R', 'G', 'B', 'Alpha')]
            return 'color', f'vec4({", ".join(components)})'
        if kind == 'ToonMixColorNode':
            factor = self.input(node, 'Factor', 'float', stack)
            a = self.input(node, 'A', 'color', stack)
            b = self.input(node, 'B', 'color', stack)
            mode = MIX_MODES.index(node.blend_type)
            clamp = 'true' if node.clamp_result else 'false'
            return 'color', f'toon_mix_color({a}, {b}, {factor}, {mode}, {clamp})'
        if kind == 'ToonMathNode':
            a = self.input(node, 'Value', 'float', stack)
            b = self.input(node, 'Value 2', 'float', stack)
            expression = {
                'ADD': f'({a} + {b})',
                'SUBTRACT': f'({a} - {b})',
                'MULTIPLY': f'({a} * {b})',
                'DIVIDE': f'({a} / (abs({b}) < 1e-8 ? 1e-8 : {b}))',
                'POWER': f'pow(max({a}, 0.0), {b})',
                'MINIMUM': f'min({a}, {b})',
                'MAXIMUM': f'max({a}, {b})',
                'ABSOLUTE': f'abs({a})',
                'LESS_THAN': f'float({a} < {b})',
                'GREATER_THAN': f'float({a} > {b})',
                'SINE': f'sin({a})',
                'COSINE': f'cos({a})',
                'FLOOR': f'floor({a})',
                'CEIL': f'ceil({a})',
                'FRACT': f'fract({a})',
            }[node.operation]
            return 'float', f'clamp({expression}, 0.0, 1.0)' if node.clamp_result else expression
        if kind == 'ToonMapRangeNode':
            value, minimum, maximum, to_min, to_max = (
                self.input(node, name, 'float', stack)
                for name in ('Value', 'From Min', 'From Max', 'To Min', 'To Max'))
            delta = f'({maximum} - {minimum})'
            ratio = f'(({value} - {minimum}) / (abs({delta}) < 1e-8 ? 1e-8 : {delta}))'
            if node.clamp_result:
                ratio = f'clamp({ratio}, 0.0, 1.0)'
            return 'float', f'mix({to_min}, {to_max}, {ratio})'
        if kind == 'ToonInvertNode':
            factor = self.input(node, 'Factor', 'float', stack)
            color = self.input(node, 'Color', 'color', stack)
            return 'color', f'mix({color}, vec4(1.0 - ({color}).rgb, ({color}).a), clamp({factor}, 0.0, 1.0))'
        if kind == 'ToonColorRampNode':
            if not node.ramp_texture:
                return ('float', '1.0') if output == 'Alpha' else ('color', 'vec4(1.0)')
            factor = self.input(node, 'Fac', 'float', stack)
            name = self._output_name(node)
            self.declarations[name] = f'uniform sampler2D {name};'
            self.textures[name] = ('RAMP', node.ramp_texture)
            sample = f'texture({name}, vec2(clamp({factor}, 0.0, 1.0), 0.5))'
            return ('float', sample + '.a') if output == 'Alpha' else ('color', sample)
        return 'float', '0.0'

    def _constant_output(self, node, socket):
        name = f'graph_out_{self.indices[node.as_pointer()]}'
        if socket.bl_idname == 'ToonColorSocket':
            self.declarations[name] = f'uniform vec4 {name};'
            self.uniforms[name] = tuple(socket.default_value)
            return 'color', name
        self.declarations[name] = f'uniform float {name};'
        self.uniforms[name] = float(socket.default_value)
        return 'float', name


def compile_material(material, output, surface):
    tree = material.toon_tree if material else None
    compiler = _Compiler(tree) if tree else None
    additive = False
    if compiler and output:
        color_input = output.inputs.get('Color')
        alpha_input = output.inputs.get('Alpha')
        color_linked = bool(color_input and color_input.is_linked)
        surface_input = output.inputs.get('Surface')
        surface_source = (surface_input.links[0].from_node
                          if surface_input and surface_input.is_linked else None)
        additive = bool(not color_linked and surface_source
                        and surface_source.bl_idname == 'ToonAdditiveNode')
        if color_linked:
            color = compiler.input(output, 'Color', 'color', set())
        elif additive:
            base = compiler.input(surface_source, 'Color', 'color', set())
            intensity_name = f'graph_additive_intensity_{compiler.indices[surface_source.as_pointer()]}'
            compiler.declarations[intensity_name] = f'uniform float {intensity_name};'
            compiler.uniforms[intensity_name] = surface_source.intensity
            color = f'vec4(({base}).rgb * {intensity_name}, ({base}).a)'
        elif surface:
            base = compiler.input(surface, 'Color', 'color', set())
            color = f'vec4(({base}).rgb * lighting, ({base}).a)'
        elif color_input:
            color = compiler.input(output, 'Color', 'color', set())
        else:
            color = 'vec4(0.8, 0.8, 0.8, 1.0)'
        if additive:
            output_alpha = compiler.input(output, 'Alpha', 'float', set()) if alpha_input else '1.0'
            alpha = f'(({base}).a * {output_alpha})'
            dynamic = True
        elif alpha_input and (alpha_input.is_linked or color_linked or not surface):
            alpha = compiler.input(output, 'Alpha', 'float', set())
            dynamic = alpha_input.is_linked or alpha_input.default_value < 1.0
        elif surface:
            surface_alpha = compiler.input(surface, 'Alpha', 'float', set())
            output_alpha = compiler.input(output, 'Alpha', 'float', set()) if alpha_input else '1.0'
            alpha = f'({surface_alpha} * {output_alpha})'
            dynamic = (surface.inputs['Alpha'].is_linked
                       or surface.inputs['Alpha'].default_value < 1.0
                       or (alpha_input is not None and alpha_input.default_value < 1.0))
        else:
            alpha = '1.0'
            dynamic = False
    else:
        color = 'vec4(graph_fallback_color.rgb * lighting, graph_fallback_color.a)'
        alpha = '1.0'
        dynamic = False
        compiler = _Compiler(tree) if tree else None
        if compiler:
            compiler.declarations['graph_fallback_color'] = 'uniform vec4 graph_fallback_color;'
            compiler.uniforms['graph_fallback_color'] = tuple(material.diffuse_color)
    declarations = compiler.declarations if compiler else {'graph_fallback_color': 'uniform vec4 graph_fallback_color;'}
    uniforms = compiler.uniforms if compiler else {'graph_fallback_color': (0.8, 0.8, 0.8, 1.0)}
    textures = compiler.textures if compiler else {}
    helpers = (HELPERS + (PROXIMITY_HELPER if compiler and compiler.uses_proximity else '')
               + (Z_DEPTH_HELPER if compiler and compiler.uses_z_depth else '')
               + (BLUR_HELPER if compiler and compiler.blur_sources else '')
               + (FLIPBOOK_HELPER if compiler and compiler.uses_flipbook else ''))
    code = '\n'.join(declarations.values()) + '\n' + helpers + '\n' + (
        f'vec4 toon_graph_color(vec3 lighting) {{ return {color}; }}\n'
        f'float toon_graph_alpha(vec3 lighting) {{ return clamp({alpha}, 0.0, 1.0); }}\n')
    uses_shadow_mask = compiler.uses_shadow_mask if compiler else False
    return Graph(code, uniforms, textures,
                 dynamic, 'lighting' in color,
                 additive, uses_shadow_mask,
                 tuple(sorted(compiler.vertex_attributes)) if compiler else (),
                 compiler.uses_proximity if compiler else False,
                 compiler.proximity_filters if compiler else {},
                 compiler.blur_sources if compiler else {},
                 compiler.time_sources if compiler else {},
                 compiler.uses_flipbook if compiler else False)


def compile_blur_source(material, node_name):
    tree = material.toon_tree
    node = tree.nodes[node_name]
    compiler = _Compiler(tree)
    color = compiler.input(node, 'Color', 'color', set())
    helpers = (HELPERS + (PROXIMITY_HELPER if compiler.uses_proximity else '')
               + (Z_DEPTH_HELPER if compiler.uses_z_depth else '')
               + (BLUR_HELPER if compiler.blur_sources else '')
               + (FLIPBOOK_HELPER if compiler.uses_flipbook else ''))
    code = '\n'.join(compiler.declarations.values()) + '\n' + helpers + '\n' + (
        f'vec4 toon_graph_color(vec3 lighting) {{ return {color}; }}\n'
        'float toon_graph_alpha(vec3 lighting) { return 1.0; }\n')
    return Graph(code, compiler.uniforms, compiler.textures,
                 False, 'lighting' in color, False, compiler.uses_shadow_mask,
                 tuple(sorted(compiler.vertex_attributes)), compiler.uses_proximity,
                 compiler.proximity_filters, compiler.blur_sources,
                 compiler.time_sources, compiler.uses_flipbook)


def gpu_texture(kind, source, cache):
    import gpu

    if kind == 'IMAGE':
        key = ('IMAGE', source.as_pointer())
        if key not in cache:
            cache[key] = gpu.texture.from_image(source)
        return cache[key]
    ramp = source.color_ramp
    signature = (ramp.color_mode, ramp.hue_interpolation, ramp.interpolation,
                 tuple((element.position, tuple(element.color)) for element in ramp.elements))
    key = ('RAMP', source.as_pointer())
    cached = cache.get(key)
    if cached is None or cached[0] != signature:
        from gpu.types import Buffer, GPUTexture
        samples = [channel for i in range(512)
                   for channel in ramp.evaluate(i / 511.0)]
        texture = GPUTexture((512, 1), format='RGBA32F',
                             data=Buffer('FLOAT', len(samples), samples))
        cache[key] = (signature, texture)
    return cache[key][1]
