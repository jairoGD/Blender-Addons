bl_info = {
    "name": "Angle Renderer",
    "author": "OpenAI",
    "version": (1, 3, 0),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > Angle Renderer",
    "description": "Render an animation from multiple viewing angles and export animated GIFs or PNG frames (Pillow bundled)",
    "category": "Render",
}

import bpy
import os
import math
import shutil
import tempfile
import sys
import importlib

BUNDLED_PILLOW_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pillow")
BUNDLED_PILLOW_VERSIONS = "3.10 - 3.14"


def _drop_pillow_modules():
    """Forget any PIL module already imported so it can be re-resolved."""
    for module_name in list(sys.modules):
        if module_name == "PIL" or module_name.startswith("PIL."):
            sys.modules.pop(module_name, None)
    importlib.invalidate_caches()


def _import_pillow():
    """
    Import PIL, preferring the copy bundled in ./pillow.

    The bundle ships the compiled modules of every CPython version Blender uses
    (3.10 - 3.14), so each interpreter picks the file matching its own ABI.
    If the bundle is absent or incompatible, fall back to a Pillow installed in
    Blender's own Python environment.
    """
    bundled_pil = os.path.join(BUNDLED_PILLOW_PATH, "PIL")

    if os.path.isdir(bundled_pil):
        loaded = sys.modules.get("PIL")
        loaded_file = getattr(loaded, "__file__", None)
        if loaded_file is None or os.path.normcase(
            os.path.dirname(os.path.abspath(loaded_file))
        ) != os.path.normcase(bundled_pil):
            # A PIL from somewhere else must not shadow the bundled one.
            _drop_pillow_modules()
            if BUNDLED_PILLOW_PATH not in sys.path:
                sys.path.insert(0, BUNDLED_PILLOW_PATH)
            importlib.invalidate_caches()

        try:
            from PIL import Image
            return Image
        except ImportError:
            # Remove a broken/incompatible bundled copy before trying system Pillow.
            while BUNDLED_PILLOW_PATH in sys.path:
                sys.path.remove(BUNDLED_PILLOW_PATH)
            _drop_pillow_modules()

    from PIL import Image
    return Image


def _load_pillow_with_fallback(report):
    """
    Return PIL.Image, installing Pillow with pip as a last resort.

    Returns None (after reporting the error) when no usable Pillow is found.
    """
    try:
        return _import_pillow()
    except ImportError:
        pass

    import subprocess
    import ensurepip

    try:
        report({'INFO'}, "Pillow não encontrado no addon nem no Blender. Preparando instalação...")
        try:
            subprocess.check_call(
                [sys.executable, "-m", "ensurepip", "--upgrade"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
            )
        except Exception:
            ensurepip.bootstrap()
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "Pillow"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            raise RuntimeError((result.stdout or "")[-1000:])
        importlib.invalidate_caches()
        return _import_pillow()
    except Exception as exc:
        report(
            {'ERROR'},
            "Não foi possível usar/instalar Pillow. Verifique a compatibilidade da pasta "
            "'pillow' (versões de Python " + BUNDLED_PILLOW_VERSIONS + ") e a internet/permissões. "
            + str(exc)[:350]
        )
        return None


def _angle_label(angle):
    """Angle formatted for filenames: 0.0 -> '0', 22.5 -> '22.5'."""
    text = f"{float(angle):.6f}".rstrip("0").rstrip(".")
    return text or "0"


def _build_angles(step):
    """
    View angles for a full turn, accepting fractional steps.

    45 -> 0, 45, 90, ... 315     |     22.5 -> 0, 22.5, 45, ... 337.5
    """
    try:
        step = float(step)
    except (TypeError, ValueError):
        step = 45.0
    if not math.isfinite(step) or step <= 0.0:
        step = 45.0
    step = min(step, 360.0)

    count = max(1, int(360.0 / step))
    angles = []
    for index in range(count):
        angle = round(index * step, 6)
        if angle >= 360.0:
            break
        angles.append(angle)
    return angles or [0.0]


class RENDERANGLES_PG_settings(bpy.types.PropertyGroup):
    render_name: bpy.props.StringProperty(
        name="Render Name",
        description="Prefix used for output filenames",
        default="idle",
    )
    pivot_empty: bpy.props.PointerProperty(
        name="Camera Empty",
        description="Empty that parents the camera and acts as the rotation pivot",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'EMPTY',
    )
    output_dir: bpy.props.StringProperty(
        name="Output Folder",
        description="Folder for the GIFs and for the per-angle PNG frame folders; //renders is relative to the .blend file",
        default="//renders",
        subtype='DIR_PATH',
    )
    angle_step: bpy.props.FloatProperty(
        name="Angle Step",
        description="Degrees between views; 45 produces eight views around a full circle. Decimals are allowed (e.g. 22.5)",
        default=45.0,
        min=0.1,
        max=360.0,
        precision=3,
        step=1,
    )
    keep_pngs: bpy.props.BoolProperty(
        name="Keep PNG Frames",
        description="Keep rendered PNG frames alongside the GIF files",
        default=False,
    )
    gif_scale: bpy.props.IntProperty(
        name="GIF Scale (%)",
        description="Resize GIF frames to reduce file size; 100 keeps render resolution",
        default=100,
        min=10,
        max=100,
    )
    transparency_threshold: bpy.props.IntProperty(
        name="Transparency Threshold",
        description="Alpha values below this number become transparent in the GIF; lower values preserve more edge pixels",
        default=128,
        min=0,
        max=255,
    )


class RENDERANGLES_OT_render_base(bpy.types.Operator):
    """
    Shared implementation for both render operators (this class is not registered).

    output_kind decides where the rendered frames go:
      'GIF' -> temporary folder, then assembled into animated GIFs
      'PNG' -> straight into the output folder, one sub-folder per angle
    """

    bl_options = {'REGISTER'}

    output_kind = 'GIF'

    _timer = None
    _angles = None
    _angle_index = 0
    _frame = 0
    _frame_paths = None
    _temp_root = None
    _output_dir = ""
    _name = ""
    _empty = None
    _scene = None
    _settings = None
    _original_frame = 0
    _original_rotation = None
    _original_filepath = ""
    _original_file_format = "PNG"
    _original_use_extension = True
    _original_color_mode = "RGBA"
    _start_frame = 0
    _end_frame = 0
    _duration_ms = 100
    _total_jobs = 0
    _completed_jobs = 0
    _created_gifs = None
    _Image = None
    _error_message = None

    def _restore(self, context):
        scene = self._scene
        if scene is not None:
            try:
                if self._empty is not None and self._original_rotation is not None:
                    self._empty.rotation_euler = self._original_rotation
                scene.frame_set(self._original_frame)
                scene.render.filepath = self._original_filepath
                scene.render.image_settings.file_format = self._original_file_format
                scene.render.image_settings.color_mode = self._original_color_mode
                scene.render.use_file_extension = self._original_use_extension
                context.view_layer.update()
            except Exception:
                pass
        if self._timer is not None:
            try:
                context.window_manager.event_timer_remove(self._timer)
            except Exception:
                pass
            self._timer = None
        if self._temp_root:
            shutil.rmtree(self._temp_root, ignore_errors=True)
            self._temp_root = None
        try:
            context.window_manager.progress_end()
        except Exception:
            pass

    def _set_status(self, context, message):
        try:
            context.workspace.status_text_set(message)
        except Exception:
            pass

    def _angle_dir(self, angle):
        """Folder that receives the PNG frames of one angle."""
        label = _angle_label(angle)
        if self.output_kind == 'GIF':
            return os.path.join(self._temp_root, f"angle_{label}")
        return os.path.join(self._output_dir, f"{self._name}_{label}")

    def _frame_path(self, angle, frame):
        angle_dir = self._angle_dir(angle)
        os.makedirs(angle_dir, exist_ok=True)
        return os.path.join(angle_dir, f"frame_{frame:06d}.png")

    def _finish_angle(self, context, angle):
        """Hook: runs once every frame of an angle has been rendered."""

    def _completion_message(self):
        if self.output_kind == 'GIF':
            return f"Concluído: {len(self._created_gifs)} GIFs criados em {self._output_dir}"
        return (
            f"Concluído: {self._completed_jobs} PNGs em {len(self._angles)} "
            f"pastas de ângulo dentro de {self._output_dir}"
        )

    def _make_gif(self, angle):
        from PIL import Image
        frame_paths = self._frame_paths
        gif_path = os.path.join(self._output_dir, f"{self._name}_{_angle_label(angle)}.gif")
        gif_frames = []
        try:
            for frame_path in frame_paths:
                with Image.open(frame_path) as im:
                    frame_image = im.convert("RGBA")
                    if self._settings.gif_scale != 100:
                        new_size = (
                            max(1, round(frame_image.width * self._settings.gif_scale / 100)),
                            max(1, round(frame_image.height * self._settings.gif_scale / 100)),
                        )
                        frame_image = frame_image.resize(new_size, Image.Resampling.LANCZOS)
                    alpha = frame_image.getchannel("A")
                    quantized = frame_image.convert("RGB").quantize(colors=255)
                    palette = quantized.getpalette()
                    if palette is None:
                        palette = [0] * 768
                    palette = palette[:765] + [255, 0, 255]
                    quantized.putpalette(palette)
                    threshold = self._settings.transparency_threshold
                    alpha_mask = alpha.point(lambda a: 255 if a < threshold else 0)
                    quantized.paste(255, mask=alpha_mask)
                    quantized.info["transparency"] = 255
                    gif_frames.append(quantized.copy())

            if gif_frames:
                gif_frames[0].save(
                    gif_path,
                    save_all=True,
                    append_images=gif_frames[1:],
                    duration=self._duration_ms,
                    loop=0,
                    disposal=2,
                    transparency=255,
                    optimize=False,
                )
                self._created_gifs.append(gif_path)
        finally:
            for image in gif_frames:
                try:
                    image.close()
                except Exception:
                    pass

        if self._settings.keep_pngs:
            png_dir = os.path.join(self._output_dir, f"{self._name}_{_angle_label(angle)}")
            os.makedirs(png_dir, exist_ok=True)
            for frame_path in frame_paths:
                shutil.copy2(frame_path, os.path.join(png_dir, os.path.basename(frame_path)))

    def invoke(self, context, event):
        scene = context.scene
        settings = scene.renderangles_settings
        empty = settings.pivot_empty
        name = settings.render_name.strip()

        if scene.camera is None:
            self.report({'ERROR'}, "A cena não tem uma câmera ativa.")
            return {'CANCELLED'}
        if empty is None or empty.type != 'EMPTY':
            self.report({'ERROR'}, "Selecione o Empty que é pai da câmera.")
            return {'CANCELLED'}
        if not name:
            self.report({'ERROR'}, "Digite um nome para os renders.")
            return {'CANCELLED'}

        Image = None
        if self.output_kind == 'GIF':
            Image = _load_pillow_with_fallback(self.report)
            if Image is None:
                return {'CANCELLED'}
            pillow_root = os.path.dirname(os.path.dirname(os.path.abspath(Image.__file__)))
            pillow_source = (
                "embutido no addon"
                if os.path.normcase(pillow_root) == os.path.normcase(BUNDLED_PILLOW_PATH)
                else "instalação do Blender"
            )
            self.report(
                {'INFO'},
                f"Pillow {getattr(Image, '__version__', '?')} ({pillow_source}), Python {sys.version_info.major}.{sys.version_info.minor}"
            )

        output_dir = bpy.path.abspath(settings.output_dir)
        try:
            os.makedirs(output_dir, exist_ok=True)
        except OSError as exc:
            self.report({'ERROR'}, f"Não foi possível criar a pasta: {exc}")
            return {'CANCELLED'}

        self._scene = scene
        self._settings = settings
        self._empty = empty
        self._name = name
        self._output_dir = output_dir
        self._Image = Image
        self._start_frame = scene.frame_start
        self._end_frame = scene.frame_end
        self._original_frame = scene.frame_current
        self._original_rotation = empty.rotation_euler.copy()
        self._original_filepath = scene.render.filepath
        self._original_file_format = scene.render.image_settings.file_format
        self._original_use_extension = scene.render.use_file_extension
        self._original_color_mode = scene.render.image_settings.color_mode
        self._angles = _build_angles(settings.angle_step)
        fps = scene.render.fps / scene.render.fps_base if scene.render.fps_base else scene.render.fps
        self._duration_ms = max(1, round(1000 / fps)) if fps > 0 else 100
        self._total_jobs = len(self._angles) * (self._end_frame - self._start_frame + 1)
        self._completed_jobs = 0
        self._angle_index = 0
        self._frame = self._start_frame
        self._created_gifs = []
        # GIF mode renders into a scratch folder that is removed afterwards;
        # PNG mode writes straight to the output folder, so there is nothing to clean.
        self._temp_root = (
            tempfile.mkdtemp(prefix="blender_angle_gifs_")
            if self.output_kind == 'GIF'
            else None
        )
        self._frame_paths = []
        self._error_message = None

        scene.render.image_settings.file_format = 'PNG'
        scene.render.use_file_extension = True
        if self.output_kind == 'GIF':
            # GIF transparency needs an alpha channel in the rendered frames.
            scene.render.image_settings.color_mode = 'RGBA'

        context.window_manager.progress_begin(0, max(1, self._total_jobs))
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        self._set_status(context, "Preparando renderização multiângulo...")
        self.report(
            {'INFO'},
            f"Render iniciado ({len(self._angles)} ângulos, saída {self.output_kind}). "
            "O progresso será exibido na barra de status."
        )
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'ESC':
            self._error_message = "Render cancelado pelo usuário."
            self._restore(context)
            self.report({'WARNING'}, self._error_message)
            self._set_status(context, None)
            return {'CANCELLED'}

        if event.type != 'TIMER':
            return {'PASS_THROUGH'}

        try:
            scene = self._scene
            angle = self._angles[self._angle_index]
            angle_text = _angle_label(angle)

            # One rendered frame per timer tick gives Blender a chance to process UI events.
            if self._frame <= self._end_frame:
                if self._frame == self._start_frame and not self._frame_paths:
                    self._empty.rotation_euler.z = (
                        self._original_rotation.z - math.radians(angle)
                    )
                    context.view_layer.update()
                    scene.frame_set(self._start_frame)

                scene.frame_set(self._frame)
                frame_path = self._frame_path(angle, self._frame)
                scene.render.filepath = frame_path
                self._set_status(
                    context,
                    f"Renderizando ângulo {angle_text}° — frame {self._frame}/{self._end_frame} "
                    f"({self._completed_jobs}/{self._total_jobs}) — Esc para cancelar"
                )
                bpy.ops.render.render(write_still=True)
                self._frame_paths.append(frame_path)
                self._completed_jobs += 1
                context.window_manager.progress_update(self._completed_jobs)
                self._frame += 1
                return {'RUNNING_MODAL'}

            # The current angle is complete.
            self._finish_angle(context, angle)

            self._angle_index += 1
            if self._angle_index >= len(self._angles):
                self._restore(context)
                self._set_status(context, None)
                self.report({'INFO'}, self._completion_message())
                return {'FINISHED'}

            self._frame = self._start_frame
            self._frame_paths = []
            return {'RUNNING_MODAL'}

        except Exception as exc:
            self._restore(context)
            self._set_status(context, None)
            self.report({'ERROR'}, f"Render interrompido: {str(exc)[:500]}")
            return {'CANCELLED'}


class RENDERANGLES_OT_render_gifs(RENDERANGLES_OT_render_base):
    bl_idname = "renderangles.render_animation_gifs"
    bl_label = "Render Angles as GIFs"
    bl_description = "Render animation frames for each angle and assemble animated GIFs"
    output_kind = 'GIF'

    def _finish_angle(self, context, angle):
        self._set_status(context, f"Montando GIF do ângulo {_angle_label(angle)}°...")
        self._make_gif(angle)


class RENDERANGLES_OT_render_pngs(RENDERANGLES_OT_render_base):
    bl_idname = "renderangles.render_animation_pngs"
    bl_label = "Render Angles as PNG"
    bl_description = "Render the animation PNG frames for each angle and skip the GIF step"
    output_kind = 'PNG'

    def _finish_angle(self, context, angle):
        self._set_status(
            context,
            f"Ângulo {_angle_label(angle)}° pronto ({self._angle_index + 1}/{len(self._angles)})"
        )


class RENDERANGLES_PT_panel(bpy.types.Panel):
    bl_label = "Angle Renderer"
    bl_idname = "RENDERANGLES_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Angle Renderer"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.renderangles_settings

        layout.label(text="Angle Renderer")
        layout.prop(settings, "render_name")
        layout.prop(settings, "pivot_empty")
        layout.prop(settings, "output_dir")
        layout.prop(settings, "angle_step")
        layout.prop(settings, "gif_scale")
        layout.prop(settings, "transparency_threshold")
        layout.prop(settings, "keep_pngs")

        box = layout.box()
        box.label(text="GIF: name_angle.gif")
        box.label(text="PNG: name_angle/frame_000001.png")
        box.label(text="GIF speed follows scene FPS")
        box.label(text="GIFs loop forever")
        box.label(text=f"Pillow bundled (Python {BUNDLED_PILLOW_VERSIONS})")

        views = len(_build_angles(settings.angle_step))
        frames = max(1, context.scene.frame_end - context.scene.frame_start + 1)
        box.label(
            text=f"{views} views x {frames} frames = {views * frames} renders",
            icon='INFO',
        )

        layout.operator("renderangles.render_animation_gifs", icon='RENDER_ANIMATION')
        layout.operator("renderangles.render_animation_pngs", icon='IMAGE_DATA')


classes = (
    RENDERANGLES_PG_settings,
    RENDERANGLES_OT_render_gifs,
    RENDERANGLES_OT_render_pngs,
    RENDERANGLES_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.renderangles_settings = bpy.props.PointerProperty(
        type=RENDERANGLES_PG_settings
    )


def unregister():
    del bpy.types.Scene.renderangles_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
