"""Small raster render engine for Blender 4.5 and 5.x."""

bl_info = {
    "name": "Toon Render",
    "author": "Toon Render contributors",
    "version": (0, 32, 1),
    "blender": (4, 5, 0),
    "location": "Render Properties > Render Engine; Material Properties; Light Properties; World > Toon Render Post Processing",
    "description": "Raster renderer with Toon materials, per-light shadows and screen-space post effects",
    "category": "Render",
}

import bpy
import importlib
import math
import numpy as np
from bpy.app.handlers import persistent
from mathutils import Matrix, Vector
from bl_ui import (properties_output, properties_world, properties_data_camera, properties_data_mesh,
                   properties_data_curves, properties_data_pointcloud)
from . import toon_nodes, post_effects, shadows, toon_graph, gpu_compat, panorama

# Blender can reload this package after installing a newer ZIP while leaving
# its pure-Python submodules in sys.modules. Keep the panorama shader and camera
# projection code from the same installed version as this engine module.
panorama = importlib.reload(panorama)

_MAX_LIGHTS = 4
_ENGINE_CHANGE_OWNER = object()
_SCENE_ENGINES = {}
_WORLD_VIEWPORT_DRAW = properties_world.WORLD_PT_viewport_display.draw
_PANORAMA_BONE_STATES = {}
_PANORAMA_BONE_KEYMAPS = []
_PANORAMA_OUTLINE_STATES = {}
_PANORAMA_EXTRAS_STATES = {}


def _panorama_camera_frame(context, camera):
    from bpy_extras.view3d_utils import location_3d_to_region_2d

    region = context.region
    view = context.region_data
    corners = [location_3d_to_region_2d(
        region, view, camera.matrix_world @ corner)
        for corner in camera.data.view_frame(scene=context.scene)]
    if any(corner is None for corner in corners):
        return None
    x0 = max(0, math.floor(min(corner.x for corner in corners)))
    y0 = max(0, math.floor(min(corner.y for corner in corners)))
    x1 = min(region.width, math.ceil(max(corner.x for corner in corners)))
    y1 = min(region.height, math.ceil(max(corner.y for corner in corners)))
    if x1 <= x0 or y1 <= y0:
        return None
    return x0, y0, x1 - x0, y1 - y0


def _restore_bone_overlays():
    for space, original in tuple(_PANORAMA_BONE_STATES.values()):
        try:
            space.overlay.show_bones = original
        except ReferenceError:
            pass
    _PANORAMA_BONE_STATES.clear()
    for space, original in tuple(_PANORAMA_OUTLINE_STATES.values()):
        try:
            space.overlay.show_outline_selected = original
        except ReferenceError:
            pass
    _PANORAMA_OUTLINE_STATES.clear()
    for space, original in tuple(_PANORAMA_EXTRAS_STATES.values()):
        try:
            space.overlay.show_extras, space.overlay.show_cursor = original
        except ReferenceError:
            pass
    _PANORAMA_EXTRAS_STATES.clear()


def _bone_overlay_watchdog():
    if not (_PANORAMA_BONE_STATES or _PANORAMA_OUTLINE_STATES
            or _PANORAMA_EXTRAS_STATES):
        return None
    live_bones = set()
    live_outlines = set()
    live_extras = set()
    for window in bpy.context.window_manager.windows:
        scene = window.scene
        active_object = window.view_layer.objects.active
        for area in window.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            space = area.spaces.active
            panoramic = (scene.render.engine == 'TOON_RENDER'
                         and scene.camera is not None
                         and scene.camera.data.type == 'PANO'
                         and scene.camera.data.panorama_type in {
                             'EQUIRECTANGULAR', 'FISHEYE_EQUISOLID'}
                         and space.shading.type == 'RENDERED'
                         and space.region_3d.view_perspective == 'CAMERA')
            if panoramic and (active_object is None or active_object.mode in {'POSE', 'OBJECT'}):
                live_bones.add(space.as_pointer())
            if panoramic and (active_object is None or active_object.mode == 'OBJECT'):
                live_outlines.add(space.as_pointer())
            if panoramic:
                live_extras.add(space.as_pointer())
    for key, (space, original) in tuple(_PANORAMA_BONE_STATES.items()):
        if key not in live_bones:
            try:
                space.overlay.show_bones = original
            except ReferenceError:
                pass
            _PANORAMA_BONE_STATES.pop(key, None)
        elif space.overlay.show_bones:
            space.overlay.show_bones = False
    for key, (space, original) in tuple(_PANORAMA_OUTLINE_STATES.items()):
        if key not in live_outlines:
            try:
                space.overlay.show_outline_selected = original
            except ReferenceError:
                pass
            _PANORAMA_OUTLINE_STATES.pop(key, None)
        elif space.overlay.show_outline_selected:
            space.overlay.show_outline_selected = False
    for key, (space, original) in tuple(_PANORAMA_EXTRAS_STATES.items()):
        if key not in live_extras:
            try:
                space.overlay.show_extras, space.overlay.show_cursor = original
            except ReferenceError:
                pass
            _PANORAMA_EXTRAS_STATES.pop(key, None)
        else:
            if space.overlay.show_extras:
                space.overlay.show_extras = False
            if space.overlay.show_cursor:
                space.overlay.show_cursor = False
    return 0.5 if (_PANORAMA_BONE_STATES or _PANORAMA_OUTLINE_STATES
                   or _PANORAMA_EXTRAS_STATES) else None


def _sync_bone_overlay(space, active):
    key = space.as_pointer()
    if active:
        if key not in _PANORAMA_BONE_STATES and space.overlay.show_bones:
            _PANORAMA_BONE_STATES[key] = (space, True)
            space.overlay.show_bones = False
            if not bpy.app.timers.is_registered(_bone_overlay_watchdog):
                bpy.app.timers.register(_bone_overlay_watchdog, first_interval=0.5)
        return key in _PANORAMA_BONE_STATES
    if key in _PANORAMA_BONE_STATES:
        _, original = _PANORAMA_BONE_STATES.pop(key)
        space.overlay.show_bones = original
    return False


def _sync_outline_overlay(space, active):
    key = space.as_pointer()
    if active:
        if key not in _PANORAMA_OUTLINE_STATES and space.overlay.show_outline_selected:
            _PANORAMA_OUTLINE_STATES[key] = (space, True)
            space.overlay.show_outline_selected = False
            if not bpy.app.timers.is_registered(_bone_overlay_watchdog):
                bpy.app.timers.register(_bone_overlay_watchdog, first_interval=0.5)
        return key in _PANORAMA_OUTLINE_STATES
    if key in _PANORAMA_OUTLINE_STATES:
        _, original = _PANORAMA_OUTLINE_STATES.pop(key)
        space.overlay.show_outline_selected = original
    return False


def _sync_extras_overlay(space, active):
    key = space.as_pointer()
    if active:
        if (key not in _PANORAMA_EXTRAS_STATES
                and (space.overlay.show_extras or space.overlay.show_cursor)):
            _PANORAMA_EXTRAS_STATES[key] = (
                space, (space.overlay.show_extras, space.overlay.show_cursor))
            space.overlay.show_extras = False
            space.overlay.show_cursor = False
            if not bpy.app.timers.is_registered(_bone_overlay_watchdog):
                bpy.app.timers.register(_bone_overlay_watchdog, first_interval=0.5)
        return
    if key in _PANORAMA_EXTRAS_STATES:
        _, original = _PANORAMA_EXTRAS_STATES.pop(key)
        space.overlay.show_extras, space.overlay.show_cursor = original


@persistent
def _toon_save_pre(_dummy):
    # Do not persist the temporary hidden-bones viewport setting in .blend.
    for space, original in _PANORAMA_BONE_STATES.values():
        try:
            space.overlay.show_bones = original
        except ReferenceError:
            pass
    for space, original in _PANORAMA_OUTLINE_STATES.values():
        try:
            space.overlay.show_outline_selected = original
        except ReferenceError:
            pass
    for space, original in _PANORAMA_EXTRAS_STATES.values():
        try:
            space.overlay.show_extras, space.overlay.show_cursor = original
        except ReferenceError:
            pass


@persistent
def _toon_save_post(_dummy):
    for space, _original in _PANORAMA_BONE_STATES.values():
        try:
            space.overlay.show_bones = False
        except ReferenceError:
            pass
    for space, _original in _PANORAMA_OUTLINE_STATES.values():
        try:
            space.overlay.show_outline_selected = False
        except ReferenceError:
            pass
    for space, _original in _PANORAMA_EXTRAS_STATES.values():
        try:
            space.overlay.show_extras = False
            space.overlay.show_cursor = False
        except ReferenceError:
            pass


def _project_pose_bones(context, camera, frame_rect):
    """Yield projected line segments for visible pose bones."""
    camera_inverse = camera.matrix_world.inverted()
    pixel_aspect = (context.scene.render.pixel_aspect_x,
                    context.scene.render.pixel_aspect_y)
    objects = (context.objects_in_mode if context.mode == 'POSE'
               else context.visible_objects)
    armatures = [obj for obj in objects if obj.type == 'ARMATURE']
    for armature in armatures:
        for pose_bone in armature.pose.bones:
            if pose_bone.bone.hide:
                continue
            head = armature.matrix_world @ pose_bone.head
            tail = armature.matrix_world @ pose_bone.tail
            points = []
            for step in range(13):
                position = head.lerp(tail, step / 12.0)
                local = camera_inverse @ position
                points.append(panorama.project_point(
                    local, camera.data, frame_rect, *pixel_aspect))
            segments = []
            for first, second in zip(points, points[1:]):
                if first is None or second is None:
                    continue
                if (camera.data.panorama_type == 'EQUIRECTANGULAR'
                        and abs(first[0] - second[0]) > frame_rect[2] * 0.5):
                    continue
                segments.append((first, second))
            if segments:
                yield armature, pose_bone, segments


def _pose_bone_selected(pose_bone):
    return bool(pose_bone.select if hasattr(pose_bone, 'select')
                else pose_bone.bone.select)


def _set_pose_bone_selected(pose_bone, selected):
    if hasattr(pose_bone, 'select'):
        pose_bone.select = selected
    else:
        pose_bone.bone.select = selected


def _sync_color_management():
    """Use Standard when a scene enters Toon Render, preserving later user edits."""
    scenes = getattr(bpy.data, 'scenes', None)
    if scenes is None:  # Add-on registration runs with Blender's restricted bpy.data.
        return
    current = {}
    for scene in scenes:
        key = scene.as_pointer()
        engine = scene.render.engine
        current[key] = engine
        if engine == 'TOON_RENDER' and _SCENE_ENGINES.get(key) != 'TOON_RENDER':
            scene.view_settings.view_transform = 'Standard'
    _SCENE_ENGINES.clear()
    _SCENE_ENGINES.update(current)


def _deferred_initial_sync():
    if getattr(bpy.data, 'scenes', None) is None:
        return 0.1
    _sync_color_management()
    toon_nodes.ensure_image_vector_inputs()
    toon_nodes.refresh_time_nodes()
    return None


def _subscribe_engine_changes():
    bpy.msgbus.clear_by_owner(_ENGINE_CHANGE_OWNER)
    bpy.msgbus.subscribe_rna(
        key=(bpy.types.RenderSettings, 'engine'),
        owner=_ENGINE_CHANGE_OWNER,
        args=(),
        notify=_sync_color_management,
    )


@persistent
def _toon_load_post(_filepath):
    _SCENE_ENGINES.clear()
    _subscribe_engine_changes()
    _sync_color_management()
    toon_nodes.ensure_image_vector_inputs()
    toon_nodes.refresh_time_nodes()


_OUTPUT_PANELS = (
    properties_output.RENDER_PT_format,
    properties_output.RENDER_PT_frame_range,
    properties_output.RENDER_PT_time_stretching,
    properties_output.RENDER_PT_output,
    properties_output.RENDER_PT_output_color_management,
    properties_output.RENDER_PT_output_pixel_density,
    properties_output.RENDER_PT_encoding,
    properties_output.RENDER_PT_encoding_video,
    properties_output.RENDER_PT_encoding_audio,
)

_DATA_PANELS = tuple(
    panel for module in (properties_data_mesh, properties_data_curves,
                         properties_data_pointcloud)
    for panel in module.classes if hasattr(panel, 'COMPAT_ENGINES')
)

_CAMERA_PANELS = tuple(
    getattr(properties_data_camera, name) for name in (
        'DATA_PT_context_camera',
        'DATA_PT_camera_background_image',
        'DATA_PT_camera_display',
        'DATA_PT_camera_display_composition_guides',
        'DATA_PT_camera_safe_areas',
        'DATA_PT_camera_safe_areas_center_cut',
        'DATA_PT_camera_animation',
        'DATA_PT_custom_props_camera',
    ) if hasattr(properties_data_camera, name)
)


def _draw_world_viewport_display(self, context):
    if context.engine != 'TOON_RENDER':
        _WORLD_VIEWPORT_DRAW(self, context)
        return
    self.layout.use_property_split = True
    self.layout.prop(context.world, 'toon_background_color', text='Background Color')


def _set_world_viewport_draw(draw):
    # Blender captures a panel's draw callback when registering its class.
    bpy.utils.unregister_class(properties_world.WORLD_PT_viewport_display)
    properties_world.WORLD_PT_viewport_display.draw = draw
    bpy.utils.register_class(properties_world.WORLD_PT_viewport_display)


def _update_transparent_png(scene, _context):
    if scene.toon_transparent and scene.render.image_settings.file_format == 'PNG':
        scene.render.image_settings.color_mode = 'RGBA'

_GEOMETRY_FRAGMENT_SHADER = """
uniform float material_alpha;
uniform int alpha_mode;
uniform float alpha_threshold;
uniform mat4 view_matrix;
#ifdef USE_ALPHA_TEXTURE
uniform sampler2D alpha_texture;
#endif
in vec3 world_normal;
in vec3 world_position;
in vec3 local_normal;
in vec3 local_position;
in vec2 tex_coord;
out vec4 frag_color;
void main() {
    float alpha = material_alpha;
#ifdef USE_ALPHA_TEXTURE
    alpha *= texture(alpha_texture, tex_coord).a;
#endif
    if (alpha_mode == 1 && alpha < alpha_threshold) discard;
    if (alpha_mode == 0 && alpha <= alpha_threshold) discard;
    float distance_to_camera = max(-(view_matrix * vec4(world_position, 1.0)).z, 0.0001);
    frag_color = vec4(normalize(world_normal) * 0.5 + 0.5, distance_to_camera);
}
"""

_PROXIMITY_FRAGMENT_SHADER = """
uniform int alpha_mode;
uniform float alpha_threshold;
uniform mat4 view_matrix;
in vec3 world_normal;
in vec3 world_position;
in vec3 local_normal;
in vec3 local_position;
in vec2 tex_coord;
out vec4 frag_color;
void main() {
    float alpha = toon_graph_alpha(vec3(1.0));
    if (alpha_mode == 1 && alpha < alpha_threshold) discard;
    if (alpha_mode == 0 && alpha <= alpha_threshold) discard;
    frag_color = vec4(world_position, alpha);
}
"""

_POST_VERTEX_SHADER = """
in vec2 pos;
void main() {
    gl_Position = vec4(pos, 0.0, 1.0);
}
"""

_VIEWPORT_BLIT_FRAGMENT_SHADER = """
uniform sampler2D source_color;
uniform vec2 viewport_origin;
uniform vec2 viewport_size;
out vec4 frag_color;
void main() {
    vec2 uv = (gl_FragCoord.xy - viewport_origin) / viewport_size;
    frag_color = texture(source_color, uv);
}
"""

_BONE_VERTEX_SHADER = """
in vec2 pos;
uniform vec2 region_size;
void main() {
    gl_Position = vec4(pos / region_size * 2.0 - 1.0, 0.0, 1.0);
}
"""

_BONE_FRAGMENT_SHADER = """
uniform vec4 bone_color;
out vec4 frag_color;
void main() {
    frag_color = bone_color;
}
"""

_OUTLINE_FRAGMENT_SHADER = """
uniform sampler2D source_color;
uniform sampler2D geometry_texture;
uniform sampler2D material_id_texture;
uniform vec3 line_color;
uniform float thickness;
uniform float depth_threshold;
uniform float normal_threshold;
uniform float opacity;
uniform ivec2 target_origin;
out vec4 frag_color;

float edge_at(ivec2 pixel, ivec2 offset, ivec2 size) {
    vec4 center = texelFetch(geometry_texture, pixel, 0);
    vec4 neighbor = texelFetch(geometry_texture,
        clamp(pixel + offset, ivec2(0), size - ivec2(1)), 0);
    if (center.a <= 0.0 && neighbor.a <= 0.0) return 0.0;
    if (center.a <= 0.0 || neighbor.a <= 0.0) return 1.0;
    float depth_change = abs(center.a - neighbor.a) / max(min(center.a, neighbor.a), 0.01);
    vec3 normal_a = normalize(center.rgb * 2.0 - 1.0);
    vec3 normal_b = normalize(neighbor.rgb * 2.0 - 1.0);
    float normal_change = 1.0 - dot(normal_a, normal_b);
    return max(step(depth_threshold, depth_change),
               step(normal_threshold, normal_change));
}

/* MATERIAL_SELECTION */

float edge_for_effect(ivec2 pixel, ivec2 offset, ivec2 size) {
    ivec2 neighbor = clamp(pixel + offset, ivec2(0), size - ivec2(1));
    bool selected_center = selected_material(pixel);
    bool selected_neighbor = selected_material(neighbor);
    if (selected_center != selected_neighbor) return 1.0;
    if (!selected_center) return 0.0;
    return edge_at(pixel, offset, size);
}

void main() {
    ivec2 size = textureSize(source_color, 0);
    ivec2 pixel = clamp(ivec2(gl_FragCoord.xy) - target_origin,
                        ivec2(0), size - ivec2(1));
    int radius = max(1, int(round(thickness)));
    float edge = 0.0;
    edge = max(edge, edge_for_effect(pixel, ivec2(radius, 0), size));
    edge = max(edge, edge_for_effect(pixel, ivec2(-radius, 0), size));
    edge = max(edge, edge_for_effect(pixel, ivec2(0, radius), size));
    edge = max(edge, edge_for_effect(pixel, ivec2(0, -radius), size));
    edge = max(edge, edge_for_effect(pixel, ivec2(radius, radius), size));
    edge = max(edge, edge_for_effect(pixel, ivec2(-radius, radius), size));
    edge = max(edge, edge_for_effect(pixel, ivec2(radius, -radius), size));
    edge = max(edge, edge_for_effect(pixel, ivec2(-radius, -radius), size));
    vec4 source = texelFetch(source_color, pixel, 0);
    float line_alpha = edge * opacity;
    frag_color = vec4(mix(source.rgb, line_color, line_alpha),
                      source.a + line_alpha * (1.0 - source.a));
}
"""


_MOSAIC_FRAGMENT_SHADER = """
uniform sampler2D source_color;
uniform sampler2D material_id_texture;
uniform int pixel_size;
uniform float opacity;
uniform ivec2 target_origin;
out vec4 frag_color;

/* MATERIAL_SELECTION */

void main() {
    ivec2 size = textureSize(source_color, 0);
    ivec2 pixel = clamp(ivec2(gl_FragCoord.xy) - target_origin,
                        ivec2(0), size - ivec2(1));
    vec4 base = texelFetch(source_color, pixel, 0);
    int cell_size = max(pixel_size, 1);
    ivec2 cell_center = clamp((pixel / cell_size) * cell_size + ivec2(cell_size / 2),
                              ivec2(0), size - ivec2(1));
    vec3 mosaic_color = texelFetch(source_color, cell_center, 0).rgb;
    float amount = selected_material(pixel) ? clamp(opacity, 0.0, 1.0) : 0.0;
    frag_color = vec4(mix(base.rgb, mosaic_color, amount), base.a);
}
"""


_VERTEX_SHADER = """
uniform mat4 model_view_projection;
uniform mat4 model_matrix;
in vec3 pos;
in vec3 normal;
in vec2 uv;
out vec3 world_normal;
out vec3 world_position;
out vec3 local_normal;
out vec3 local_position;
out vec2 tex_coord;
void main() {
    gl_Position = model_view_projection * vec4(pos, 1.0);
    world_normal = mat3(transpose(inverse(model_matrix))) * normal;
    world_position = (model_matrix * vec4(pos, 1.0)).xyz;
    local_normal = normal;
    local_position = pos;
    tex_coord = uv;
}
"""

_FRAGMENT_SHADER = """
uniform vec4 base_color;
uniform mat4 view_matrix;
uniform float material_alpha;
uniform int alpha_mode;
uniform float alpha_threshold;
uniform int unlit;
uniform int light_count;
uniform vec4 light_position_type_0;
uniform vec4 light_color_energy_0;
uniform vec4 light_direction_angle_0;
uniform vec4 light_spot_inner_0;
uniform vec4 light_position_type_1;
uniform vec4 light_color_energy_1;
uniform vec4 light_direction_angle_1;
uniform vec4 light_spot_inner_1;
uniform vec4 light_position_type_2;
uniform vec4 light_color_energy_2;
uniform vec4 light_direction_angle_2;
uniform vec4 light_spot_inner_2;
uniform vec4 light_position_type_3;
uniform vec4 light_color_energy_3;
uniform vec4 light_direction_angle_3;
uniform vec4 light_spot_inner_3;
uniform int shadow_enabled_0;
uniform mat4 shadow_matrix_0;
uniform vec4 shadow_settings_0;
uniform sampler2D shadow_map_0_0;
uniform sampler2D shadow_map_0_1;
uniform vec3 shadow_position_0;
uniform int shadow_enabled_1;
uniform mat4 shadow_matrix_1;
uniform vec4 shadow_settings_1;
uniform sampler2D shadow_map_1_0;
uniform sampler2D shadow_map_1_1;
uniform vec3 shadow_position_1;
uniform int shadow_enabled_2;
uniform mat4 shadow_matrix_2;
uniform vec4 shadow_settings_2;
uniform sampler2D shadow_map_2_0;
uniform sampler2D shadow_map_2_1;
uniform vec3 shadow_position_2;
uniform int shadow_enabled_3;
uniform mat4 shadow_matrix_3;
uniform vec4 shadow_settings_3;
uniform sampler2D shadow_map_3_0;
uniform sampler2D shadow_map_3_1;
uniform vec3 shadow_position_3;
#ifdef USE_TEXTURE
uniform sampler2D base_texture;
#endif
#ifdef USE_ALPHA_TEXTURE
uniform sampler2D alpha_texture;
#endif
in vec3 world_normal;
in vec3 world_position;
in vec3 local_normal;
in vec3 local_position;
in vec2 tex_coord;
out vec4 frag_color;
float shadow_visibility(vec3 position, mat4 light_matrix, sampler2D map0,
                        sampler2D map1, vec4 settings) {
    vec4 clip = light_matrix * vec4(position, 1.0);
    vec3 projected = clip.xyz / clip.w * 0.5 + 0.5;
    if (projected.x < 0.0 || projected.x > 1.0 ||
        projected.y < 0.0 || projected.y > 1.0 ||
        projected.z < 0.0 || projected.z > 1.0) return 1.0;
    ivec2 size = textureSize(map0, 0);
    ivec2 center = clamp(ivec2(projected.xy * vec2(size)), ivec2(0), size - ivec2(1));
    int radius = int(round(settings.z));
    float blocked = 0.0;
    int count = 0;
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            if (radius == 0 && (x != 0 || y != 0)) continue;
            ivec2 pixel = clamp(center + ivec2(x, y) * radius, ivec2(0), size - ivec2(1));
            vec4 first = texelFetch(map0, pixel, 0);
            vec4 second = texelFetch(map1, pixel, 0);
            float transmission = 1.0;
            if (first.a > 0.0 && projected.z > first.r + settings.x)
                transmission *= 1.0 - first.g;
            if (second.a > 0.0 && projected.z > second.r + settings.x)
                transmission *= 1.0 - second.g;
            blocked += 1.0 - transmission;
            count++;
        }
    }
    return 1.0 - settings.y * blocked / float(count);
}
ivec2 point_atlas_pixel(vec3 direction, ivec2 atlas_size) {
    vec3 axis = abs(direction);
    float major;
    vec2 face_uv;
    int face;
    if (axis.x >= axis.y && axis.x >= axis.z) {
        major = axis.x;
        face = direction.x >= 0.0 ? 0 : 1;
        face_uv = vec2(direction.x >= 0.0 ? -direction.z : direction.z, -direction.y);
    } else if (axis.y >= axis.z) {
        major = axis.y;
        face = direction.y >= 0.0 ? 2 : 3;
        face_uv = vec2(direction.y >= 0.0 ? direction.x : -direction.x,
                       direction.y >= 0.0 ? direction.z : -direction.z);
    } else {
        major = axis.z;
        face = direction.z >= 0.0 ? 4 : 5;
        face_uv = vec2(direction.z >= 0.0 ? direction.x : -direction.x, -direction.y);
    }
    ivec2 face_size = atlas_size / ivec2(3, 2);
    ivec2 local = clamp(ivec2((face_uv / major * 0.5 + 0.5) * vec2(face_size)),
                        ivec2(0), face_size - ivec2(1));
    return ivec2(face % 3, face / 3) * face_size + local;
}
float point_shadow_visibility(vec3 position, vec3 light_position,
                              sampler2D map0, sampler2D map1, vec4 settings) {
    vec3 delta = position - light_position;
    float distance_to_light = length(delta);
    float receiver_depth = distance_to_light / settings.w;
    if (receiver_depth >= 1.0 || distance_to_light < 0.0001) return 1.0;
    vec3 direction = delta / distance_to_light;
    vec3 helper = abs(direction.z) < 0.9 ? vec3(0.0, 0.0, 1.0) : vec3(0.0, 1.0, 0.0);
    vec3 tangent = normalize(cross(helper, direction));
    vec3 bitangent = cross(direction, tangent);
    ivec2 atlas_size = textureSize(map0, 0);
    float angular_step = settings.z * 2.0 / float(atlas_size.x / 3);
    int radius = settings.z > 0.0 ? 1 : 0;
    float blocked = 0.0;
    int count = 0;
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            if (radius == 0 && (x != 0 || y != 0)) continue;
            vec3 sample_direction = normalize(direction +
                (tangent * float(x) + bitangent * float(y)) * angular_step);
            ivec2 pixel = point_atlas_pixel(sample_direction, atlas_size);
            vec4 first = texelFetch(map0, pixel, 0);
            vec4 second = texelFetch(map1, pixel, 0);
            float transmission = 1.0;
            if (first.a > 0.0 && receiver_depth > first.r + settings.x)
                transmission *= 1.0 - first.g;
            if (second.a > 0.0 && receiver_depth > second.r + settings.x)
                transmission *= 1.0 - second.g;
            blocked += 1.0 - transmission;
            count++;
        }
    }
    return 1.0 - settings.y * blocked / float(count);
}
vec3 shade_light(vec4 position_type, vec4 color_energy,
                 vec4 direction_angle, vec4 spot_inner) {
    vec3 normal = normalize(world_normal);
    vec3 to_light;
    float strength = color_energy.w;
    int light_type = int(position_type.w);
    if (light_type == 0) {
        to_light = normalize(-direction_angle.xyz);
    } else {
        vec3 delta = position_type.xyz - world_position;
        float distance_squared = max(dot(delta, delta), 0.25);
        to_light = normalize(delta);
        float falloff = strength * 0.5 / (12.5663706 * distance_squared);
        strength = falloff / (1.0 + falloff);
        if (light_type == 2) {
            float angle = dot(normalize(direction_angle.xyz), -to_light);
            float outer = direction_angle.w;
            float inner = max(spot_inner.x, outer + 0.0001);
            strength *= smoothstep(outer, inner, angle);
        }
    }
    return color_energy.rgb * (max(dot(normal, to_light), 0.0) * strength);
}
void main() {
    vec4 color = base_color;
#ifdef USE_TEXTURE
    color *= texture(base_texture, tex_coord);
#endif
    float alpha = material_alpha;
#ifdef USE_ALPHA_TEXTURE
    alpha *= texture(alpha_texture, tex_coord).a;
#endif
    if (alpha_mode == 1 && alpha < alpha_threshold) discard;
    if (alpha_mode == 0 && alpha <= alpha_threshold) discard;
    if (alpha_mode == 1) alpha = 1.0;
    vec3 lighting = vec3(1.0);
    if (unlit == 0) {
        lighting = vec3(0.16);
        if (light_count > 0) {
            vec3 contribution = shade_light(light_position_type_0, light_color_energy_0,
                                            light_direction_angle_0, light_spot_inner_0);
            if (shadow_enabled_0 == 1) contribution *= shadow_visibility(
                world_position, shadow_matrix_0, shadow_map_0_0, shadow_map_0_1, shadow_settings_0);
            else if (shadow_enabled_0 == 2) contribution *= point_shadow_visibility(
                world_position, shadow_position_0, shadow_map_0_0, shadow_map_0_1, shadow_settings_0);
            lighting += contribution;
        }
        if (light_count > 1) {
            vec3 contribution = shade_light(light_position_type_1, light_color_energy_1,
                                            light_direction_angle_1, light_spot_inner_1);
            if (shadow_enabled_1 == 1) contribution *= shadow_visibility(
                world_position, shadow_matrix_1, shadow_map_1_0, shadow_map_1_1, shadow_settings_1);
            else if (shadow_enabled_1 == 2) contribution *= point_shadow_visibility(
                world_position, shadow_position_1, shadow_map_1_0, shadow_map_1_1, shadow_settings_1);
            lighting += contribution;
        }
        if (light_count > 2) {
            vec3 contribution = shade_light(light_position_type_2, light_color_energy_2,
                                            light_direction_angle_2, light_spot_inner_2);
            if (shadow_enabled_2 == 1) contribution *= shadow_visibility(
                world_position, shadow_matrix_2, shadow_map_2_0, shadow_map_2_1, shadow_settings_2);
            else if (shadow_enabled_2 == 2) contribution *= point_shadow_visibility(
                world_position, shadow_position_2, shadow_map_2_0, shadow_map_2_1, shadow_settings_2);
            lighting += contribution;
        }
        if (light_count > 3) {
            vec3 contribution = shade_light(light_position_type_3, light_color_energy_3,
                                            light_direction_angle_3, light_spot_inner_3);
            if (shadow_enabled_3 == 1) contribution *= shadow_visibility(
                world_position, shadow_matrix_3, shadow_map_3_0, shadow_map_3_1, shadow_settings_3);
            else if (shadow_enabled_3 == 2) contribution *= point_shadow_visibility(
                world_position, shadow_position_3, shadow_map_3_0, shadow_map_3_1, shadow_settings_3);
            lighting += contribution;
        }
    }
    frag_color = vec4(color.rgb * lighting, alpha);
}
"""


_SHADOW_MASK_FUNCTION = 'float toon_scene_shadow_mask() {\n    float mask = 0.0;\n' + ''.join(
    f'''    if (light_count > {index}) {{
        if (shadow_enabled_{index} == 1)
            mask = max(mask, 1.0 - shadow_visibility(
                world_position, shadow_matrix_{index}, shadow_map_{index}_0,
                shadow_map_{index}_1, shadow_settings_{index}));
        else if (shadow_enabled_{index} == 2)
            mask = max(mask, 1.0 - point_shadow_visibility(
                world_position, shadow_position_{index}, shadow_map_{index}_0,
                shadow_map_{index}_1, shadow_settings_{index}));
    }}
''' for index in range(_MAX_LIGHTS)) + '    return clamp(mask, 0.0, 1.0);\n}\n'


def _graph_fragment(source, graph, compute_shadows=False):
    helpers = graph.code + (_SHADOW_MASK_FUNCTION if compute_shadows and graph.uses_shadow_mask else '')
    source = source.replace('void main() {', helpers + '\nvoid main() {', 1)
    source = source.replace('''    vec4 color = base_color;
#ifdef USE_TEXTURE
    color *= texture(base_texture, tex_coord);
#endif''', '')
    source = source.replace('''    float alpha = material_alpha;
#ifdef USE_ALPHA_TEXTURE
    alpha *= texture(alpha_texture, tex_coord).a;
#endif''', '    float alpha = toon_graph_alpha(vec3(1.0));')
    if compute_shadows and graph.uses_shadow_mask:
        source = source.replace('    float alpha = toon_graph_alpha(vec3(1.0));',
                                '    toon_shadow_mask_value = toon_scene_shadow_mask();\n'
                                '    float alpha = toon_graph_alpha(vec3(1.0));')
    source = source.replace('    frag_color = vec4(color.rgb * lighting, alpha);',
                            '    vec4 color = toon_graph_color(lighting);\n'
                            '    frag_color = vec4(color.rgb, alpha);')
    return source


def _graph_vertex(source, graph):
    if not graph.vertex_attributes:
        return source
    declarations = ''.join(
        f'in vec4 {attribute};\nout vec4 toon_vcol_{attribute};\n'
        for attribute in graph.vertex_attributes)
    assignments = ''.join(
        f'    toon_vcol_{attribute} = {attribute};\n'
        for attribute in graph.vertex_attributes)
    return source.replace('void main() {', declarations + 'void main() {', 1).replace(
        'void main() {', 'void main() {\n' + assignments, 1)


def _mesh_batches(obj, color_attributes=()):
    """Build one vertex buffer and one indexed batch per used material slot."""
    import gpu

    mesh = obj.to_mesh()
    if mesh is None:
        return []
    try:
        mesh.calc_loop_triangles()
        triangle_count = len(mesh.loop_triangles)
        if triangle_count == 0:
            return []
        vertices = np.empty((len(mesh.vertices), 3), dtype=np.float32)
        mesh.vertices.foreach_get('co', vertices.ravel())
        loop_vertex_indices = np.empty(len(mesh.loops), dtype=np.int32)
        mesh.loops.foreach_get('vertex_index', loop_vertex_indices)
        positions = vertices[loop_vertex_indices]
        normals = np.empty((len(mesh.loops), 3), dtype=np.float32)
        mesh.corner_normals.foreach_get('vector', normals.ravel())
        uv_layer = mesh.uv_layers.active
        uvs = np.zeros((len(mesh.loops), 2), dtype=np.float32)
        if uv_layer:
            uv_layer.data.foreach_get('uv', uvs.ravel())
        triangles = np.empty((triangle_count, 3), dtype=np.int32)
        mesh.loop_triangles.foreach_get('loops', triangles.ravel())
        triangle_polygons = np.empty(triangle_count, dtype=np.int32)
        mesh.loop_triangles.foreach_get('polygon_index', triangle_polygons)
        polygon_materials = np.empty(len(mesh.polygons), dtype=np.int32)
        mesh.polygons.foreach_get('material_index', polygon_materials)
        triangle_materials = polygon_materials[triangle_polygons]

        vertex_format = gpu.types.GPUVertFormat()
        vertex_format.attr_add(id='pos', comp_type='F32', len=3, fetch_mode='FLOAT')
        vertex_format.attr_add(id='normal', comp_type='F32', len=3, fetch_mode='FLOAT')
        vertex_format.attr_add(id='uv', comp_type='F32', len=2, fetch_mode='FLOAT')
        color_arrays = {}
        for attribute_id, name in color_attributes:
            attribute = mesh.color_attributes.get(name)
            if attribute and attribute.domain in {'POINT', 'CORNER'}:
                values = np.empty((len(attribute.data), 4), dtype=np.float32)
                attribute.data.foreach_get('color', values.ravel())
                color_arrays[attribute_id] = (
                    values[loop_vertex_indices] if attribute.domain == 'POINT' else values)
            else:
                color_arrays[attribute_id] = np.ones((len(mesh.loops), 4), dtype=np.float32)
            vertex_format.attr_add(id=attribute_id, comp_type='F32', len=4,
                                   fetch_mode='FLOAT')
        vertex_buffer = gpu.types.GPUVertBuf(vertex_format, len(mesh.loops))
        vertex_buffer.attr_fill('pos', positions)
        vertex_buffer.attr_fill('normal', normals)
        vertex_buffer.attr_fill('uv', uvs)
        for attribute_id, values in color_arrays.items():
            vertex_buffer.attr_fill(attribute_id, values)
        return [
            (int(slot), gpu.types.GPUBatch(
                type='TRIS', buf=vertex_buffer,
                elem=gpu.types.GPUIndexBuf(
                    type='TRIS', seq=triangles[triangle_materials == slot])))
            for slot in np.unique(triangle_materials)
        ]
    finally:
        obj.to_mesh_clear()


def _needs_frame_rebuild(obj):
    """Identify meshes whose evaluated vertices can change during playback."""
    source = obj.original
    if source.data.shape_keys or source.data.animation_data:
        return True
    static_modifiers = {'MIRROR', 'BEVEL', 'SOLIDIFY', 'SUBSURF',
                        'TRIANGULATE', 'DECIMATE', 'WELD', 'EDGE_SPLIT',
                        'WEIGHTED_NORMAL'}
    return any(modifier.type not in static_modifiers for modifier in source.modifiers)


def _material_surface(material):
    """Evaluate the small Toon Render graph for a material."""
    if material is None:
        return (toon_graph.compile_material(None, None, None), 'BLEND', 0.001,
                True, 0.0, False, False, True, True)
    tree = material.toon_tree
    output = next((node for node in tree.nodes
                   if node.bl_idname == toon_nodes.ToonMaterialOutputNode.bl_idname), None) if tree else None
    def upstream_surface(node, visited):
        if node.as_pointer() in visited:
            return None
        visited.add(node.as_pointer())
        if node.bl_idname == toon_nodes.ToonSurfaceNode.bl_idname:
            return node
        for socket in node.inputs:
            if socket.is_linked:
                found = upstream_surface(socket.links[0].from_node, visited)
                if found:
                    return found
        return None

    surface = None
    if output:
        source = output.inputs['Surface'].links[0].from_node if output.inputs['Surface'].is_linked else None
        if source and source.bl_idname == toon_nodes.ToonSurfaceNode.bl_idname:
            surface = source
        else:
            surface = upstream_surface(output, set())
    graph = toon_graph.compile_material(material, output, surface)
    if graph.additive:
        return (graph, 'ADDITIVE', 0.001, True, 0.0,
                material.toon_double_sided, True,
                material.toon_cast_shadow, material.toon_receive_shadow)
    if surface:
        method = surface.transparency_method
        return (graph, method, surface.cutout_threshold if method == 'CUTOUT'
                else surface.blend_threshold, surface.transparency_overlap,
                surface.render_priority, material.toon_double_sided,
                material.toon_unlit, material.toon_cast_shadow,
                material.toon_receive_shadow)
    return (graph, 'BLEND', 0.001, True, 0.0,
            material.toon_double_sided, material.toon_unlit,
            material.toon_cast_shadow, material.toon_receive_shadow)


def _scene_lights(depsgraph):
    """Pack Sun, Point and Spot instances for the small forward shader."""
    positions = []
    colors = []
    directions = []
    spot_inner = []
    for instance in depsgraph.object_instances:
        obj = instance.object
        if obj.type != 'LIGHT' or obj.hide_render:
            continue
        light = obj.data
        if light.type not in {'SUN', 'POINT', 'SPOT'}:
            continue
        matrix = instance.matrix_world
        direction = (matrix.to_quaternion() @ Vector((0.0, 0.0, -1.0))).normalized()
        position = matrix.translation
        kind = {'SUN': 0.0, 'POINT': 1.0, 'SPOT': 2.0}[light.type]
        half_angle = light.spot_size * 0.5 if light.type == 'SPOT' else 0.0
        outer = math.cos(half_angle) if light.type == 'SPOT' else 0.0
        inner = math.cos(half_angle * (1.0 - light.spot_blend)) if light.type == 'SPOT' else 0.0
        positions.append((position.x, position.y, position.z, kind))
        colors.append((*light.color, max(0.0, light.energy)))
        directions.append((direction.x, direction.y, direction.z, outer))
        spot_inner.append((inner, 0.0, 0.0, 0.0))
        if len(positions) == _MAX_LIGHTS:
            break
    padding = _MAX_LIGHTS - len(positions)
    return (len(positions),
            positions + [(0.0, 0.0, 0.0, 0.0)] * padding,
            colors + [(0.0, 0.0, 0.0, 0.0)] * padding,
            directions + [(0.0, 0.0, -1.0, 0.0)] * padding,
            spot_inner + [(0.0, 0.0, 0.0, 0.0)] * padding)


class ToonRenderEngine(bpy.types.RenderEngine):
    bl_idname = "TOON_RENDER"
    bl_label = "Toon Render"
    bl_use_preview = False
    bl_use_gpu_context = True
    bl_use_shading_nodes_custom = True

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._shaders = {}
        self._viewport_batches = {}
        self._viewport_batch_frames = {}
        self._viewport_dynamic_keys = set()
        self._viewport_textures = {}
        self._viewport_post_buffers = None
        self._viewport_shadow_buffers = {}
        self._viewport_panorama_buffers = None
        self._viewport_resolution_buffer = None

    def _get_panorama_shader(self):
        key = ('PANORAMA',)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _POST_VERTEX_SHADER, panorama.COMPOSITE_FRAGMENT_SHADER)
        return self._shaders[key]

    def _draw_viewport_blit(self, texture, viewport):
        import gpu
        from gpu_extras.batch import batch_for_shader

        key = ('VIEWPORT_BLIT',)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _POST_VERTEX_SHADER, _VIEWPORT_BLIT_FRAGMENT_SHADER)
        shader = self._shaders[key]
        quad = batch_for_shader(gpu_compat.raw_shader(shader), 'TRIS', {'pos': (
            (-1.0, -1.0), (1.0, -1.0), (1.0, 1.0),
            (-1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))})
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('NONE')
        gpu_compat.bind_shader(shader)
        shader.uniform_sampler('source_color', texture)
        shader.uniform_float('viewport_origin', viewport[:2])
        shader.uniform_float('viewport_size', viewport[2:])
        gpu_compat.draw_batch(quad, shader)

    def _draw_panorama_composite(self, camera_data, faces, width, height,
                                 origin=(0, 0), outside_color=(0, 0, 0, 1),
                                 pixel_aspect=(1.0, 1.0)):
        import gpu
        from gpu_extras.batch import batch_for_shader

        shader = self._get_panorama_shader()
        quad = batch_for_shader(gpu_compat.raw_shader(shader), 'TRIS', {'pos': (
            (-1.0, -1.0), (1.0, -1.0), (1.0, 1.0),
            (-1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))})
        sensor = panorama.fisheye_sensor(camera_data, width, height,
                                        *pixel_aspect)
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('NONE')
        gpu.state.color_mask_set(True, True, True, True)
        gpu_compat.bind_shader(shader)
        for index, offscreen in enumerate(faces):
            shader.uniform_sampler(f'face_{index}', offscreen.texture_color)
        shader.uniform_int('projection_type',
                           int(camera_data.panorama_type == 'FISHEYE_EQUISOLID'))
        shader.uniform_float('angular_limits', (
            camera_data.longitude_min, camera_data.longitude_max,
            camera_data.latitude_min, camera_data.latitude_max))
        shader.uniform_float('fisheye_sensor_size', sensor)
        shader.uniform_float('fisheye_lens', max(camera_data.fisheye_lens, 1e-6))
        shader.uniform_float('fisheye_fov', camera_data.fisheye_fov)
        shader.uniform_float('outside_color', outside_color)
        shader.uniform_float('image_size', (width, height))
        shader.uniform_float('image_origin', origin)
        gpu_compat.draw_batch(quad, shader)

    def _draw_panorama_bones(self, context, camera, frame_rect):
        import gpu
        from gpu_extras.batch import batch_for_shader

        key = ('BONE_LINES',)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _BONE_VERTEX_SHADER, _BONE_FRAGMENT_SHADER)
        shader = self._shaders[key]
        groups = {'NORMAL': [], 'SELECTED': [], 'ACTIVE': []}
        for armature, pose_bone, segments in _project_pose_bones(
                context, camera, frame_rect):
            if context.mode == 'POSE':
                active = armature.data.bones.active
                selected = _pose_bone_selected(pose_bone)
                kind = ('ACTIVE' if selected and active == pose_bone.bone else
                        'SELECTED' if selected else 'NORMAL')
            else:
                kind = ('ACTIVE' if context.active_object == armature else
                        'SELECTED' if armature.select_get() else 'NORMAL')
            for first, second in segments:
                groups[kind].extend((first, second))

        colors = {
            'NORMAL': (0.55, 0.8, 1.0, 0.95),
            'SELECTED': (1.0, 0.48, 0.08, 1.0),
            'ACTIVE': (1.0, 0.9, 0.18, 1.0),
        }
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('ALPHA')
        gpu.state.line_width_set(2.5)
        for kind, positions in groups.items():
            if not positions:
                continue
            batch = batch_for_shader(gpu_compat.raw_shader(shader), 'LINES',
                                     {'pos': positions})
            gpu_compat.bind_shader(shader)
            shader.uniform_float('region_size', (context.region.width,
                                                 context.region.height))
            shader.uniform_float('bone_color', colors[kind])
            gpu_compat.draw_batch(batch, shader)
        gpu.state.line_width_set(1.0)
        gpu.state.blend_set('NONE')

    def _draw_panorama_object_selection(self, context, camera, frame_rect):
        import gpu
        from gpu_extras.batch import batch_for_shader

        selected = [obj for obj in context.selected_objects if obj.visible_get()
                    and obj.type in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT',
                                     'ARMATURE', 'LATTICE'}]
        if not selected:
            return
        key = ('BONE_LINES',)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _BONE_VERTEX_SHADER, _BONE_FRAGMENT_SHADER)
        shader = self._shaders[key]
        inverse = camera.matrix_world.inverted()
        pixel_aspect = (context.scene.render.pixel_aspect_x,
                        context.scene.render.pixel_aspect_y)
        edges = ((0, 1), (1, 2), (2, 3), (3, 0),
                 (4, 5), (5, 6), (6, 7), (7, 4),
                 (0, 4), (1, 5), (2, 6), (3, 7))
        positions = []
        for obj in selected:
            corners = [inverse @ (obj.matrix_world @ Vector(corner))
                       for corner in obj.bound_box]
            for first, second in edges:
                previous = None
                for index in range(13):
                    point = corners[first].lerp(corners[second], index / 12)
                    projected = panorama.project_point(
                        point, camera.data, frame_rect, *pixel_aspect)
                    if previous is not None and projected is not None:
                        # Do not draw a seam-spanning edge across the whole image.
                        if abs(projected[0] - previous[0]) < frame_rect[2] * 0.25:
                            positions.extend((previous, projected))
                    previous = projected
        if not positions:
            return
        batch = batch_for_shader(gpu_compat.raw_shader(shader), 'LINES',
                                 {'pos': positions})
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('ALPHA')
        gpu.state.line_width_set(2.0)
        gpu_compat.bind_shader(shader)
        shader.uniform_float('region_size', (context.region.width,
                                             context.region.height))
        shader.uniform_float('bone_color', (1.0, 0.52, 0.08, 1.0))
        gpu_compat.draw_batch(batch, shader)
        gpu.state.line_width_set(1.0)
        gpu.state.blend_set('NONE')

    def _get_shader(self, graph):
        import gpu

        key = ('MATERIAL', graph.code)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _graph_vertex(_VERTEX_SHADER, graph),
                _graph_fragment(_FRAGMENT_SHADER, graph, compute_shadows=True))
        return self._shaders[key]

    def _get_geometry_shader(self, graph, material_ids=False):
        import gpu

        key = ('MATERIAL_ID' if material_ids else 'GEOMETRY', graph.code)
        if key not in self._shaders:
            source = _graph_fragment(_GEOMETRY_FRAGMENT_SHADER, graph)
            if material_ids:
                source = source.replace('out vec4 frag_color;',
                                        'uniform vec2 material_id;\nout vec4 frag_color;')
                source = source.replace(
                    'frag_color = vec4(normalize(world_normal) * 0.5 + 0.5, distance_to_camera);',
                    'frag_color = vec4(material_id, 0.0, 1.0);')
            self._shaders[key] = gpu_compat.create_shader(
                _graph_vertex(_VERTEX_SHADER, graph), source)
        return self._shaders[key]

    def _get_proximity_shader(self, graph):
        import gpu

        key = ('PROXIMITY', graph.code)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _graph_vertex(_VERTEX_SHADER, graph),
                _graph_fragment(_PROXIMITY_FRAGMENT_SHADER, graph))
        return self._shaders[key]

    @staticmethod
    def _bind_proximity(shader, graph, proximity_buffers):
        if not graph.uses_proximity or not proximity_buffers:
            return
        try:
            shader.uniform_int('toon_proximity_active', 1)
        except ValueError:
            # Color-only proximity nodes are removed from alpha-only passes.
            return
        for sampler_name, specification in graph.proximity_filters.items():
            target, matrix = proximity_buffers[(graph.object_pointer, specification)]
            try:
                shader.uniform_sampler(sampler_name, target.texture_color)
            except ValueError:
                pass
            try:
                shader.uniform_float(sampler_name.replace('texture', 'matrix'), matrix)
            except ValueError:
                pass

    @staticmethod
    def _bind_blur(shader, graph, blur_buffers, origin):
        if not graph.blur_sources or not blur_buffers:
            return
        try:
            shader.uniform_int('toon_blur_origin', origin)
        except ValueError:
            return  # The alpha-only shader does not use a color-only Blur.
        for sampler, node_name in graph.blur_sources.items():
            key = (graph.object_pointer, graph.material_pointer, node_name)
            try:
                shader.uniform_sampler(sampler, blur_buffers[key].texture_color)
            except ValueError:
                pass

    def _draw_blur_buffers(self, depsgraph, view_matrix, projection_matrix,
                           priority_queues, textures, width, height,
                           shadow_maps, proximity_buffers):
        import gpu

        groups = {}
        required = set()
        for queues in priority_queues.values():
            for queue in queues:
                for item in queue:
                    graph = item[5]
                    group = (graph.object_pointer, graph.material_pointer)
                    groups.setdefault(group, []).append(item)
                    required.update((group[0], group[1], node_name)
                                    for node_name in graph.blur_sources.values())
        if not required:
            return {}
        materials = {material.as_pointer(): material for material in bpy.data.materials}
        buffers = {}

        def ensure(key, visiting):
            if key in buffers:
                return
            if key in visiting:
                raise ValueError('Blur nodes cannot form a cycle')
            object_pointer, material_pointer, node_name = key
            material = materials[material_pointer]
            source_graph = toon_graph.compile_blur_source(material, node_name)
            source_graph.object_pointer = object_pointer
            source_graph.material_pointer = material_pointer
            for dependency in source_graph.blur_sources.values():
                ensure((object_pointer, material_pointer, dependency), visiting | {key})
            target = gpu.types.GPUOffScreen(width, height, format='RGBA16F')
            buffers[key] = target
            source_items = []
            for item in groups[(object_pointer, material_pointer)]:
                source_item = list(item)
                source_item[0] = source_graph.code
                source_item[5] = source_graph
                source_item[6] = 'BLEND'
                source_item[7] = 0.0
                source_item[8] = True
                source_item[9] = 0.0
                source_items.append(tuple(source_item))
            with target.bind():
                gpu.state.viewport_set(0, 0, width, height)
                gpu.state.active_framebuffer_get().clear(
                    color=(0.0, 0.0, 0.0, 0.0), depth=1.0)
                self._draw_scene(depsgraph, view_matrix, projection_matrix,
                                 {}, textures, {0.0: (source_items, [])}, shadow_maps,
                                 proximity_buffers=proximity_buffers,
                                 blur_buffers=buffers)

        try:
            for key in required:
                ensure(key, set())
        except Exception:
            for target in buffers.values():
                target.free()
            raise
        return buffers

    def _get_outline_shader(self, selected_ids=None):
        import gpu

        key = ('OUTLINE', selected_ids)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _POST_VERTEX_SHADER,
                _OUTLINE_FRAGMENT_SHADER.replace(
                    '/* MATERIAL_SELECTION */', self._material_selection_code(selected_ids)))
        return self._shaders[key]

    @staticmethod
    def _material_selection_code(selected_ids):
        if selected_ids is None:
            return 'bool selected_material(ivec2 pixel) { return true; }'
        if not selected_ids:
            return 'bool selected_material(ivec2 pixel) { return false; }'
        comparisons = ' || '.join(
            f'all(equal(material_id, ivec2({value % 2048}, {value // 2048})))'
            for value in selected_ids)
        return ('bool selected_material(ivec2 pixel) {\n'
                '    ivec2 material_id = ivec2(texelFetch(material_id_texture, pixel, 0).rg + 0.5);\n'
                f'    return {comparisons};\n}}')

    def _get_mosaic_shader(self, selected_ids=None):
        import gpu

        key = ('MOSAIC', selected_ids)
        if key not in self._shaders:
            self._shaders[key] = gpu_compat.create_shader(
                _POST_VERTEX_SHADER,
                _MOSAIC_FRAGMENT_SHADER.replace(
                    '/* MATERIAL_SELECTION */', self._material_selection_code(selected_ids)))
        return self._shaders[key]

    def view_update(self, context, depsgraph):
        dirty_objects = set()
        dirty_meshes = set()
        armature_changed = False
        clear_all = False
        for update in depsgraph.updates:
            datablock = update.id
            if isinstance(datablock, bpy.types.Image):
                self._viewport_textures.pop(('IMAGE', datablock.as_pointer()), None)
            elif isinstance(datablock, bpy.types.Object):
                if datablock.type == 'MESH' and update.is_updated_geometry:
                    dirty_objects.add(datablock.original.as_pointer())
                elif datablock.type == 'ARMATURE':
                    armature_changed = True
            elif isinstance(datablock, bpy.types.Mesh):
                dirty_meshes.add(datablock.original.as_pointer())
            elif isinstance(datablock, (bpy.types.Armature, bpy.types.Key)):
                armature_changed = True
            elif isinstance(datablock, bpy.types.NodeTree) and update.is_updated_geometry:
                clear_all = True
        if clear_all:
            self._viewport_batches.clear()
        else:
            if dirty_meshes:
                for obj in context.scene.objects:
                    if obj.type == 'MESH' and obj.data.as_pointer() in dirty_meshes:
                        dirty_objects.add(obj.as_pointer())
            if armature_changed:
                dirty_objects.update(self._viewport_dynamic_keys)
            for key in dirty_objects:
                self._viewport_batches.pop(key, None)
        self.tag_redraw()

    def _collect_scene_items(self, depsgraph, view_matrix, cache):
        # Vertex buffers are shared by materials on the mesh, including their
        # requested color attributes.
        # Each priority is a compositing layer. The depth buffer is reset
        # between layers so a higher priority can appear over nearer geometry.
        priority_queues = {}
        viewport_cache = cache is self._viewport_batches
        frame_key = (depsgraph.scene_eval.frame_current,
                     depsgraph.scene_eval.frame_subframe) if viewport_cache else None
        seen_keys = set()
        for instance in depsgraph.object_instances:
            obj = instance.object
            if obj.type != 'MESH' or obj.hide_render:
                continue
            key = obj.original.as_pointer()
            if viewport_cache:
                seen_keys.add(key)
                if _needs_frame_rebuild(obj):
                    self._viewport_dynamic_keys.add(key)
                    if self._viewport_batch_frames.get(key) != frame_key:
                        cache.pop(key, None)
                        self._viewport_batch_frames[key] = frame_key
                else:
                    self._viewport_dynamic_keys.discard(key)
                    self._viewport_batch_frames.pop(key, None)
            materials = [slot.material for slot in obj.material_slots]
            material_graphs = [_material_surface(material) for material in materials]
            blur_graphs = [toon_graph.compile_blur_source(material, node.name)
                           for material in materials if material and material.toon_tree
                           for node in material.toon_tree.nodes
                           if node.bl_idname == 'ToonBlurNode']
            attribute_ids = tuple(sorted({attribute
                for graph in [entry[0] for entry in material_graphs] + blur_graphs
                for attribute in graph.vertex_attributes}))
            attribute_names = {
                toon_graph.vertex_color_attribute_id(node.attribute_name): node.attribute_name
                for material in materials if material and material.toon_tree
                for node in material.toon_tree.nodes
                if node.bl_idname == 'ToonVertexColorNode' and node.attribute_name
            }
            if key not in cache or cache[key][0] != attribute_ids:
                cache[key] = (attribute_ids, _mesh_batches(
                    obj, tuple((attribute, attribute_names[attribute])
                               for attribute in attribute_ids)))
            for slot, batch in cache[key][1]:
                material = obj.material_slots[slot].material if slot < len(obj.material_slots) else None
                graph, method, threshold, overlap, priority, double_sided, unlit, cast_shadow, receive_shadow = (
                    material_graphs[slot] if slot < len(material_graphs)
                    else _material_surface(None))
                if 'toon_object_color' in graph.uniforms:
                    graph.uniforms['toon_object_color'] = tuple(obj.color)
                graph.object_pointer = obj.original.as_pointer()
                graph.material_pointer = material.original.as_pointer() if material else 0
                model = instance.matrix_world.copy()
                item = (graph.code, material.original.as_pointer() if material else 0,
                        (view_matrix @ model.translation).z, model, batch,
                        graph, method, threshold, overlap, priority,
                        double_sided, unlit, cast_shadow, receive_shadow)
                opaque_queue, transparent_queue = priority_queues.setdefault(priority, ([], []))
                if method == 'ADDITIVE' or (method == 'BLEND' and graph.dynamic_alpha):
                    transparent_queue.append(item)
                else:
                    opaque_queue.append(item)
        if viewport_cache:
            for key in cache.keys() - seen_keys:
                cache.pop(key, None)
                self._viewport_dynamic_keys.discard(key)
                self._viewport_batch_frames.pop(key, None)
        for opaque_queue, transparent_queue in priority_queues.values():
            opaque_queue.sort(key=lambda item: (item[0], item[1]))
            transparent_queue.sort(key=lambda item: (item[6] == 'ADDITIVE', item[2]))
        return priority_queues

    def _draw_proximity_buffers(self, depsgraph, view_matrix, projection_matrix,
                                priority_queues, textures, width, height):
        import gpu

        receivers = {(item[5].object_pointer, specification)
                     for queues in priority_queues.values()
                     for queue in queues for item in queue
                     for specification in item[5].proximity_filters.values()}
        materials = {material.as_pointer(): material for material in bpy.data.materials}
        for queues in priority_queues.values():
            for queue in queues:
                for item in queue:
                    graph = item[5]
                    if not graph.blur_sources:
                        continue
                    material = materials.get(graph.material_pointer)
                    if not material or not material.toon_tree:
                        continue
                    for node in material.toon_tree.nodes:
                        if node.bl_idname != 'ToonBlurNode':
                            continue
                        source_graph = toon_graph.compile_blur_source(material, node.name)
                        receivers.update((graph.object_pointer, specification)
                                         for specification in source_graph.proximity_filters.values())
        if not receivers:
            return {}
        buffers = {}
        receiver_bounds = {}
        receiver_ids = {receiver for receiver, _ in receivers}
        for instance in depsgraph.object_instances:
            obj = instance.object
            pointer = obj.original.as_pointer()
            if pointer not in receiver_ids or obj.type != 'MESH':
                continue
            receiver_bounds.setdefault(pointer, []).extend(
                instance.matrix_world @ Vector(corner) for corner in obj.bound_box)

        def get_texture(kind, source):
            return toon_graph.gpu_texture(kind, source, textures)

        try:
            for receiver, specification in receivers:
                selected_materials, direction_values, resolution, alpha_limit, distance = specification
                if direction_values == 'CAMERA':
                    light_matrix = projection_matrix @ view_matrix
                    buffer_width, buffer_height = width, height
                else:
                    direction = Vector(direction_values)
                    if direction.length_squared < 1e-10:
                        direction = Vector((0.0, 0.0, -1.0))
                    direction.normalize()
                    up_hint = (Vector((0.0, 0.0, 1.0)) if abs(direction.z) < 0.9
                               else Vector((0.0, 1.0, 0.0)))
                    right = direction.cross(up_hint).normalized()
                    up = right.cross(direction).normalized()
                    light_view = Matrix(((right.x, right.y, right.z, 0.0),
                                         (up.x, up.y, up.z, 0.0),
                                         (-direction.x, -direction.y, -direction.z, 0.0),
                                         (0.0, 0.0, 0.0, 1.0)))
                    corners = [light_view @ point for point in receiver_bounds[receiver]]
                    minimum = [min(point[axis] for point in corners) for axis in range(3)]
                    maximum = [max(point[axis] for point in corners) for axis in range(3)]
                    center = [(minimum[axis] + maximum[axis]) * 0.5 for axis in range(3)]
                    size = max(maximum[0] - minimum[0], maximum[1] - minimum[1], 0.1) * 1.05
                    depth_span = max(maximum[2] - minimum[2] + 2.0 * distance, 0.2)
                    light_projection = Matrix((
                        (2.0 / size, 0.0, 0.0, -2.0 * center[0] / size),
                        (0.0, 2.0 / size, 0.0, -2.0 * center[1] / size),
                        (0.0, 0.0, -2.0 / depth_span, 2.0 * center[2] / depth_span),
                        (0.0, 0.0, 0.0, 1.0)))
                    light_matrix = light_projection @ light_view
                    buffer_width = buffer_height = resolution
                target = gpu.types.GPUOffScreen(buffer_width, buffer_height, format='RGBA32F')
                buffers[(receiver, specification)] = (target, light_matrix)
                with target.bind():
                    gpu.state.viewport_set(0, 0, buffer_width, buffer_height)
                    gpu.state.active_framebuffer_get().clear(
                        color=(0.0, 0.0, 0.0, 0.0), depth=1.0)
                    gpu.state.depth_test_set('LESS_EQUAL')
                    gpu.state.depth_mask_set(True)
                    gpu.state.blend_set('NONE')
                    for opaque_queue, transparent_queue in priority_queues.values():
                        for item in opaque_queue + transparent_queue:
                            _, material_pointer, _, model, batch, graph, method, threshold, _, _, double_sided, _, _, _ = item
                            if graph.object_pointer == receiver:
                                continue
                            if (selected_materials is not None
                                    and material_pointer not in selected_materials):
                                continue
                            gpu.state.face_culling_set('NONE' if double_sided else 'BACK')
                            shader = self._get_proximity_shader(graph)
                            gpu_compat.bind_shader(shader)
                            shader.uniform_float('model_view_projection',
                                                 light_matrix @ model)
                            try:
                                shader.uniform_float('model_matrix', model)
                            except ValueError:
                                pass
                            try:
                                shader.uniform_float('view_matrix', view_matrix)
                            except ValueError:
                                pass
                            graph.bind(shader, get_texture)
                            shader.uniform_int('alpha_mode', 1 if method == 'CUTOUT' else 0)
                            shader.uniform_float('alpha_threshold', max(threshold, alpha_limit))
                            gpu_compat.draw_batch(batch, shader)
        except Exception:
            for target, _ in buffers.values():
                target.free()
            raise
        finally:
            gpu.state.depth_mask_set(False)
            gpu.state.depth_test_set('NONE')
            gpu.state.face_culling_set('NONE')
        return buffers

    def _draw_scene(self, depsgraph, view_matrix, projection_matrix, cache, textures,
                    priority_queues=None, shadow_maps=None, transparent_background=False,
                    proximity_buffers=None, blur_buffers=None, blur_origin=(0, 0)):
        import gpu

        if priority_queues is None:
            priority_queues = self._collect_scene_items(depsgraph, view_matrix, cache)
        if shadow_maps is None:
            shadow_maps = {}
        if proximity_buffers is None:
            proximity_buffers = {}
        if blur_buffers is None:
            blur_buffers = {}
        light_count, light_positions, light_colors, light_directions, light_inner = _scene_lights(depsgraph)

        def get_texture(kind, source):
            return toon_graph.gpu_texture(kind, source, textures)

        try:
            gpu.state.depth_test_set('LESS_EQUAL')
            gpu.state.depth_mask_set(True)
            gpu.state.blend_set('NONE')
            gpu.state.face_culling_set('NONE')
            lit_shaders = set()
            for layer_index, priority in enumerate(sorted(priority_queues)):
                opaque_queue, transparent_queue = priority_queues[priority]
                gpu.state.depth_mask_set(True)
                gpu.state.depth_test_set('LESS_EQUAL')
                gpu.state.blend_set('NONE')
                if layer_index:
                    gpu.state.active_framebuffer_get().clear(depth=1.0)
                for index, item in enumerate(opaque_queue + transparent_queue):
                    if index == len(opaque_queue):
                        gpu.state.depth_mask_set(False)
                        gpu.state.blend_set('ALPHA')
                    shader_key, _, _, model, batch, graph, method, threshold, overlap, _priority, double_sided, unlit, _, receive_shadow = item
                    if method == 'ADDITIVE':
                        gpu.state.blend_set('ADDITIVE')
                    gpu.state.face_culling_set('NONE' if double_sided else 'BACK')
                    shader = self._get_shader(graph)
                    gpu_compat.bind_shader(shader)
                    if shader_key not in lit_shaders and (graph.needs_lighting or graph.uses_shadow_mask):
                        shader.uniform_int('light_count', light_count)
                        for light_index in range(_MAX_LIGHTS):
                            if graph.needs_lighting:
                                shader.uniform_float(f'light_position_type_{light_index}', light_positions[light_index])
                                shader.uniform_float(f'light_color_energy_{light_index}', light_colors[light_index])
                                shader.uniform_float(f'light_direction_angle_{light_index}', light_directions[light_index])
                                shader.uniform_float(f'light_spot_inner_{light_index}', light_inner[light_index])
                            shadow = shadow_maps.get(light_index)
                            if shadow:
                                kind, light_matrix, buffers, light, position = shadow
                                shader.uniform_float(f'shadow_settings_{light_index}', (
                                    light.toon_shadow_bias, light.toon_shadow_strength,
                                    light.toon_shadow_softness,
                                    light.toon_shadow_distance if kind == 'POINT'
                                    else float(buffers[0].width)))
                                if kind == 'POINT':
                                    shader.uniform_float(f'shadow_position_{light_index}', position)
                                    shader.uniform_sampler(f'shadow_map_{light_index}_0', buffers[0])
                                    shader.uniform_sampler(f'shadow_map_{light_index}_1', buffers[1])
                                else:
                                    shader.uniform_float(f'shadow_matrix_{light_index}', light_matrix)
                                    shader.uniform_sampler(f'shadow_map_{light_index}_0',
                                                           buffers[0].texture_color)
                                    shader.uniform_sampler(f'shadow_map_{light_index}_1',
                                                           buffers[1].texture_color)
                        lit_shaders.add(shader_key)
                    if graph.needs_lighting or graph.uses_shadow_mask:
                        for light_index in range(_MAX_LIGHTS):
                            shadow = shadow_maps.get(light_index) if receive_shadow else None
                            shader.uniform_int(f'shadow_enabled_{light_index}',
                                               2 if shadow and shadow[0] == 'POINT'
                                               else 1 if shadow else 0)
                    shader.uniform_float('model_view_projection', projection_matrix @ view_matrix @ model)
                    shader.uniform_float('model_matrix', model)
                    try:
                        shader.uniform_float('view_matrix', view_matrix)
                    except ValueError:
                        pass
                    graph.bind(shader, get_texture)
                    self._bind_proximity(shader, graph, proximity_buffers)
                    self._bind_blur(shader, graph, blur_buffers, blur_origin)
                    shader.uniform_int('alpha_mode', 1 if method == 'CUTOUT' else 0)
                    shader.uniform_float('alpha_threshold', threshold)
                    if graph.needs_lighting:
                        shader.uniform_int('unlit', 1 if unlit else 0)
                    if method == 'BLEND' and not overlap and index >= len(opaque_queue):
                        gpu.state.blend_set('NONE')
                        gpu.state.color_mask_set(False, False, False, False)
                        gpu.state.depth_mask_set(True)
                        gpu_compat.draw_batch(batch, shader)
                        gpu.state.color_mask_set(True, True, True, True)
                        gpu.state.depth_mask_set(False)
                        gpu.state.depth_test_set('EQUAL')
                        gpu.state.blend_set('ALPHA')
                        gpu_compat.draw_batch(batch, shader)
                        gpu.state.depth_test_set('LESS_EQUAL')
                    else:
                        gpu_compat.draw_batch(batch, shader)
                    if method == 'ADDITIVE' and transparent_background:
                        gpu.state.color_mask_set(False, False, False, True)
                        gpu.state.blend_set('ALPHA')
                        gpu_compat.draw_batch(batch, shader)
                        gpu.state.color_mask_set(True, True, True, True)
                        gpu.state.blend_set('ADDITIVE')
        finally:
            gpu.state.color_mask_set(True, True, True, True)
            gpu.state.blend_set('NONE')
            gpu.state.depth_mask_set(False)
            gpu.state.depth_test_set('NONE')
            gpu.state.face_culling_set('NONE')

    def _draw_scene_shadows(self, depsgraph, view_matrix, projection_matrix,
                            cache, textures, width, height, viewport=False,
                            output_offscreen=None, transparent_background=False,
                            retain_proximity=False):
        import gpu

        priority_queues = self._collect_scene_items(depsgraph, view_matrix, cache)
        framebuffer = gpu.state.active_framebuffer_get()
        target_viewport = gpu.state.viewport_get()
        if target_viewport[2] == 0 or target_viewport[3] == 0:
            target_viewport = (0, 0, width, height)
        if viewport and not depsgraph.scene_eval.toon_viewport_shadows:
            shadow_maps, transient = {}, []
        else:
            shadow_maps, transient = shadows.render_shadow_maps(
                self, depsgraph, view_matrix, priority_queues, textures, viewport)
        proximity_buffers = {}
        blur_buffers = {}
        world = depsgraph.scene_eval.world
        background = tuple(world.toon_background_color) if world else (0.05, 0.05, 0.05)
        clear_color = ((0.0, 0.0, 0.0, 0.0) if transparent_background
                       else (*background, 1.0))
        completed = False
        try:
            proximity_buffers = self._draw_proximity_buffers(
                depsgraph, view_matrix, projection_matrix, priority_queues,
                textures, width, height)
            blur_buffers = self._draw_blur_buffers(
                depsgraph, view_matrix, projection_matrix, priority_queues,
                textures, width, height, shadow_maps, proximity_buffers)
            if shadow_maps or proximity_buffers or blur_buffers:
                binding = output_offscreen.bind() if output_offscreen else framebuffer.bind()
                with binding:
                    gpu.state.viewport_set(*target_viewport)
                    gpu.state.active_framebuffer_get().clear(
                        color=clear_color, depth=1.0)
                    self._draw_scene(depsgraph, view_matrix, projection_matrix,
                                     cache, textures, priority_queues, shadow_maps,
                                     transparent_background, proximity_buffers,
                                     blur_buffers, target_viewport[:2])
            else:
                gpu.state.viewport_set(*target_viewport)
                framebuffer.clear(color=clear_color, depth=1.0)
                self._draw_scene(depsgraph, view_matrix, projection_matrix,
                                 cache, textures, priority_queues,
                                 transparent_background=transparent_background,
                                 proximity_buffers=proximity_buffers,
                                 blur_buffers=blur_buffers,
                                 blur_origin=target_viewport[:2])
            completed = True
        finally:
            for offscreen in transient:
                offscreen.free()
            if not retain_proximity or not completed:
                for offscreen, _ in proximity_buffers.values():
                    offscreen.free()
                for offscreen in blur_buffers.values():
                    offscreen.free()
        return ((priority_queues, proximity_buffers, blur_buffers)
                if retain_proximity else priority_queues)

    def _draw_geometry(self, view_matrix, projection_matrix, priority_queues,
                       textures, material_ids=None, occlusion_alpha_threshold=None,
                       selected_material_pointers=(), proximity_buffers=None,
                       blur_buffers=None):
        import gpu

        def get_texture(kind, source):
            return toon_graph.gpu_texture(kind, source, textures)

        try:
            gpu.state.depth_test_set('LESS_EQUAL')
            gpu.state.depth_mask_set(True)
            gpu.state.blend_set('NONE')
            gpu.state.face_culling_set('NONE')
            for layer_index, priority in enumerate(sorted(priority_queues)):
                if layer_index:
                    gpu.state.active_framebuffer_get().clear(depth=1.0)
                opaque_queue, transparent_queue = priority_queues[priority]
                for item in opaque_queue + transparent_queue:
                    _, material_pointer, _, model, batch, graph, method, threshold, _, _, double_sided, _, _, _ = item
                    gpu.state.face_culling_set('NONE' if double_sided else 'BACK')
                    shader = self._get_geometry_shader(graph, material_ids is not None)
                    gpu_compat.bind_shader(shader)
                    shader.uniform_float('model_view_projection', projection_matrix @ view_matrix @ model)
                    try:
                        shader.uniform_float('model_matrix', model)
                    except ValueError:
                        pass
                    try:
                        shader.uniform_float('view_matrix', view_matrix)
                    except ValueError:
                        pass
                    if material_ids is not None:
                        material_id = material_ids[material_pointer]
                        shader.uniform_float('material_id',
                                             (float(material_id % 2048),
                                              float(material_id // 2048)))
                    graph.bind(shader, get_texture)
                    self._bind_proximity(shader, graph, proximity_buffers)
                    self._bind_blur(shader, graph, blur_buffers, (0, 0))
                    shader.uniform_int('alpha_mode', 1 if method == 'CUTOUT' else 0)
                    effective_threshold = threshold
                    if (occlusion_alpha_threshold is not None
                            and method in {'BLEND', 'ADDITIVE'}
                            and material_pointer not in selected_material_pointers):
                        effective_threshold = max(threshold, min(occlusion_alpha_threshold, 0.999))
                    shader.uniform_float('alpha_threshold', effective_threshold)
                    gpu_compat.draw_batch(batch, shader)
        finally:
            gpu.state.depth_mask_set(False)
            gpu.state.depth_test_set('NONE')
            gpu.state.face_culling_set('NONE')

    def _draw_outline(self, source_texture, geometry_texture, effect,
                      origin=(0, 0), material_id_texture=None, selected_ids=None):
        import gpu
        from gpu_extras.batch import batch_for_shader

        shader = self._get_outline_shader(selected_ids)
        quad = batch_for_shader(gpu_compat.raw_shader(shader), 'TRIS', {'pos': (
            (-1.0, -1.0), (1.0, -1.0), (1.0, 1.0),
            (-1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))})
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('NONE')
        gpu.state.color_mask_set(True, True, True, True)
        gpu_compat.bind_shader(shader)
        shader.uniform_sampler('source_color', source_texture)
        if selected_ids == ():
            shader.uniform_int('target_origin', origin)
            gpu_compat.draw_batch(quad, shader)
            return
        shader.uniform_sampler('geometry_texture', geometry_texture)
        if selected_ids:
            shader.uniform_sampler('material_id_texture', material_id_texture)
        shader.uniform_float('line_color', effect.color)
        shader.uniform_float('thickness', effect.thickness)
        shader.uniform_float('depth_threshold', effect.depth_threshold)
        shader.uniform_float('normal_threshold', effect.normal_threshold)
        shader.uniform_float('opacity', effect.opacity)
        shader.uniform_int('target_origin', origin)
        gpu_compat.draw_batch(quad, shader)

    def _draw_mosaic(self, source_texture, effect, origin=(0, 0),
                     material_id_texture=None, selected_ids=None):
        import gpu
        from gpu_extras.batch import batch_for_shader

        shader = self._get_mosaic_shader(selected_ids)
        quad = batch_for_shader(gpu_compat.raw_shader(shader), 'TRIS', {'pos': (
            (-1.0, -1.0), (1.0, -1.0), (1.0, 1.0),
            (-1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))})
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set('NONE')
        gpu.state.color_mask_set(True, True, True, True)
        gpu_compat.bind_shader(shader)
        shader.uniform_sampler('source_color', source_texture)
        shader.uniform_int('target_origin', origin)
        if selected_ids != ():
            if selected_ids:
                shader.uniform_sampler('material_id_texture', material_id_texture)
            shader.uniform_int('pixel_size', effect.pixel_size)
            shader.uniform_float('opacity', effect.opacity)
        gpu_compat.draw_batch(quad, shader)

    def _draw_post_effect(self, source_texture, geometry_texture, effect,
                          origin=(0, 0), material_id_texture=None, selected_ids=None):
        if effect.effect_type == 'MOSAIC':
            self._draw_mosaic(source_texture, effect, origin,
                              material_id_texture, selected_ids)
        else:
            self._draw_outline(source_texture, geometry_texture, effect, origin,
                               material_id_texture, selected_ids)

    def _draw_with_effects(self, depsgraph, view_matrix, projection_matrix,
                           cache, textures, width, height, effects, viewport=False,
                           output_offscreen=None, transparent_background=False):
        import gpu

        # On Vulkan, creating a GPUOffScreen can change the active framebuffer.
        # Capture the destination before allocating intermediate passes.
        target_framebuffer = gpu.state.active_framebuffer_get()
        target_viewport = gpu.state.viewport_get()

        def selected_pointers(effect):
            if not effect.limit_to_materials:
                return ()
            return tuple(sorted({item.material.original.as_pointer()
                                 for item in effect.materials if item.material}))

        effect_selections = [selected_pointers(effect) for effect in effects]
        geometry_keys = list(dict.fromkeys(
            (effect.occlusion_alpha_threshold, effect_selections[index])
            for index, effect in enumerate(effects)
            if effect.effect_type == 'OUTLINE'))
        id_keys = []
        for index, effect in enumerate(effects):
            if effect_selections[index]:
                key = (effect.occlusion_alpha_threshold, effect_selections[index])
                if key not in id_keys:
                    id_keys.append(key)
        count = (1 + len(geometry_keys) + len(id_keys)
                 + min(2, max(0, len(effects) - 1)))
        size_key = (width, height, count, len(geometry_keys), len(id_keys))
        if viewport and self._viewport_post_buffers and self._viewport_post_buffers[0] != size_key:
            for offscreen in self._viewport_post_buffers[1]:
                offscreen.free()
            self._viewport_post_buffers = None
        if viewport and self._viewport_post_buffers:
            buffers = self._viewport_post_buffers[1]
        else:
            buffers = [gpu.types.GPUOffScreen(width, height, format='RGBA16F')
                       for _ in range(count)]
            if viewport:
                self._viewport_post_buffers = (size_key, buffers)
        scene_buffer = buffers[0]
        geometry_buffers = dict(zip(geometry_keys, buffers[1:1 + len(geometry_keys)]))
        id_buffers = dict(zip(id_keys,
                              buffers[1 + len(geometry_keys):
                                      1 + len(geometry_keys) + len(id_keys)]))
        ping_buffers = buffers[1 + len(geometry_keys) + len(id_keys):]
        if target_viewport[2] == 0 or target_viewport[3] == 0:
            target_viewport = (0, 0, width, height)
        proximity_buffers = {}
        blur_buffers = {}
        try:
            with scene_buffer.bind():
                gpu.state.viewport_set(0, 0, width, height)
                priority_queues, proximity_buffers, blur_buffers = self._draw_scene_shadows(
                    depsgraph, view_matrix, projection_matrix, cache, textures,
                    width, height, viewport, scene_buffer, transparent_background,
                    retain_proximity=True)
            for (threshold, selected), geometry_buffer in geometry_buffers.items():
                with geometry_buffer.bind():
                    gpu.state.viewport_set(0, 0, width, height)
                    gpu.state.active_framebuffer_get().clear(
                        color=(0.0, 0.0, 0.0, 0.0), depth=1.0)
                    self._draw_geometry(view_matrix, projection_matrix,
                                        priority_queues, textures,
                                        occlusion_alpha_threshold=threshold,
                                        selected_material_pointers=selected,
                                        proximity_buffers=proximity_buffers,
                                        blur_buffers=blur_buffers)
            material_ids = {
                pointer: index + 1
                for index, pointer in enumerate(sorted({item[1] for queues in priority_queues.values()
                                                        for queue in queues for item in queue}))
            } if id_keys else {}
            for (threshold, selected), id_buffer in id_buffers.items():
                with id_buffer.bind():
                    gpu.state.viewport_set(0, 0, width, height)
                    gpu.state.active_framebuffer_get().clear(
                        color=(0.0, 0.0, 0.0, 0.0), depth=1.0)
                    self._draw_geometry(view_matrix, projection_matrix,
                                        priority_queues, textures, material_ids,
                                        occlusion_alpha_threshold=threshold,
                                        selected_material_pointers=selected,
                                        proximity_buffers=proximity_buffers,
                                        blur_buffers=blur_buffers)
            source = scene_buffer.texture_color
            for index, effect in enumerate(effects):
                selected_ids = None
                if effect.limit_to_materials:
                    selected_ids = tuple(sorted(material_ids[pointer]
                        for pointer in effect_selections[index] if pointer in material_ids))
                id_key = (effect.occlusion_alpha_threshold, effect_selections[index])
                id_buffer = id_buffers.get(id_key) if selected_ids else None
                geometry_buffer = (geometry_buffers.get(id_key)
                                   if effect.effect_type == 'OUTLINE' else None)
                if index == len(effects) - 1:
                    binding = target_framebuffer.bind()
                    with binding:
                        gpu.state.viewport_set(*target_viewport)
                        self._draw_post_effect(source, geometry_buffer.texture_color if geometry_buffer else None,
                                               effect, target_viewport[:2],
                                               id_buffer.texture_color if id_buffer else None,
                                               selected_ids)
                else:
                    target = ping_buffers[index % len(ping_buffers)]
                    with target.bind():
                        gpu.state.viewport_set(0, 0, width, height)
                        self._draw_post_effect(
                            source, geometry_buffer.texture_color if geometry_buffer else None, effect,
                            material_id_texture=id_buffer.texture_color if id_buffer else None,
                            selected_ids=selected_ids)
                    source = target.texture_color
        finally:
            for offscreen, _ in proximity_buffers.values():
                offscreen.free()
            for offscreen in blur_buffers.values():
                offscreen.free()
            if not viewport:
                for offscreen in buffers:
                    offscreen.free()

    @staticmethod
    def _active_effects(scene):
        # Custom World collections can stay stale on scene_eval after an item
        # is removed. Read the editable World so the viewport drops it now.
        world = scene.original.world
        return [effect for effect in world.toon_effects if effect.enabled] if world else []

    def view_draw(self, context, depsgraph):
        import gpu

        region = context.region
        if region.width < 1 or region.height < 1:
            return
        view = context.region_data
        scene = depsgraph.scene_eval
        effects = (self._active_effects(scene)
                   if scene.toon_viewport_effects else [])
        camera = depsgraph.scene_eval.camera
        if (view.view_perspective == 'CAMERA' and camera is not None
                and camera.data.type == 'PANO'
                and camera.data.panorama_type in {'EQUIRECTANGULAR', 'FISHEYE_EQUISOLID'}):
            if self._viewport_resolution_buffer:
                gpu_compat.forget_shaders(self._shaders.values())
                self._shaders = {}
                self._viewport_resolution_buffer[1].free()
                self._viewport_resolution_buffer = None
            frame_rect = _panorama_camera_frame(context, camera)
            _sync_extras_overlay(
                context.space_data, context.space_data.overlay.show_overlays)
            draw_bones = _sync_bone_overlay(
                context.space_data,
                context.mode in {'POSE', 'OBJECT'}
                and context.space_data.overlay.show_overlays)
            draw_objects = _sync_outline_overlay(
                context.space_data,
                context.mode == 'OBJECT' and context.space_data.overlay.show_overlays)
            self._draw_panorama_viewport(depsgraph, camera, region.width,
                                         region.height, effects, frame_rect,
                                         context if draw_bones or draw_objects else None)
            return
        _sync_bone_overlay(context.space_data, False)
        _sync_outline_overlay(context.space_data, False)
        _sync_extras_overlay(context.space_data, False)
        if self._viewport_panorama_buffers:
            gpu_compat.forget_shaders(self._shaders.values())
            self._shaders = {}
            for offscreen in self._viewport_panorama_buffers[1]:
                offscreen.free()
            self._viewport_panorama_buffers = None
        scale = scene.toon_viewport_resolution / 100.0
        width = max(1, round(region.width * scale))
        height = max(1, round(region.height * scale))
        reduced = (width, height) != (region.width, region.height)
        if self._viewport_resolution_buffer and (
                not reduced or self._viewport_resolution_buffer[0] != (width, height)):
            gpu_compat.forget_shaders(self._shaders.values())
            self._shaders = {}
            self._viewport_resolution_buffer[1].free()
            self._viewport_resolution_buffer = None
        if reduced:
            target_framebuffer = gpu.state.active_framebuffer_get()
            target_viewport = gpu.state.viewport_get()
            if target_viewport[2] == 0 or target_viewport[3] == 0:
                target_viewport = (0, 0, region.width, region.height)
            if self._viewport_resolution_buffer is None:
                offscreen = gpu.types.GPUOffScreen(width, height, format='RGBA16F')
                self._viewport_resolution_buffer = ((width, height), offscreen)
            offscreen = self._viewport_resolution_buffer[1]
            with offscreen.bind():
                gpu.state.viewport_set(0, 0, width, height)
                self._draw_standard_viewport(
                    depsgraph, view, effects, width, height)
            with target_framebuffer.bind():
                gpu.state.viewport_set(*target_viewport)
                self._draw_viewport_blit(offscreen.texture_color, target_viewport)
        else:
            self._draw_standard_viewport(
                depsgraph, view, effects, region.width, region.height)

    def _draw_standard_viewport(self, depsgraph, view, effects, width, height):
        if effects:
            self._draw_with_effects(depsgraph, view.view_matrix, view.window_matrix,
                                    self._viewport_batches, self._viewport_textures,
                                    width, height, effects, viewport=True)
        else:
            self._draw_scene_shadows(
                depsgraph, view.view_matrix, view.window_matrix,
                self._viewport_batches, self._viewport_textures,
                width, height, viewport=True)

    def _draw_panorama_viewport(self, depsgraph, camera, width, height, effects,
                                frame_rect=None, context=None):
        import gpu

        target_framebuffer = gpu.state.active_framebuffer_get()
        target_viewport = gpu.state.viewport_get()
        frame_rect = frame_rect or (0, 0, width, height)
        frame_width, frame_height = frame_rect[2:]
        face_size = self._panorama_face_size(
            camera.data, frame_width, frame_height,
            camera.data.toon_panorama_viewport_quality
            * depsgraph.scene_eval.toon_viewport_resolution / 100.0)
        if (self._viewport_panorama_buffers is None
                or self._viewport_panorama_buffers[0] != face_size):
            if self._viewport_panorama_buffers:
                gpu_compat.forget_shaders(self._shaders.values())
                self._shaders = {}
                for old in self._viewport_panorama_buffers[1]:
                    old.free()
            buffers = [gpu.types.GPUOffScreen(face_size, face_size, format='RGBA16F')
                       for _ in panorama.FACE_ROTATIONS]
            self._viewport_panorama_buffers = (face_size, buffers)
        else:
            buffers = self._viewport_panorama_buffers[1]

        projection = panorama.face_projection(camera.data.clip_start,
                                              camera.data.clip_end)
        for rotation, offscreen in zip(panorama.FACE_ROTATIONS, buffers):
            view = (camera.matrix_world @ rotation).inverted()
            with offscreen.bind():
                gpu.state.viewport_set(0, 0, face_size, face_size)
                if effects:
                    self._draw_with_effects(
                        depsgraph, view, projection, self._viewport_batches,
                        self._viewport_textures, face_size, face_size, effects,
                        viewport=True, output_offscreen=offscreen)
                else:
                    self._draw_scene_shadows(
                        depsgraph, view, projection, self._viewport_batches,
                        self._viewport_textures, face_size, face_size,
                        viewport=True, output_offscreen=offscreen)
        world = depsgraph.scene_eval.world
        background = (*world.toon_background_color, 1.0) if world else (0.05, 0.05, 0.05, 1.0)
        with target_framebuffer.bind():
            if frame_rect != (0, 0, width, height):
                target_framebuffer.clear(color=background)
            image_origin = (target_viewport[0] + frame_rect[0],
                            target_viewport[1] + frame_rect[1])
            gpu.state.viewport_set(*image_origin, frame_width, frame_height)
            self._draw_panorama_composite(
                camera.data, buffers, frame_width, frame_height,
                image_origin, background,
                (depsgraph.scene_eval.render.pixel_aspect_x,
                 depsgraph.scene_eval.render.pixel_aspect_y))
            gpu.state.viewport_set(*target_viewport)
            if context is not None:
                if (context.mode == 'OBJECT'
                        and context.space_data.as_pointer() in _PANORAMA_OUTLINE_STATES):
                    self._draw_panorama_object_selection(context, camera,
                                                         frame_rect)
                if (context.mode in {'POSE', 'OBJECT'}
                        and context.space_data.as_pointer() in _PANORAMA_BONE_STATES):
                    self._draw_panorama_bones(context, camera, frame_rect)

    @staticmethod
    def _panorama_face_size(camera_data, width, height, quality):
        if camera_data.panorama_type == 'FISHEYE_EQUISOLID':
            base = max(width, height) / 2
        else:
            longitude_span = abs(camera_data.longitude_max - camera_data.longitude_min)
            latitude_span = abs(camera_data.latitude_max - camera_data.latitude_min)
            base = max(width * (math.pi / 2) / max(longitude_span, 0.001),
                       height * (math.pi / 2) / max(latitude_span, 0.001))
        return max(16, math.ceil(base * quality))

    def render(self, depsgraph):
        import gpu

        scene = depsgraph.scene_eval
        transparent_background = (scene.toon_transparent
                                  and scene.render.image_settings.file_format == 'PNG')
        if transparent_background:
            scene.original.render.image_settings.color_mode = 'RGBA'
        camera = scene.camera
        if camera is None:
            self.report({'ERROR'}, "Toon Render needs an active camera")
            return
        scale = scene.render.resolution_percentage / 100.0
        width = max(1, round(scene.render.resolution_x * scale))
        height = max(1, round(scene.render.resolution_y * scale))
        # The render method has its own GPU context. Its batches must not share
        # the viewport cache, whose resources belong to another context.
        gpu_compat.forget_shaders(self._shaders.values())
        self._shaders = {}
        try:
            if camera.data.type == 'PANO':
                if camera.data.panorama_type not in {'EQUIRECTANGULAR', 'FISHEYE_EQUISOLID'}:
                    self.report({'ERROR'}, 'Toon Render supports Equirectangular and Fisheye Equisolid panorama')
                    return
                face_size = self._panorama_face_size(
                    camera.data, width, height, camera.data.toon_panorama_quality)
                projection = panorama.face_projection(camera.data.clip_start,
                                                      camera.data.clip_end)
                faces = []
                for rotation in panorama.FACE_ROTATIONS:
                    view = (camera.matrix_world @ rotation).inverted()
                    faces.append(self._render_camera_pixels(
                        depsgraph, view, projection, face_size, face_size,
                        transparent_background, scene))
                    # Vulkan retains sampler references to the temporary post
                    # textures; release shaders before rendering the next face.
                    gpu_compat.forget_shaders(self._shaders.values())
                    self._shaders = {}
                world = scene.world
                background = ((0.0, 0.0, 0.0, 0.0) if transparent_background
                              else (*world.toon_background_color, 1.0) if world
                              else (0.05, 0.05, 0.05, 1.0))
                pixels = panorama.stitch_panorama(
                    faces, width, height, camera.data, background,
                    scene.render.pixel_aspect_x, scene.render.pixel_aspect_y)
            else:
                projection = camera.calc_matrix_camera(depsgraph, x=width, y=height)
                view = camera.matrix_world.inverted()
                pixels = self._render_camera_pixels(depsgraph, view, projection,
                                                    width, height, transparent_background, scene)

            result = self.begin_result(0, 0, width, height)
            result.layers[0].passes['Combined'].rect = [
                tuple(pixels[y][x]) for y in range(height) for x in range(width)
            ]
            self.end_result(result)
        finally:
            # The final-render GPU context can differ from the viewport context.
            gpu_compat.forget_shaders(self._shaders.values())
            self._shaders = {}

    def _render_camera_pixels(self, depsgraph, view, projection, width, height,
                              transparent_background, scene):
        import gpu

        offscreen = gpu.types.GPUOffScreen(width, height, format='RGBA16F')
        try:
            with offscreen.bind():
                gpu.state.viewport_set(0, 0, width, height)
                framebuffer = gpu.state.active_framebuffer_get()
                effects = self._active_effects(scene)
                if effects:
                    self._draw_with_effects(depsgraph, view, projection, {}, {},
                                            width, height, effects,
                                            output_offscreen=offscreen,
                                            transparent_background=transparent_background)
                else:
                    self._draw_scene_shadows(depsgraph, view, projection, {}, {},
                                             width, height, output_offscreen=offscreen,
                                             transparent_background=transparent_background)
                with framebuffer.bind():
                    buffer = framebuffer.read_color(0, 0, width, height, 4, 0, 'FLOAT')
                    return np.array(buffer.to_list(), dtype=np.float32).reshape(height, width, 4)
        finally:
            offscreen.free()


class TOON_PT_render_settings(bpy.types.Panel):
    bl_label = 'Toon Render'
    bl_idname = 'TOON_PT_render_settings'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'render'

    @classmethod
    def poll(cls, context):
        return context.scene is not None and context.scene.render.engine == 'TOON_RENDER'

    def draw(self, context):
        row = self.layout.row()
        row.enabled = context.scene.render.image_settings.file_format == 'PNG'
        row.prop(context.scene, 'toon_transparent', text='Transparent')


class TOON_PT_render_viewport(bpy.types.Panel):
    bl_label = 'Viewport Preview'
    bl_idname = 'TOON_PT_render_viewport'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'render'
    bl_parent_id = 'TOON_PT_render_settings'

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        layout.use_property_split = True
        layout.prop(scene, 'toon_viewport_resolution', text='Resolution')
        layout.prop(scene, 'toon_viewport_shadows', text='Shadows')
        layout.prop(scene, 'toon_viewport_effects', text='Post Processing')
        camera = scene.camera
        if camera and camera.data.type == 'PANO':
            layout.prop(camera.data, 'toon_panorama_viewport_quality',
                        text='Panorama Face Quality')


class TOON_PT_camera_settings(bpy.types.Panel):
    bl_label = 'Lens'
    bl_idname = 'TOON_PT_camera_settings'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'data'

    @classmethod
    def poll(cls, context):
        return context.engine == 'TOON_RENDER' and context.camera is not None

    def draw(self, context):
        camera = context.camera
        layout = self.layout
        layout.use_property_split = True
        layout.prop(camera, 'type')
        if camera.type == 'PERSP':
            layout.prop(camera, 'lens' if camera.lens_unit == 'MILLIMETERS' else 'angle')
            layout.prop(camera, 'lens_unit')
        elif camera.type == 'ORTHO':
            layout.prop(camera, 'ortho_scale')
        elif camera.type == 'PANO':
            layout.prop(camera, 'panorama_type', text='Projection')
            if camera.panorama_type == 'EQUIRECTANGULAR':
                layout.prop(camera, 'longitude_min')
                layout.prop(camera, 'longitude_max')
                layout.prop(camera, 'latitude_min')
                layout.prop(camera, 'latitude_max')
            elif camera.panorama_type == 'FISHEYE_EQUISOLID':
                layout.prop(camera, 'fisheye_lens', text='Fisheye Lens')
                layout.prop(camera, 'fisheye_fov')
                layout.prop(camera, 'sensor_fit')
                layout.prop(camera, 'sensor_width')
                layout.prop(camera, 'sensor_height')
            else:
                layout.label(text='Projection unavailable in Toon Render', icon='INFO')
            if camera.panorama_type in {'EQUIRECTANGULAR', 'FISHEYE_EQUISOLID'}:
                layout.prop(camera, 'toon_panorama_quality', text='Render Face Resolution')
                layout.prop(camera, 'toon_panorama_viewport_quality', text='Viewport Face Resolution')
        layout.separator()
        if camera.type != 'PANO':
            layout.prop(camera, 'shift_x')
            layout.prop(camera, 'shift_y')
        layout.prop(camera, 'clip_start')
        layout.prop(camera, 'clip_end')


def _selection_mouse_button(context):
    keyconfig = context.window_manager.keyconfigs.active
    chosen = context.preferences.keymap.active_keyconfig.lower()
    if '27x' in chosen or '2.7' in chosen:
        return 'RIGHTMOUSE'
    preferences = keyconfig.preferences if keyconfig else None
    select_mouse = getattr(preferences, 'select_mouse', None)
    if select_mouse in {'LEFT', 'RIGHT'}:
        return select_mouse + 'MOUSE'
    names = (getattr(keyconfig, 'name', '') + ' '
             + context.preferences.keymap.active_keyconfig).lower()
    return 'RIGHTMOUSE' if '27x' in names or '2.7' in names else 'LEFTMOUSE'


class TOON_OT_select_panorama_object(bpy.types.Operator):
    bl_idname = 'view3d.toon_select_panorama_object'
    bl_label = 'Select Panoramic Object'
    bl_description = 'Select an object through its panoramic camera position'
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        camera = context.scene.camera if context.scene else None
        return (context.area is not None and context.area.type == 'VIEW_3D'
                and context.mode == 'OBJECT'
                and context.space_data.shading.type == 'RENDERED'
                and context.scene.render.engine == 'TOON_RENDER'
                and context.region_data is not None
                and context.region_data.view_perspective == 'CAMERA'
                and camera is not None and camera.data.type == 'PANO'
                and camera.data.panorama_type in {
                    'EQUIRECTANGULAR', 'FISHEYE_EQUISOLID'})

    @staticmethod
    def select_at(context, x, y, extend=False):
        camera = context.scene.camera
        frame_rect = _panorama_camera_frame(context, camera)
        if frame_rect is None:
            return False
        direction_local = panorama.unproject_direction(
            x, y, camera.data, frame_rect,
            context.scene.render.pixel_aspect_x,
            context.scene.render.pixel_aspect_y)
        if direction_local is None:
            return False
        obj = None
        if (context.space_data.overlay.show_overlays
                and (context.space_data.overlay.show_bones
                     or context.space_data.as_pointer() in _PANORAMA_BONE_STATES)):
            nearest_distance = 12.0 ** 2
            for armature, _bone, segments in _project_pose_bones(
                    context, camera, frame_rect):
                if armature.hide_select:
                    continue
                for first, second in segments:
                    dx, dy = second[0] - first[0], second[1] - first[1]
                    length_squared = dx * dx + dy * dy
                    t = (max(0.0, min(1.0,
                             ((x - first[0]) * dx + (y - first[1]) * dy)
                             / length_squared)) if length_squared > 1e-8 else 0.0)
                    distance_squared = ((x - first[0] - t * dx) ** 2
                                        + (y - first[1] - t * dy) ** 2)
                    if distance_squared < nearest_distance:
                        nearest_distance = distance_squared
                        obj = armature
        if obj is None:
            direction = (camera.matrix_world.to_3x3()
                         @ Vector(direction_local)).normalized()
            start = camera.data.clip_start
            hit, _position, _normal, _face, obj, _matrix = context.scene.ray_cast(
                context.view_layer.depsgraph,
                camera.matrix_world.translation + direction * start,
                direction, distance=max(camera.data.clip_end - start, 0.001))
            obj = obj.original if hit and obj is not None else None
        if obj is not None and (obj.name not in context.view_layer.objects
                                or not obj.visible_get() or obj.hide_select):
            obj = None
        if not extend:
            for selected in context.selected_objects:
                selected.select_set(False)
        if obj is not None:
            obj.select_set(not obj.select_get() if extend else True)
            context.view_layer.objects.active = obj
        context.area.tag_redraw()
        return True

    def invoke(self, context, event):
        if event.type != _selection_mouse_button(context):
            return {'PASS_THROUGH'}
        handled = self.select_at(context, event.mouse_region_x,
                                 event.mouse_region_y, event.shift)
        return {'FINISHED'} if handled else {'PASS_THROUGH'}


class TOON_OT_select_panorama_bone(bpy.types.Operator):
    bl_idname = 'view3d.toon_select_panorama_bone'
    bl_label = 'Select Panoramic Bone'
    bl_description = 'Select a pose bone at its projected position in the panoramic camera'
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        camera = context.scene.camera if context.scene else None
        return (context.area is not None and context.area.type == 'VIEW_3D'
                and context.mode == 'POSE'
                and context.space_data.shading.type == 'RENDERED'
                and context.scene.render.engine == 'TOON_RENDER'
                and context.region_data is not None
                and context.region_data.view_perspective == 'CAMERA'
                and camera is not None and camera.data.type == 'PANO'
                and camera.data.panorama_type in {
                    'EQUIRECTANGULAR', 'FISHEYE_EQUISOLID'})

    @staticmethod
    def select_at(context, x, y, extend=False):
        camera = context.scene.camera
        frame_rect = _panorama_camera_frame(context, camera)
        if frame_rect is None:
            return False
        left, bottom, width, height = frame_rect
        if not (left <= x <= left + width and bottom <= y <= bottom + height):
            return False

        nearest = None
        best_distance_squared = 12.0 ** 2
        for armature, pose_bone, segments in _project_pose_bones(
                context, camera, frame_rect):
            for first, second in segments:
                dx = second[0] - first[0]
                dy = second[1] - first[1]
                denominator = dx * dx + dy * dy
                t = (max(0.0, min(1.0,
                         ((x - first[0]) * dx + (y - first[1]) * dy) / denominator))
                     if denominator > 1e-8 else 0.0)
                distance_squared = ((x - first[0] - t * dx) ** 2
                                    + (y - first[1] - t * dy) ** 2)
                if distance_squared < best_distance_squared:
                    best_distance_squared = distance_squared
                    nearest = (armature, pose_bone)

        if not extend:
            for obj in context.objects_in_mode:
                if obj.type == 'ARMATURE':
                    for pose_bone in obj.pose.bones:
                        _set_pose_bone_selected(pose_bone, False)
        if nearest is not None:
            armature, pose_bone = nearest
            _set_pose_bone_selected(
                pose_bone, not _pose_bone_selected(pose_bone) if extend else True)
            armature.data.bones.active = pose_bone.bone
            context.view_layer.objects.active = armature
        context.area.tag_redraw()
        return True

    def invoke(self, context, event):
        if event.type != _selection_mouse_button(context):
            return {'PASS_THROUGH'}
        handled = self.select_at(context, event.mouse_region_x,
                                 event.mouse_region_y, event.shift)
        return {'FINISHED'} if handled else {'PASS_THROUGH'}


class TOON_PT_material_slots(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'TOON_PT_material_slots'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'material'
    bl_options = {'HIDE_HEADER'}
    bl_order = 0

    @classmethod
    def poll(cls, context):
        obj = context.object
        return (context.scene is not None
                and context.scene.render.engine == 'TOON_RENDER'
                and ((obj is not None and hasattr(obj.data, 'materials'))
                     or context.material is not None))

    def draw(self, context):
        layout = self.layout
        obj = context.object
        material = context.material
        slot = context.material_slot

        if obj and hasattr(obj.data, 'materials'):
            sortable = len(obj.material_slots) > 1
            row = layout.row()
            row.template_list('MATERIAL_UL_matslots', '', obj, 'material_slots',
                              obj, 'active_material_index', rows=5 if sortable else 3)
            column = row.column(align=True)
            column.operator('object.material_slot_add', icon='ADD', text='')
            column.operator('object.material_slot_remove', icon='REMOVE', text='')
            column.separator()
            column.menu('MATERIAL_MT_context_menu', icon='DOWNARROW_HLT', text='')
            if sortable:
                column.separator()
                column.operator('object.material_slot_move', icon='TRIA_UP', text='').direction = 'UP'
                column.operator('object.material_slot_move', icon='TRIA_DOWN', text='').direction = 'DOWN'

            row = layout.row()
            row.template_ID(obj, 'active_material', new=toon_nodes.TOON_OT_new_material.bl_idname)
            if slot:
                row.prop(slot, 'link', icon_only=True)
            if obj.mode == 'EDIT':
                row = layout.row(align=True)
                row.operator('object.material_slot_assign', text='Assign')
                row.operator('object.material_slot_select', text='Select')
                row.operator('object.material_slot_deselect', text='Deselect')
        elif material:
            layout.template_ID(context.space_data, 'pin_id')


class TOON_PT_material_settings(bpy.types.Panel):
    bl_label = 'Toon Render'
    bl_idname = 'TOON_PT_material_settings'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'material'
    bl_order = 1

    @classmethod
    def poll(cls, context):
        return (context.scene is not None
                and context.scene.render.engine == 'TOON_RENDER'
                and context.material is not None)

    def draw(self, context):
        material = context.material
        self.layout.prop(material, 'toon_double_sided', text='Double Sided')
        self.layout.prop(material, 'toon_unlit', text='Unlit')
        self.layout.prop(material, 'toon_cast_shadow', text='Cast Shadow')
        self.layout.prop(material, 'toon_receive_shadow', text='Receive Shadow')


def register():
    toon_nodes.register()
    post_effects.register()
    shadows.register()
    bpy.types.Scene.toon_transparent = bpy.props.BoolProperty(
        name='Transparent', default=False,
        description='Keep background and material transparency in PNG renders',
        update=_update_transparent_png)
    bpy.types.Scene.toon_viewport_resolution = bpy.props.IntProperty(
        name='Viewport Resolution', default=100, min=25, max=100,
        subtype='PERCENTAGE',
        description='Internal resolution of the rendered viewport preview; panoramic cameras scale their cube faces',
        update=toon_nodes._tag_viewports)
    bpy.types.Scene.toon_viewport_shadows = bpy.props.BoolProperty(
        name='Viewport Shadows', default=True,
        description='Render light shadows in the viewport preview',
        update=toon_nodes._tag_viewports)
    bpy.types.Scene.toon_viewport_effects = bpy.props.BoolProperty(
        name='Viewport Post Processing', default=True,
        description='Render World post processing effects in the viewport preview',
        update=toon_nodes._tag_viewports)
    bpy.types.Camera.toon_panorama_quality = bpy.props.FloatProperty(
        name='Face Resolution', default=1.25, min=0.5, max=3.0,
        description='Cube face resolution in final panorama renders; higher values improve sharpness and cost more memory')
    bpy.types.Camera.toon_panorama_viewport_quality = bpy.props.FloatProperty(
        name='Viewport Face Resolution', default=0.6, min=0.25, max=2.0,
        description='Cube face resolution in camera viewport; higher values improve sharpness and reduce frame rate',
        update=toon_nodes._tag_viewports)
    bpy.types.World.toon_background_color = bpy.props.FloatVectorProperty(
        name='Background Color', subtype='COLOR', size=3,
        min=0.0, max=1.0, default=(0.05, 0.05, 0.05),
        description='Background color in Toon renders and the 3D viewport',
        update=toon_nodes._tag_viewports)
    bpy.types.Material.toon_double_sided = bpy.props.BoolProperty(
        name='Double Sided', default=False,
        description='Render both front and back faces of this material',
        update=toon_nodes._tag_viewports)
    bpy.types.Material.toon_unlit = bpy.props.BoolProperty(
        name='Unlit', default=False,
        description='Render the material color and texture without lighting',
        update=toon_nodes._tag_viewports)
    bpy.types.Material.toon_cast_shadow = bpy.props.BoolProperty(
        name='Cast Shadow', default=True,
        description='Allow this material to cast shadows from Toon lights',
        update=toon_nodes._tag_viewports)
    bpy.types.Material.toon_receive_shadow = bpy.props.BoolProperty(
        name='Receive Shadow', default=True,
        description='Allow this material to receive shadows from Toon lights',
        update=toon_nodes._tag_viewports)
    bpy.utils.register_class(ToonRenderEngine)
    bpy.utils.register_class(TOON_PT_render_settings)
    bpy.utils.register_class(TOON_PT_render_viewport)
    bpy.utils.register_class(TOON_PT_camera_settings)
    bpy.utils.register_class(TOON_OT_select_panorama_object)
    bpy.utils.register_class(TOON_OT_select_panorama_bone)
    bpy.utils.register_class(TOON_PT_material_slots)
    bpy.utils.register_class(TOON_PT_material_settings)
    for panel in _OUTPUT_PANELS:
        panel.COMPAT_ENGINES.add(ToonRenderEngine.bl_idname)
    for panel in _DATA_PANELS:
        panel.COMPAT_ENGINES.add(ToonRenderEngine.bl_idname)
    for panel in _CAMERA_PANELS:
        panel.COMPAT_ENGINES.add(ToonRenderEngine.bl_idname)
    keyconfig = bpy.context.window_manager.keyconfigs.addon
    if keyconfig is not None:
        for keymap_name, operator in (
                ('Pose', TOON_OT_select_panorama_bone),
                ('Object Mode', TOON_OT_select_panorama_object),
                ('3D View', TOON_OT_select_panorama_object)):
            keymap = keyconfig.keymaps.new(name=keymap_name, space_type='EMPTY')
            for button in ('LEFTMOUSE', 'RIGHTMOUSE'):
                for extend in (False, True):
                    item = keymap.keymap_items.new(
                        operator.bl_idname, button, 'PRESS', shift=extend,
                        head=True)
                    _PANORAMA_BONE_KEYMAPS.append((keymap, item))
    _set_world_viewport_draw(_draw_world_viewport_display)
    bpy.app.handlers.load_post.append(_toon_load_post)
    bpy.app.handlers.save_pre.append(_toon_save_pre)
    bpy.app.handlers.save_post.append(_toon_save_post)
    _subscribe_engine_changes()
    bpy.app.timers.register(_deferred_initial_sync, first_interval=0.1)


def unregister():
    for keymap, item in _PANORAMA_BONE_KEYMAPS:
        keymap.keymap_items.remove(item)
    _PANORAMA_BONE_KEYMAPS.clear()
    if bpy.app.timers.is_registered(_bone_overlay_watchdog):
        bpy.app.timers.unregister(_bone_overlay_watchdog)
    _restore_bone_overlays()
    if bpy.app.timers.is_registered(_deferred_initial_sync):
        bpy.app.timers.unregister(_deferred_initial_sync)
    bpy.msgbus.clear_by_owner(_ENGINE_CHANGE_OWNER)
    bpy.app.handlers.load_post.remove(_toon_load_post)
    bpy.app.handlers.save_pre.remove(_toon_save_pre)
    bpy.app.handlers.save_post.remove(_toon_save_post)
    _SCENE_ENGINES.clear()
    _set_world_viewport_draw(_WORLD_VIEWPORT_DRAW)
    for panel in _DATA_PANELS:
        panel.COMPAT_ENGINES.discard(ToonRenderEngine.bl_idname)
    for panel in _CAMERA_PANELS:
        panel.COMPAT_ENGINES.discard(ToonRenderEngine.bl_idname)
    for panel in _OUTPUT_PANELS:
        panel.COMPAT_ENGINES.discard(ToonRenderEngine.bl_idname)
    bpy.utils.unregister_class(TOON_PT_material_settings)
    bpy.utils.unregister_class(TOON_PT_material_slots)
    bpy.utils.unregister_class(TOON_PT_camera_settings)
    bpy.utils.unregister_class(TOON_OT_select_panorama_bone)
    bpy.utils.unregister_class(TOON_OT_select_panorama_object)
    bpy.utils.unregister_class(TOON_PT_render_viewport)
    bpy.utils.unregister_class(TOON_PT_render_settings)
    bpy.utils.unregister_class(ToonRenderEngine)
    del bpy.types.World.toon_background_color
    del bpy.types.Scene.toon_transparent
    del bpy.types.Scene.toon_viewport_effects
    del bpy.types.Scene.toon_viewport_shadows
    del bpy.types.Scene.toon_viewport_resolution
    del bpy.types.Camera.toon_panorama_quality
    del bpy.types.Camera.toon_panorama_viewport_quality
    del bpy.types.Material.toon_receive_shadow
    del bpy.types.Material.toon_cast_shadow
    del bpy.types.Material.toon_unlit
    del bpy.types.Material.toon_double_sided
    shadows.unregister()
    post_effects.unregister()
    toon_nodes.unregister()


if __name__ == "__main__":
    register()
