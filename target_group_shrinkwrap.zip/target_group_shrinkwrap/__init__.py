bl_info = {
    "name": "Target Group Shrinkwrap",
    "author": "Codex",
    "version": (0, 3, 1),
    "blender": (4, 5, 0),
    "location": "Add Modifier > Deform > Target Group Shrinkwrap",
    "description": "Use a vertex group on the target to restrict a native Shrinkwrap modifier",
    "category": "Object",
}

import bpy
from bpy.app.handlers import persistent
from bpy.props import FloatProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup


PROXY_TAG = "target_group_shrinkwrap_proxy"
PROXY_ARMED = "target_group_shrinkwrap_linked"
PROXY_MODIFIER = "Target Group Filter"
PROXY_COLLECTION = "Target Group Shrinkwrap Proxies"
_cleanup_scheduled = False


def make_filter_group():
    group = bpy.data.node_groups.new("Target Group Shrinkwrap Filter", "GeometryNodeTree")
    group.is_modifier = True
    iface = group.interface
    iface.new_socket(name="Geometry", in_out="OUTPUT", socket_type="NodeSocketGeometry")
    iface.new_socket(name="Target", in_out="INPUT", socket_type="NodeSocketObject")
    iface.new_socket(name="Target Group", in_out="INPUT", socket_type="NodeSocketString")
    weight = iface.new_socket(name="Minimum Weight", in_out="INPUT", socket_type="NodeSocketFloat")
    weight.default_value = 0.001
    weight.min_value = 0.0
    weight.max_value = 1.0
    iface.new_socket(name="Use Group", in_out="INPUT", socket_type="NodeSocketBool")

    nodes = group.nodes
    links = group.links
    source = nodes.new("NodeGroupInput")
    source.location = (-650, 0)
    info = nodes.new("GeometryNodeObjectInfo")
    info.transform_space = "RELATIVE"
    info.inputs["As Instance"].default_value = False
    info.location = (-430, 200)
    links.new(source.outputs["Target"], info.inputs["Object"])

    named = nodes.new("GeometryNodeInputNamedAttribute")
    named.data_type = "FLOAT"
    named.location = (-430, -100)
    links.new(source.outputs["Target Group"], named.inputs["Name"])
    compare = nodes.new("FunctionNodeCompare")
    compare.data_type = "FLOAT"
    compare.operation = "GREATER_THAN"
    compare.location = (-200, -100)
    links.new(named.outputs["Attribute"], compare.inputs["A"])
    links.new(source.outputs["Minimum Weight"], compare.inputs["B"])

    separate = nodes.new("GeometryNodeSeparateGeometry")
    separate.domain = "POINT"
    separate.location = (20, 180)
    links.new(info.outputs["Geometry"], separate.inputs["Geometry"])
    links.new(compare.outputs["Result"], separate.inputs["Selection"])

    switch = nodes.new("GeometryNodeSwitch")
    switch.input_type = "GEOMETRY"
    switch.location = (250, 180)
    links.new(source.outputs["Use Group"], switch.inputs["Switch"])
    links.new(info.outputs["Geometry"], switch.inputs["False"])
    links.new(separate.outputs["Selection"], switch.inputs["True"])
    output = nodes.new("NodeGroupOutput")
    output.location = (480, 180)
    links.new(switch.outputs["Output"], output.inputs["Geometry"])
    return group


def sync_proxy(proxy):
    modifier = proxy.modifiers.get(PROXY_MODIFIER)
    if not modifier or modifier.type != "NODES" or not modifier.node_group:
        return
    settings = proxy.target_group_shrinkwrap
    values = {
        "Target": settings.target,
        "Target Group": settings.target_group,
        "Minimum Weight": settings.minimum_weight,
        "Use Group": bool(settings.target_group),
    }
    for socket in modifier.node_group.interface.items_tree:
        if socket.item_type == "SOCKET" and socket.in_out == "INPUT":
            if socket.name in values:
                modifier[socket.identifier] = values[socket.name]
    proxy.update_tag(refresh={"OBJECT", "DATA", "TIME"})


def settings_changed(self, _context):
    proxy = self.id_data
    if isinstance(proxy, bpy.types.Object) and proxy.get(PROXY_TAG):
        sync_proxy(proxy)


def target_poll(self, obj):
    return obj.type == "MESH" and obj != self.id_data


class TGS_Settings(PropertyGroup):
    target: PointerProperty(name="Target", type=bpy.types.Object, poll=target_poll,
                            update=settings_changed)
    target_group: StringProperty(name="Target Group", update=settings_changed)
    minimum_weight: FloatProperty(
        name="Minimum Weight", default=0.001, min=0.0, max=1.0,
        description="Only target vertices with a greater group weight are included",
        update=settings_changed,
    )


def proxy_for_modifier(modifier):
    if modifier and modifier.type == "SHRINKWRAP":
        target = modifier.target
        if target and target.get(PROXY_TAG):
            return target
    return None


def active_pair(obj):
    active = obj.modifiers.active
    proxy = proxy_for_modifier(active)
    if proxy:
        return active, proxy
    for modifier in obj.modifiers:
        proxy = proxy_for_modifier(modifier)
        if proxy:
            return modifier, proxy
    return None, None


def referenced_proxy_ids():
    return {
        modifier.target.as_pointer()
        for obj in bpy.data.objects
        for modifier in obj.modifiers
        if modifier.type == "SHRINKWRAP" and modifier.target
        and modifier.target.get(PROXY_TAG)
    }


def orphan_proxies():
    referenced = referenced_proxy_ids()
    return [
        obj for obj in bpy.data.objects
        if obj.get(PROXY_TAG) and obj.get(PROXY_ARMED)
        and obj.as_pointer() not in referenced
    ]


def remove_proxy(proxy):
    filter_modifier = proxy.modifiers.get(PROXY_MODIFIER)
    node_group = filter_modifier.node_group if filter_modifier else None
    proxy_mesh = proxy.data
    bpy.data.objects.remove(proxy, do_unlink=True)
    if proxy_mesh and proxy_mesh.users == 0:
        bpy.data.meshes.remove(proxy_mesh)
    if node_group and node_group.users == 0:
        bpy.data.node_groups.remove(node_group)


def cleanup_orphan_proxies():
    global _cleanup_scheduled
    _cleanup_scheduled = False
    for proxy in orphan_proxies():
        remove_proxy(proxy)
    return None


@persistent
def hide_existing_proxies(_dummy):
    referenced = referenced_proxy_ids()
    for proxy in bpy.data.objects:
        if not proxy.get(PROXY_TAG):
            continue
        proxy.hide_viewport = True
        proxy.hide_render = True
        if proxy.as_pointer() in referenced:
            proxy[PROXY_ARMED] = True
        for scene in bpy.data.scenes:
            for view_layer in scene.view_layers:
                try:
                    proxy.hide_set(True, view_layer=view_layer)
                except RuntimeError:
                    pass


def hide_existing_after_register():
    # Blender exposes a restricted bpy.data while an add-on is registering.
    # The timer runs after registration, when scene objects are available.
    hide_existing_proxies(None)
    return None


@persistent
def schedule_orphan_cleanup(_scene, _depsgraph):
    global _cleanup_scheduled
    if not _cleanup_scheduled and orphan_proxies():
        _cleanup_scheduled = True
        bpy.app.timers.register(cleanup_orphan_proxies, first_interval=0.05)


class OBJECT_OT_add_target_group_shrinkwrap(Operator):
    bl_idname = "object.add_target_group_shrinkwrap"
    bl_label = "Target Group Shrinkwrap"
    bl_description = "Add a native Shrinkwrap restricted to a vertex group on its target"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.type in {
            "MESH", "CURVE", "SURFACE", "FONT", "LATTICE"
        }

    def execute(self, context):
        source = context.object

        collection = bpy.data.collections.get(PROXY_COLLECTION)
        if collection is None:
            collection = bpy.data.collections.new(PROXY_COLLECTION)
            context.scene.collection.children.link(collection)

        proxy_mesh = bpy.data.meshes.new(f"{source.name} target group proxy")
        proxy = bpy.data.objects.new(f"{source.name} target group proxy", proxy_mesh)
        collection.objects.link(proxy)
        proxy[PROXY_TAG] = True
        proxy.hide_viewport = True
        proxy.hide_render = True
        proxy.hide_set(True, view_layer=context.view_layer)

        filter_modifier = proxy.modifiers.new(PROXY_MODIFIER, "NODES")
        filter_modifier.node_group = make_filter_group()
        sync_proxy(proxy)

        shrinkwrap = source.modifiers.new("Target Group Shrinkwrap", "SHRINKWRAP")
        shrinkwrap.target = proxy
        shrinkwrap.wrap_method = "NEAREST_SURFACEPOINT"
        shrinkwrap.wrap_mode = "OUTSIDE_SURFACE"
        source.modifiers.active = shrinkwrap
        proxy[PROXY_ARMED] = True
        return {"FINISHED"}


class OBJECT_OT_remove_target_group_shrinkwrap(Operator):
    bl_idname = "object.remove_target_group_shrinkwrap"
    bl_label = "Remove Target Group Shrinkwrap"
    bl_description = "Remove this Shrinkwrap modifier and its generated target proxy"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.object is not None and active_pair(context.object)[1] is not None

    def execute(self, context):
        modifier, proxy = active_pair(context.object)
        if modifier is None or proxy is None:
            return {"CANCELLED"}
        context.object.modifiers.remove(modifier)
        if proxy.as_pointer() not in referenced_proxy_ids():
            remove_proxy(proxy)
        return {"FINISHED"}


class DATA_PT_target_group_shrinkwrap(Panel):
    bl_label = "Target Group Shrinkwrap"
    bl_idname = "DATA_PT_target_group_shrinkwrap"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "modifier"
    bl_parent_id = "DATA_PT_modifiers"

    @classmethod
    def poll(cls, context):
        return context.object is not None and active_pair(context.object)[1] is not None

    def draw(self, context):
        modifier, proxy = active_pair(context.object)
        settings = proxy.target_group_shrinkwrap
        col = self.layout.column()
        col.label(text=f"Modifier: {modifier.name}")
        col.prop(settings, "target")
        if settings.target:
            col.prop_search(settings, "target_group", settings.target, "vertex_groups")
        else:
            col.prop(settings, "target_group")
        col.prop(settings, "minimum_weight")
        col.separator()
        col.prop(modifier, "wrap_method")
        if modifier.wrap_method != "NEAREST_VERTEX":
            col.prop(modifier, "wrap_mode", text="Snap Mode")
        col.prop(modifier, "offset")
        col.operator(OBJECT_OT_remove_target_group_shrinkwrap.bl_idname,
                     icon="TRASH")


def draw_modifier_menu(self, _context):
    self.layout.operator(OBJECT_OT_add_target_group_shrinkwrap.bl_idname,
                         text="Target Group Shrinkwrap", icon="MOD_SHRINKWRAP")


classes = (TGS_Settings, OBJECT_OT_add_target_group_shrinkwrap,
           OBJECT_OT_remove_target_group_shrinkwrap,
           DATA_PT_target_group_shrinkwrap)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Object.target_group_shrinkwrap = PointerProperty(type=TGS_Settings)
    bpy.types.OBJECT_MT_modifier_add_deform.append(draw_modifier_menu)
    if hide_existing_proxies not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(hide_existing_proxies)
    if schedule_orphan_cleanup not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(schedule_orphan_cleanup)
    bpy.app.timers.register(hide_existing_after_register, first_interval=0.1)


def unregister():
    global _cleanup_scheduled
    if bpy.app.timers.is_registered(hide_existing_after_register):
        bpy.app.timers.unregister(hide_existing_after_register)
    if bpy.app.timers.is_registered(cleanup_orphan_proxies):
        bpy.app.timers.unregister(cleanup_orphan_proxies)
    _cleanup_scheduled = False
    if hide_existing_proxies in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(hide_existing_proxies)
    if schedule_orphan_cleanup in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(schedule_orphan_cleanup)
    bpy.types.OBJECT_MT_modifier_add_deform.remove(draw_modifier_menu)
    del bpy.types.Object.target_group_shrinkwrap
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
